"""v1.10 交易所保护单。"""
import tempfile
import time

import pytest

from parallax_hedge.positions import HedgeHealth, LegPosition
from parallax_hedge.protect import ProtectionManager, orders_for, protective_prices
from parallax_hedge.store import Store
from pathlib import Path

from test_engine import MARKET, make, row, run


def leg(venue, size, mark, liq):
    return LegPosition(venue, "X", size, mark, mark, liq, 0.0, 100.0)


def health(e_size=-15.0, a_size=15.0, mark=1135.6, e_liq=1192.7, a_liq=991.1):
    return HedgeHealth(asset="X", entropy=leg("entropy", e_size, mark, e_liq),
                       arcus=leg("arcus", a_size, mark, a_liq), warn_distance_pct=1.5)


def test_levels_sit_just_inside_each_liquidation_price():
    lv = protective_prices(health(), 1.0)
    assert lv.upper == pytest.approx(1192.7 * 0.99)      # 空腿（Entropy）的强平价往里 1%
    assert lv.lower == pytest.approx(991.1 * 1.01)       # 多腿（Arcus）的强平价往里 1%
    assert lv.short_venue == "entropy" and lv.long_venue == "arcus"
    o = orders_for(lv)
    # 涨到上边界：空腿止损（买）+ 多腿止盈（卖）；跌到下边界：多腿止损 + 空腿止盈
    assert {(x["side"], x["kind"], round(x["trigger"], 2)) for x in o["entropy"]} == {
        ("buy", "sl", round(lv.upper, 2)), ("buy", "tp", round(lv.lower, 2))}
    assert {(x["side"], x["kind"], round(x["trigger"], 2)) for x in o["arcus"]} == {
        ("sell", "sl", round(lv.lower, 2)), ("sell", "tp", round(lv.upper, 2))}


def test_no_levels_when_unhedged_or_already_too_close():
    assert protective_prices(health(a_size=0.0), 1.0) is None
    assert protective_prices(health(e_liq=None), 1.0) is None
    assert protective_prices(health(e_liq=1140.0), 1.0) is None     # 上边界已经低于现价


class FakeEx:
    def __init__(self):
        self.e_live, self.a_live = set(), set()
        self.calls = []
        self.n = 0
        self.arcus_reject = False

    def _id(self):
        self.n += 1
        return str(self.n)

    async def place_entropy_triggers(self, symbol, orders, size_decimals):
        self.calls.append(("e_place", [(o["side"], o["kind"], o["size"]) for o in orders]))
        ids = [self._id() for _ in orders]
        self.e_live |= set(ids)
        return ids, []

    async def cancel_entropy_order(self, symbol, oid):
        self.calls.append(("e_cancel", oid))
        self.e_live.discard(oid)
        return True

    async def entropy_trigger_oids(self, symbol):
        return set(self.e_live)

    async def place_arcus_position_tpsl(self, market, side, sl, tp):
        self.calls.append(("a_place", side, round(sl, 2), round(tp, 2)))
        ids = [self._id(), self._id()]
        if not self.arcus_reject:
            self.a_live |= set(ids)
        return ids, []

    async def arcus_tpsl_orders(self, market):
        return [{"orderId": i, "tpslType": "X", "isPositionTPSL": True} for i in self.a_live]

    async def _arcus_cancel(self, market, oid):
        self.calls.append(("a_cancel", oid))
        self.a_live.discard(oid)
        return True, "CANCELED"


def manager(tmp, **over):
    from parallax_hedge.config import Settings
    st = Settings(env_path=Path("."), data_dir=Path(tmp), **over)
    store = Store(Path(tmp) / "t.db")
    ex = FakeEx()
    m = ProtectionManager(lambda: ex, store, st)
    m.verify_delay = 0.0
    return m, ex, store


def test_ensure_places_a_full_set_once_and_clear_removes_it():
    with tempfile.TemporaryDirectory() as tmp:
        m, ex, store = manager(tmp)
        run(m.ensure("X", MARKET, health(), 2))
        assert [c[0] for c in ex.calls] == ["e_place", "a_place"]
        assert len(ex.e_live) == 2 and len(ex.a_live) == 2
        assert m.status()["X"]["ok"] and m.has("X")
        assert any(c["plan"] == "protect" for c in store.recent_cycles())
        run(m.ensure("X", MARKET, health(), 2))             # 没变化：不动
        assert len(ex.calls) == 2
        assert run(m.clear("X", MARKET)) is True
        assert not ex.e_live and not ex.a_live and not m.has("X")


def test_a_size_change_or_a_drifted_liquidation_replaces_the_orders():
    with tempfile.TemporaryDirectory() as tmp:
        m, ex, _ = manager(tmp)
        run(m.ensure("X", MARKET, health(), 2))
        run(m.ensure("X", MARKET, health(e_size=-20.0, a_size=20.0), 2))   # 补仓了
        assert [c[0] for c in ex.calls].count("e_place") == 2
        assert len(ex.e_live) == 2 and len(ex.a_live) == 2                  # 旧的撤了
        run(m.ensure("X", MARKET, health(e_size=-20.0, a_size=20.0, e_liq=1210.0), 2))
        assert [c[0] for c in ex.calls].count("e_place") == 3


def test_missing_orders_are_noticed_on_verification():
    with tempfile.TemporaryDirectory() as tmp:
        m, ex, _ = manager(tmp)
        run(m.ensure("X", MARKET, health(), 2))
        ex.a_live.clear()                                   # 交易所那边没了（被撤 / 触发）
        st = m.state("X")
        st["verified_at"] = 0
        m._save("X", st)
        run(m.ensure("X", MARKET, health(), 2))
        st = m.state("X")
        assert st["errors"]                                  # 记下来了，两分钟后重挂
        st["placed_at"] = 0
        m._save("X", st)
        run(m.ensure("X", MARKET, health(), 2))
        assert len(ex.a_live) == 2 and m.status()["X"]["ok"]


def test_an_async_arcus_rejection_is_reported():
    with tempfile.TemporaryDirectory() as tmp:
        m, ex, store = manager(tmp)
        ex.arcus_reject = True
        run(m.ensure("X", MARKET, health(), 2))
        assert not m.status()["X"]["ok"] and "Arcus" in m.status()["X"]["error"]
        assert any(c["plan"] == "protect_failed" for c in store.recent_cycles())


def test_engine_protects_a_hedged_position_and_clears_before_reopening():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, svc = make(tmp, row(0.2, -0.2), dry_run=False)
        ex = FakeEx()

        class Stub(FakeEx):
            pass
        eng.protect._executor = lambda: ex
        eng.protect.verify_delay = 0.0
        eng.executor = type("E", (), {"halts": None})()
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 3600, corridor_at_open=8.3)
        run(eng.run_cycle())
        assert len(ex.e_live) == 2 and len(ex.a_live) == 2
        # 两边都平了（比如保护单触发了）：下一轮先撤干净
        svc.row = row(0.0, 0.0)
        ex.a_live.add("stuck")
        st = eng.protect.state("OAI")
        st["arcus_ids"].append("stuck")
        eng.protect._save("OAI", st)
        ex_cancel = ex._arcus_cancel

        async def refuse(market, oid):
            if oid == "stuck":
                return False, "x"
            return await ex_cancel(market, oid)
        ex._arcus_cancel = refuse
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "blocked" and "保护单" in d[0]["reason"]
        ex._arcus_cancel = ex_cancel
        d = run(eng.run_cycle())
        assert not eng.protect.has("OAI")
        assert d[0]["plan"] != "blocked" or "保护单" not in d[0]["reason"]


# ── 执行器：报文 ─────────────────────────────────────────

def _executor():
    from test_execution import FakeMarket, settings
    from parallax_hedge.execution import Executor
    return Executor(settings(), FakeMarket(), dry_run=False)


def test_entropy_trigger_orders_are_reduce_only_market_triggers():
    ex = _executor()
    sent = {}

    class SDK:
        def bulk_orders(self, reqs):
            sent["reqs"] = reqs
            return {"status": "ok", "response": {"type": "order", "data": {"statuses": [
                {"resting": {"oid": 11}}, "waitingForTrigger"]}}}

    async def sdk_for(symbol):
        return SDK()

    async def open_orders():
        return [{"coin": "io:SNDK", "isTrigger": True, "side": "B", "oid": 22,
                 "triggerPx": str(sent["reqs"][1]["order_type"]["trigger"]["triggerPx"])}]
    ex._entropy_exchange_for = sdk_for
    ex._entropy_open_orders = open_orders
    oids, errors = run(ex.place_entropy_triggers("io:SNDK", [
        {"side": "buy", "kind": "sl", "size": 15.0712, "trigger": 1180.777},
        {"side": "buy", "kind": "tp", "size": 15.0712, "trigger": 1001.0111},
    ], 2))
    assert oids == ["11", "22"] and errors == []
    sl, tp = sent["reqs"]
    assert sl["reduce_only"] and tp["reduce_only"] and sl["is_buy"]
    assert sl["order_type"]["trigger"] == {"triggerPx": pytest.approx(1180.7, abs=0.11),
                                           "isMarket": True, "tpsl": "sl"}
    assert sl["order_type"]["trigger"]["triggerPx"] <= 1180.777       # 止损宁早勿晚：往下取整
    assert tp["order_type"]["trigger"]["triggerPx"] >= 1001.0111      # 止盈（买回）往上取整
    assert sl["limit_px"] > sl["order_type"]["trigger"]["triggerPx"]   # 买单滑点上限在触发价之上
    assert sl["sz"] == pytest.approx(15.07)


def test_arcus_position_tpsl_batch_is_signed_as_op4_with_zero_size():
    import json as _json
    from parallax_hedge.execution import Executor
    from test_execution import MARKET as AM
    ex = _executor()
    seen = {}

    async def post(path, body, ts, sig):
        seen.update(path=path, body=body, ts=ts, sig=sig)
        return 202, {"responses": [{"orderId": "a1", "status": "UNTRIGGERED"},
                                   {"orderId": "a2", "status": "UNTRIGGERED"}]}
    ex._arcus_post = post
    ids, errors = run(ex.place_arcus_position_tpsl(AM, "sell", 900.0, 1100.0))
    assert ids == ["a1", "a2"] and errors == []
    assert seen["path"] == "/v1/batchPlaceOrders" and seen["body"]["grouping"] == "positionTpsl"
    sl, tp = seen["body"]["orders"]
    assert (sl["tpslType"], tp["tpslType"]) == ("STOP_LOSS", "TAKE_PROFIT")
    assert sl["quantity"] == "0" and sl["reduceOnly"] and sl["orderType"] == "MARKET"
    assert sl["timeInForce"] == "IOC" and sl["isPositionTPSL"]
    assert sl["stopPrice"] == "900" or float(sl["stopPrice"]) == 900.0
    assert float(sl["price"]) == pytest.approx(855.0, abs=0.02)        # 卖出滑点上限 = 触发价 −5%
    assert sl["timestamp"] == tp["timestamp"] == seen["ts"] and seen["sig"] == sl["signature"]
    # 验签：op=4、q=0，字段和下单一样
    from parallax_hedge import arcus as ax
    key, _ = ex._get_arcus_key()
    payload = ax.build_place_payload(
        address=sl["address"], account_index=sl["accountIndex"], client_id=sl["clientId"],
        timestamp=sl["timestamp"], good_til_us_value=int(sl["goodTilTime"]),
        market_id=sl["marketId"], price_ticks=ax.to_units(ax.D(sl["price"]), AM["arcus_tick_size"]),
        quantity_quantums=0, reduce_only=True, side="SELL", time_in_force="IOC", op=4)
    assert '"op":4' in payload and '"q":0' in payload
    assert ax.sign_hex(key, payload) == sl["signature"]
