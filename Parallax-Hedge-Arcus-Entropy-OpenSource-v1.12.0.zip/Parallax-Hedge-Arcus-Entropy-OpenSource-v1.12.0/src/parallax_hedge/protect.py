"""交易所保护单（v1.10）—— 程序断网 / 电脑关机时，由两个交易所自己把两条腿一起平掉。

为什么要有它：程序在线时，任一条腿离强平 < CLOSE_CORRIDOR_PCT 就会两边一起平；
但程序一断线就没人管了。2026-11-04 SNDK 那单 Entropy 空单逐仓 10×，离强平只有约 5%，
一个晚上涨 5% 并不罕见 —— Entropy 那条腿被强平，Arcus 剩一条裸多单。

做法：每对对冲仓位在两个交易所上【成套】挂 4 张只减仓的触发单，两条边界：
    价格涨到上边界 U → 空腿止损 + 多腿止盈（两边一起平）
    价格跌到下边界 L → 多腿止损 + 空腿止盈（两边一起平）
只给受伤的那条腿挂止损，触发后另一条腿就裸奔了 —— 所以四张必须成套。

边界放在「离强平价还剩 PROTECT_LIQ_BUFFER_PCT」的位置：
  · 比程序自己的平仓线（CLOSE_CORRIDOR_PCT，默认离强平 1.5%）更靠外 —— 程序在线时永远是程序先平，
    保护单只在程序失联时才会触发；
  · 又留了一段给触发后的市价滑点，免得来不及成交就被交易所强平。

两边怎么挂：
  · Entropy（Hyperliquid）：两张普通触发单（tpsl = sl / tp，isMarket），数量 = 当前仓位；
    仓位变了（补仓）就撤掉重挂。
  · Arcus：一对「整仓止盈止损」（positionTpsl，数量填 0，触发时按当时整个仓位平），
    一个市场同时只能有一对，所以挂之前先把这个市场上已有的整仓止盈止损撤掉。

生命周期：持仓对冲好且没在开平仓 → 确保保护单在、边界没漂；空仓 → 先撤干净再允许开新仓
（只减仓单留着不会开出新仓，但下一轮如果反方向开仓，旧的只减仓单会误平新仓位）。
挂完 2 秒后去两边的挂单列表里核对，每 5 分钟再核对一次；缺了就重挂。
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import time
from dataclasses import dataclass
from typing import Any, Callable

from .positions import HedgeHealth

META_PREFIX = "protect:"
REFRESH_MOVE = 0.005        # 边界漂了 0.5% 以上才重挂（强平价会随资金费、保证金慢慢动）
VERIFY_EVERY_SEC = 300.0
RETRY_EVERY_SEC = 120.0
MIN_GAP = 0.002             # 边界离现价至少 0.2%，否则「挂上就触发」—— 那种情况程序自己的风控早该平了


@dataclass(frozen=True)
class Levels:
    upper: float
    lower: float
    long_venue: str
    short_venue: str
    long_size: float
    short_size: float


def protective_prices(health: HedgeHealth, buffer_pct: float) -> Levels | None:
    """按两条腿的强平价算上下边界。缺强平价 / 不是一多一空 / 边界已经贴着现价 → None。"""
    if not health.is_hedged:
        return None
    longs = [p for p in health.open_legs if p.size > 0]
    shorts = [p for p in health.open_legs if p.size < 0]
    if len(longs) != 1 or len(shorts) != 1:
        return None
    long_leg, short_leg = longs[0], shorts[0]
    if not (long_leg.liquidation_price and short_leg.liquidation_price
            and long_leg.mark_price and short_leg.mark_price):
        return None
    buffer = float(buffer_pct) / 100.0
    upper = float(short_leg.liquidation_price) * (1 - buffer)
    lower = float(long_leg.liquidation_price) * (1 + buffer)
    hi_mark = max(long_leg.mark_price, short_leg.mark_price)
    lo_mark = min(long_leg.mark_price, short_leg.mark_price)
    if upper <= hi_mark * (1 + MIN_GAP) or lower >= lo_mark * (1 - MIN_GAP) or lower <= 0:
        return None
    return Levels(upper, lower, long_leg.venue, short_leg.venue,
                  abs(long_leg.size), abs(short_leg.size))


def orders_for(levels: Levels) -> dict[str, list[dict[str, Any]]]:
    """每个所要挂的单：多腿卖出平仓（跌到 L 止损、涨到 U 止盈），空腿买入平仓（涨到 U 止损、跌到 L 止盈）。"""
    out: dict[str, list[dict[str, Any]]] = {}
    out[levels.long_venue] = [
        {"side": "sell", "kind": "sl", "trigger": levels.lower, "size": levels.long_size},
        {"side": "sell", "kind": "tp", "trigger": levels.upper, "size": levels.long_size},
    ]
    out[levels.short_venue] = [
        {"side": "buy", "kind": "sl", "trigger": levels.upper, "size": levels.short_size},
        {"side": "buy", "kind": "tp", "trigger": levels.lower, "size": levels.short_size},
    ]
    return out


def _moved(old: float | None, new: float) -> bool:
    return not old or abs(new - old) / old > REFRESH_MOVE


class ProtectionManager:
    def __init__(self, executor: Callable[[], Any], store: Any, settings: Any,
                 dry_run: bool = False) -> None:
        self._executor = executor          # 取当前执行器（测试里会被替换）
        self.store = store
        self.settings = settings
        self.dry_run = dry_run
        self.notes: dict[str, dict[str, Any]] = {}      # 面板展示：币种 → 状态
        self._locks: dict[str, asyncio.Lock] = {}
        self._last_log: dict[str, tuple[str, float]] = {}
        self.verify_delay = 2.0

    @property
    def ex(self) -> Any:
        return self._executor()

    # ── 状态（存在交易账本的 meta 里，重启后还认得自己挂过的单）──
    def state(self, asset: str) -> dict[str, Any] | None:
        raw = self.store.get_meta(META_PREFIX + asset)
        try:
            return json.loads(raw) if raw else None
        except ValueError:
            return None

    def _save(self, asset: str, state: dict[str, Any] | None) -> None:
        self.store.set_meta(META_PREFIX + asset, json.dumps(state) if state else "")

    def has(self, asset: str) -> bool:
        st = self.state(asset)
        return bool(st and (st.get("entropy_oids") or st.get("arcus_ids")))

    def status(self) -> dict[str, Any]:
        out = {}
        for asset, note in self.notes.items():
            out[asset] = dict(note)
        return out

    def _note(self, asset: str, **kw: Any) -> None:
        self.notes[asset] = {**kw, "at": time.time()}

    def _lock(self, asset: str) -> asyncio.Lock:
        return self._locks.setdefault(asset, asyncio.Lock())

    # ── 主流程 ──
    async def ensure(self, asset: str, market: dict[str, Any], health: HedgeHealth,
                     size_decimals: int) -> None:
        """持仓对冲好时调用：保护单不在 / 边界漂了 / 数量变了 → 撤掉重挂。出错只记状态，不抛。"""
        if self.dry_run or not self.settings.protect_orders:
            return
        async with self._lock(asset):
            try:
                await self._ensure(asset, market, health, size_decimals)
            except Exception as exc:  # noqa: BLE001 —— 保护单出错绝不能拖住交易
                self._note(asset, ok=False, error=f"保护单处理出错：{exc}"[:300])

    async def _ensure(self, asset: str, market: dict[str, Any], health: HedgeHealth,
                      size_decimals: int) -> None:
        levels = protective_prices(health, self.settings.protect_liq_buffer_pct)
        st = self.state(asset) or {}
        now = time.time()
        if levels is None:
            self._note(asset, ok=False, error="算不出保护价（缺强平价，或者已经贴着强平价 —— 程序自己的风控会处理）",
                       upper=st.get("upper"), lower=st.get("lower"))
            return
        entropy_leg = health.entropy
        need = (not st or _moved(st.get("upper"), levels.upper)
                or _moved(st.get("lower"), levels.lower)
                or (entropy_leg is not None
                    and abs(abs(entropy_leg.size) - float(st.get("entropy_size") or 0))
                    > abs(entropy_leg.size) * 0.01)
                or bool(st.get("errors")))
        if not need and now - float(st.get("verified_at") or 0) >= VERIFY_EVERY_SEC:
            missing = await self._missing(market, st)
            st["verified_at"] = now
            if missing:
                st["errors"] = [f"{m} 不在挂单列表里了" for m in missing]
                need = True
            self._save(asset, st)
        if not need:
            self._note(asset, ok=True, upper=st.get("upper"), lower=st.get("lower"),
                       verified_at=st.get("verified_at"))
            return
        if st.get("errors") and now - float(st.get("placed_at") or 0) < RETRY_EVERY_SEC:
            return                                     # 刚失败过：两分钟后再试，别刷屏
        await self._cancel(market, st)
        orders = orders_for(levels)
        errors: list[str] = []
        entropy_oids: list[str] = []
        arcus_ids: list[str] = []
        try:
            entropy_oids, errs = await self.ex.place_entropy_triggers(
                market["entropy_symbol"], orders["entropy"], size_decimals)
            errors += [f"Entropy：{e}" for e in errs]
        except Exception as exc:  # noqa: BLE001
            errors.append(f"Entropy：{exc}"[:200])
        try:
            # 一个市场只能有一对整仓止盈止损：先把已有的撤掉（多半是自己上一轮的）
            for row in await self.ex.arcus_tpsl_orders(market) or []:
                if row.get("isPositionTPSL") and row.get("orderId"):
                    await self.ex._arcus_cancel(market, str(row["orderId"]))
            arcus = {o["kind"]: o for o in orders["arcus"]}
            arcus_ids, errs = await self.ex.place_arcus_position_tpsl(
                market, arcus["sl"]["side"], arcus["sl"]["trigger"], arcus["tp"]["trigger"])
            errors += [f"Arcus：{e}" for e in errs]
        except Exception as exc:  # noqa: BLE001
            errors.append(f"Arcus：{exc}"[:200])
        st = {
            "upper": levels.upper, "lower": levels.lower,
            "entropy_size": abs(entropy_leg.size) if entropy_leg else 0.0,
            "entropy_oids": entropy_oids, "arcus_ids": arcus_ids,
            "placed_at": time.time(), "verified_at": 0.0, "errors": errors,
        }
        self._save(asset, st)
        # Arcus 的整仓止盈止损是异步受理的（202）：等两秒去挂单列表里核对，被拒的这时才看得出来
        missing: list[str] = []
        if entropy_oids or arcus_ids:
            await asyncio.sleep(self.verify_delay)
            missing = await self._missing(market, st)
        st["verified_at"] = time.time()
        if missing:
            st["errors"] = errors + [f"{m} 下单后在挂单列表里没看到（可能被交易所拒了）" for m in missing]
        self._save(asset, st)
        ok = not st["errors"] and len(entropy_oids) == 2 and len(arcus_ids) == 2
        text = (f"交易所保护单：涨到 {levels.upper:.4g} 或跌到 {levels.lower:.4g} 时两边交易所自动一起平"
                f"（Entropy {len(entropy_oids)}/2 张、Arcus {len(arcus_ids)}/2 张）")
        if not ok:
            text += "；⚠ " + "；".join(st["errors"])[:400]
        # 同样的失败每两分钟重试一次，但执行记录 30 分钟内只写一条
        key = "ok" if ok else "；".join(st["errors"])
        last = self._last_log.get(asset)
        if ok or last is None or last[0] != key or time.time() - last[1] > 1800:
            self._last_log[asset] = (key, time.time())
            with contextlib.suppress(Exception):
                self.store.log_cycle(asset, "protect" if ok else "protect_failed", text,
                                     urgent=not ok, dry_run=False)
        self._note(asset, ok=ok, upper=levels.upper, lower=levels.lower,
                   verified_at=st["verified_at"], error=None if ok else "；".join(st["errors"])[:300])

    async def clear(self, asset: str, market: dict[str, Any]) -> bool:
        """空仓时撤掉这个币的保护单。返回 True = 撤干净了（可以开新仓）。"""
        if self.dry_run:
            return True
        async with self._lock(asset):
            st = self.state(asset)
            if not st:
                return True
            try:
                left = await self._cancel(market, st)
            except Exception as exc:  # noqa: BLE001
                self._note(asset, ok=False, error=f"撤保护单出错：{exc}"[:300])
                return False
            if left:
                st["entropy_oids"] = [o for o in st.get("entropy_oids") or [] if o in left]
                st["arcus_ids"] = [o for o in st.get("arcus_ids") or [] if o in left]
                self._save(asset, st)
                self._note(asset, ok=False, error=f"还有 {len(left)} 张保护单没撤掉，下一轮再撤")
                return False
            self._save(asset, None)
            self.notes.pop(asset, None)
            with contextlib.suppress(Exception):
                self.store.log_cycle(asset, "protect_cleared", "已空仓，交易所保护单已撤",
                                     dry_run=False)
            return True

    async def _cancel(self, market: dict[str, Any], st: dict[str, Any]) -> set[str]:
        """撤掉记录里的单；返回撤完以后仍然挂着的订单号。"""
        for oid in st.get("entropy_oids") or []:
            with contextlib.suppress(Exception):
                await self.ex.cancel_entropy_order(market["entropy_symbol"], oid)
        for oid in st.get("arcus_ids") or []:
            with contextlib.suppress(Exception):
                await self.ex._arcus_cancel(market, oid)
        if not (st.get("entropy_oids") or st.get("arcus_ids")):
            return set()
        await asyncio.sleep(self.verify_delay / 2)
        left: set[str] = set()
        live_e = await self.ex.entropy_trigger_oids(market["entropy_symbol"])
        if live_e is not None:
            left |= {o for o in st.get("entropy_oids") or [] if o in live_e}
        rows = await self.ex.arcus_tpsl_orders(market)
        if rows is not None:
            live_a = {str(r.get("orderId")) for r in rows}
            left |= {o for o in st.get("arcus_ids") or [] if o in live_a}
        return left

    async def _missing(self, market: dict[str, Any], st: dict[str, Any]) -> list[str]:
        """记录里有、交易所挂单列表里没有的单（读不到列表时不算缺）。"""
        missing: list[str] = []
        live_e = await self.ex.entropy_trigger_oids(market["entropy_symbol"])
        if live_e is not None:
            missing += [f"Entropy 触发单 {o}" for o in st.get("entropy_oids") or [] if o not in live_e]
            if len(st.get("entropy_oids") or []) < 2:
                missing.append("Entropy 保护单不全")
        rows = await self.ex.arcus_tpsl_orders(market)
        if rows is not None:
            live_a = {str(r.get("orderId")) for r in rows}
            missing += [f"Arcus 止盈止损 {o}" for o in st.get("arcus_ids") or [] if o not in live_a]
            if len(st.get("arcus_ids") or []) < 2:
                missing.append("Arcus 保护单不全")
        return missing
