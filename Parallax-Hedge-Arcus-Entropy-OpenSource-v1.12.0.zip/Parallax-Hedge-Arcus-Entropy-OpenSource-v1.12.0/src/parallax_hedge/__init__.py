"""Parallax Hedge · Arcus × Entropy —— 对冲刷量控制台。"""

__version__ = "1.12.0"
