"""对冲刷量引擎 —— 把各层接起来跑。

每个周期对每个任务走一遍：
    快照（费率 + 持仓）→ 风控裁决 → 开仓前预检 → 调度决策 → 执行

所有决策逻辑都在 risk.py / scheduler.py 那些纯函数里，这里只负责
取数据、调用、落库。这样决策部分能离线测透，而这一层的 bug 只会是
接线错误，不会是判断错误。
"""
from __future__ import annotations

import asyncio
import contextlib
import math
import random
import time
from typing import Any

from .accounts import arcus_balance, entropy_balance
from .arcus import account_exposure
from .config import Settings
from .books import (
    basis_bps,
    executable_prices,
    max_quantity_within_cost,
    round_trip_cost_bps,
)
from .execution import Executor, PairResult
from .fills import align_quantity, closing_sides, hedge_side
from .guards import (
    REDUCE_ONLY_GONE,
    VENUE_LABEL,
    VenueHalts,
    orphan_slippage_bps,
    plan_blocked_by_halt,
    take_profit_estimate,
)
from .funding import choose_direction
from .positions import HedgeHealth
from .risk import (
    DEFAULT_MIN_CORRIDOR_PCT,
    PreOpenDecision,
    effective_leverages,
    evaluate,
    fit_quantity,
    max_quantity_for,
    pre_open_check,
    sizing_limit,
    verify_corridor_after_open,
)
from .ledger import ledger_rows_for_result
from .scheduler import CycleDecision, TaskState, decide, draw_hold_hours
from .service import FundingService
from .store import DEFAULT_ARCUS_FEE_RATE, DEFAULT_ENTROPY_FEE_RATE, Store, rebate_fraction

# 两个所：下单通道熔断判断「这个动作会不会碰到失效的所」时用
VENUES = ("entropy", "arcus")
# Arcus 美股等 RWA 合约盘后有「价格带」：价格贴着带边时，往带外成交的单一律被拒
# （FILL_WILL_EXCEED_TRADING_BOUND）。碰到一次就暂停这个币的开仓 / 到期平仓一段时间。
ARCUS_BOUND_ERROR = "TRADING_BOUND"
# 熔断期间同一个币种「暂停开平仓」的记录多久写一条（秒）—— 每 20 秒一条会把执行记录刷屏
HALT_LOG_EVERY_SEC = 300.0
# 平仓手续费按吃单估（止盈平仓一律吃单，不挂单等）
CLOSE_FEE_RATES = {"arcus": DEFAULT_ARCUS_FEE_RATE, "entropy": DEFAULT_ENTROPY_FEE_RATE}

# 开仓后复核的重试节奏：两所的账户接口偶尔要几秒才反映新仓位。
# 累计约 1.5+3+4.5+6+7.5 = 22.5 秒，足够覆盖正常的结算延迟。
_VERIFY_ATTEMPTS = 5
_VERIFY_DELAY_SEC = 1.5

# 开仓前两所中价最多允许差多少（bps）。正常的跨所基差是个位数到几十 bps；
# 差到 3% 以上，基本是配错了标的（同名不同物、1000 倍合约）或者一边盘口坏了。
MAX_OPEN_BASIS_BPS = 300.0

# 持仓期间挂单补仓（v1.3）：挂单只开出一部分时，后面每一轮继续挂单，补到这一轮的目标数量。
# 离轮换平仓不到「挂单等待时长 + 这么多秒」就不再补 —— 刚补上就要平，白白多一次往返
TOPUP_MIN_LEFT_SEC = 300.0
# 差额小于目标的这个比例就不补了（零头不值得挂单，也可能低于最小下单量）
TOPUP_MIN_FRACTION = 0.02
# 叫停补仓后最多等多久让它收尾（撤单 + 把已成交的对冲完）
TOPUP_STOP_WAIT_SEC = 20.0


class HedgeEngine:
    def __init__(
        self, settings: Settings, service: FundingService, store: Store,
        *, dry_run: bool = True,
    ) -> None:
        self.settings = settings
        self.service = service
        self.store = store
        self.dry_run = dry_run
        self.executor = Executor(settings, service.client, dry_run=dry_run)
        self._lock = asyncio.Lock()
        self.last_cycle_at: float | None = None
        self.last_decisions: list[dict[str, Any]] = []
        # 随机轮换用的随机源。单独一个实例，测试里可以换成固定种子。
        self.rng = random.Random()
        # 上一轮 Arcus 账户里有仓位的币种 —— 组合一变就重设各任务的走廊基准
        self._arcus_composition: frozenset[str] | None = None
        # 后台挂单任务（币种 → asyncio 任务）；门铃由 api 启动时注入
        self._jobs: dict[str, asyncio.Future] = {}
        self._job_kind: dict[str, str] = {}
        self._stops: dict[str, asyncio.Event] = {}
        # 补仓完成后，下一轮要重设各任务的强平距离基准（仓位变大是机械变化，不是行情）
        self._rebase_note: str | None = None
        self.bell = None
        self._announced_halts: set[str] = set()
        # v1.8：孤腿连续平不掉的次数（币种 → 次数），用来逐级放宽滑点
        self._orphan_fail: dict[str, int] = {}
        # v1.8：熔断期间每个币种上一次写「暂停」记录的时间
        self._halt_logged: dict[str, float] = {}
        # v1.8：面板上展示的最近一次止盈估算（币种 → 文本）
        self.take_profit_view: dict[str, dict[str, Any]] = {}
        # v1.9 基差监控（api 启动时注入；没有就不择时）与择时开仓的等待起点
        self.basis = None
        self._entry_wait_since: dict[str, float] = {}
        self._exit_wait_since: dict[str, float] = {}
        # v1.11.1 Arcus 盘后价格带：币种 → 暂停到什么时候
        self._arcus_bound_until: dict[str, float] = {}
        # v1.10 交易所保护单（执行器用取值函数传进去：测试里会替换 self.executor）
        from .protect import ProtectionManager
        self.protect = ProtectionManager(lambda: self.executor, store, settings, dry_run=dry_run)

    async def aclose(self) -> None:
        # 关程序时挂单任务还在跑：取消它（任务会尽力撤掉 Arcus 上的挂单）
        for job in self._jobs.values():
            if not job.done():
                job.cancel()
        for job in self._jobs.values():
            with contextlib.suppress(BaseException):
                await job
        await self.executor.aclose()

    # ── 一个周期 ────────────────────────────────────
    async def run_cycle(self) -> list[dict[str, Any]]:
        async with self._lock:
            return await self._run_cycle()

    async def _run_cycle(self) -> list[dict[str, Any]]:
        now = time.time()
        await self._probe_halts()
        snapshot = await self.service.refresh()
        rows = {r["asset"]: r for r in snapshot.get("rows", [])}
        markets = {m["asset"]: m for m in await self.service.client.common_markets()}
        mmf_by_market = {
            int(m["arcus_market_id"]): float(m["arcus_mmf"])
            for m in markets.values() if m.get("arcus_mmf") and m.get("arcus_market_id") is not None
        }
        decisions: list[dict[str, Any]] = []
        # 任何一边的账户读取失败，那一边的腿在快照里就是「空」—— 和真的空仓分不出来。
        # 这时候按快照做决定，会把一条健康的腿当成孤腿市价平掉（另一边反而成了裸腿），
        # 或者把还在的仓位当成「已经不在了」清掉状态。所以这一轮什么都不做，等下一轮。
        account_errors = (snapshot.get("accounts") or {}).get("errors") or {}
        if not account_errors and not self.dry_run:
            self._rebase_on_composition_change(rows)

        for task_row in self.store.list_tasks():
            # 每个任务单独兜底：一个任务出错（比如某个所连不上）不能让这一轮里
            # 其它任务的风控检查、孤腿抢救也跟着停掉（2026-10-01 QQQ 裸腿 26 分钟就是这么来的）
            try:
                await self._cycle_task(task_row, rows, markets, mmf_by_market, decisions,
                                       account_errors, now)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                asset = task_row.get("asset", "-")
                reason = f"本轮处理出错（其它币种照常检查）：{exc}"[:300]
                decisions.append({"asset": asset, "plan": "error", "reason": reason,
                                  "urgent": True, "result": None})
                with contextlib.suppress(Exception):
                    self.store.log_cycle(asset, "error", reason, dry_run=self.dry_run)

        self.last_cycle_at = now
        self.last_decisions = decisions
        return decisions

    async def _cycle_task(self, task_row: dict[str, Any], rows: dict[str, Any],
                          markets: dict[str, Any], mmf_by_market: dict[int, float],
                          decisions: list[dict[str, Any]], account_errors: dict[str, Any],
                          now: float) -> None:
        """一个任务这一轮的全部判断与动作。"""
        asset = task_row["asset"]
        job = self._jobs.get(asset)
        if job is not None and not job.done():
            # 挂单任务还在跑：仓位正在一点点建 / 平，这时候不能拿它做判断
            # （半建好的仓位看起来就是「两腿不匹配」）。任务自己负责兜底。
            # 例外：补仓任务可能一直在跑，风控不能因此停摆 —— 每一轮照样看
            # 强平距离 / 到期 / 停用，需要处理就叫停补仓，等它收尾后按最新仓位走正常流程。
            why = None
            if self._job_kind.get(asset) == "topup" and not account_errors:
                why = self._topup_should_stop(task_row, rows.get(asset), now)
            if why is None and self.halts.any():
                why = self.halts.describe()
            if why is None:
                kind = "挂单补仓中" if self._job_kind.get(asset) == "topup" else "挂单任务进行中"
                decisions.append({"asset": asset, "plan": "maker_busy",
                                  "reason": f"{kind}（Arcus 成交多少立刻在 Entropy 对冲多少）",
                                  "urgent": False, "result": None})
                return
            self._stops[asset].set()
            with contextlib.suppress(Exception):
                await asyncio.wait_for(asyncio.shield(job), TOPUP_STOP_WAIT_SEC)
            if not job.done():
                decisions.append({"asset": asset, "plan": "maker_busy",
                                  "reason": f"已叫停补仓（{why}），等它收尾",
                                  "urgent": False, "result": None})
                return
            self.store.log_cycle(asset, "topup_stop", f"叫停补仓：{why}",
                                 dry_run=self.dry_run)
            # 收尾期间仓位变了：重读一次再判断
            fresh = await self.service.refresh()
            if (fresh.get("accounts") or {}).get("errors"):
                return
            for r in fresh.get("rows", []):
                if r["asset"] == asset:
                    rows[asset] = r
            task_row = self.store.get_task(asset) or task_row
        else:
            # 后台挂单任务可能在这一轮开始之后、走到这个币之前刚好收尾（开完或平完）：
            # 这时库里的状态是新的，而本轮的持仓快照还是旧的。拿新旧混在一起判断会出错 ——
            # 2026-11-03 20:28:56 SNDK 刚开完仓，4 秒后被当成「外来仓位」又接管了一次，
            # 持有时长被重抽、开仓时的强平距离基准也丢了。反过来还可能把刚开的仓当成「已经不在了」。
            # 所以状态在这一轮里变过的币，这一轮跳过，下一轮按最新仓位判断。
            fresh_task = self.store.get_task(asset)
            if fresh_task and any(fresh_task.get(k) != task_row.get(k)
                                  for k in ("opened_at", "last_closed_at", "open_quantity")):
                decisions.append({"asset": asset, "plan": "maker_busy",
                                  "reason": "刚完成一次开 / 平仓，下一轮按最新仓位判断",
                                  "urgent": False, "result": None})
                return
        row = rows.get(asset)
        market = markets.get(asset)
        if row is None or market is None:
            decisions.append({"asset": asset, "plan": "blocked",
                              "reason": "该币种当前不在两所共有列表里"})
            return
        if account_errors and not self.dry_run:
            reason = (
                f"{'、'.join(sorted(account_errors))} 账户读取失败，持仓状态未知"
                f" —— 本轮不做任何动作，下一轮重试"
            )
            decisions.append({"asset": asset, "plan": "blocked", "reason": reason})
            self.store.log_cycle(asset, "blocked", reason, dry_run=self.dry_run)
            return

        health = self._health_for(asset, row)
        corridor_at_open = task_row.get("corridor_at_open")
        # 演练模式下不会产生真实仓位，但调度器是按【真实仓位】判断
        # 有没有持仓的 —— 不补这一步，每一轮都会认为自己空仓而重复开仓，
        # 「持仓 → 到期 → 平仓」这条链就永远验不到。
        if self.dry_run:
            simulated = self._simulated_health(task_row, asset, price_hint=row.get("mark_price"))
            if simulated is not None:
                health = simulated
        elif task_row.get("opened_at") and not health.open_legs:
            # 实盘下库里记着有仓、两边却都读不到：仓位已经不在了
            # （手动平掉 / 被强平 / 当初那次开仓其实没成）。
            # 必须在【决策之前】清掉，否则调度器看到「空仓」会当场又开一个新仓，
            # 陈旧状态被覆盖、冷却期也永远不生效。清掉后冷却自然接管。
            self.store.mark_closed(asset)
            task_row = self.store.get_task(asset) or task_row
            corridor_at_open = None
        elif (task_row.get("enabled") and not task_row.get("opened_at")
                and health.is_hedged):
            # 有一对对冲好的仓位，库里却没有开仓记录（手动开的 / 回撤平仓失败 /
            # 以前被误清掉的）。不接管的话调度器只会一直「闲置」，这对仓位
            # 永远不会被轮换。接管 = 从现在开始计时，按任务设置抽一个持有时长。
            hold = draw_hold_hours(
                float(task_row.get("rotation_hours") or 4.0),
                task_row.get("rotation_hours_max"), self.rng,
            )
            entropy_leg = health.entropy
            direction = (
                "long_entropy_short_arcus"
                if entropy_leg is not None and entropy_leg.size > 0
                else "short_entropy_long_arcus"
            )
            self.store.mark_opened(
                asset, direction=direction,
                quantity=abs(entropy_leg.size) if entropy_leg else 0.0,
                corridor_pct=None, hold_hours=hold,
            )
            task_row = self.store.get_task(asset) or task_row
            self.store.log_cycle(
                asset, "adopt",
                f"接管已有对冲仓位，从现在开始计时（本轮持有 {hold:.2f} 小时）",
                dry_run=self.dry_run,
            )
        if (not self.dry_run and self.settings.protect_orders and not health.open_legs
                and self.protect.has(asset)):
            # 空仓了：先把上一轮的交易所保护单撤干净再说。只减仓单留着不会开出新仓，
            # 但下一轮如果反方向开仓，旧的只减仓单会把新仓位误平掉。
            if not await self.protect.clear(asset, market):
                reason = "上一轮的交易所保护单还没撤干净，先不开新仓（下一轮再撤）"
                decisions.append({"asset": asset, "plan": "blocked", "reason": reason})
                return
        risk = evaluate(
            health,
            corridor_at_open_pct=corridor_at_open,
            min_corridor_pct=self.settings.close_corridor_pct,
        )

        # 开仓所需的数量与预检
        price = self._mark_for(health, row)
        leverage = float(task_row["leverage"] or 1.0)
        quantity, pre = 0.0, None
        available: tuple[float, float] | None = None
        leverages: tuple[int, int] | None = None
        sizing: str | None = None
        if not health.open_legs and price:
            entropy_avail, arcus_avail, arcus_acct = await self._available(with_arcus=True)
            available = (entropy_avail, arcus_avail)
            # Arcus 全仓：走廊看账户权益和账户里已有的 Arcus 仓位
            arcus_equity, other_notional, other_mm = account_exposure(
                arcus_acct, mmf_by_market, exclude_market=int(market["arcus_market_id"]))
            # 两边真正会设的杠杆（任务值，各自不超过该所上限）。
            # 数量和保证金检查都按它算 —— 按任务值算而交易所实际用的是别的杠杆，
            # 就是 2026-09-19 SNDK 只开出一半的原因。
            leverages = effective_leverages(
                leverage, arcus_max=float(market["max_leverage"]),
                entropy_max=await self._entropy_max_leverage(market),
                entropy_mmf=market.get("entropy_mmf"),
                min_corridor_pct=self.settings.min_corridor_pct,
            )
            quantity = max_quantity_for(
                leverage=leverage, price=price,
                entropy_available=entropy_avail, arcus_available=arcus_avail,
                quantity_decimals=market["quantity_decimals"],
                entropy_leverage=leverages[0], arcus_leverage=leverages[1],
            )
            notional_cap = self._draw_notional(task_row)
            if notional_cap:
                # 名义上限截断后【必须重新对齐到精度档位】。
                # 200/1588.7 = 0.12588909… 这种数会被交易所直接拒单 ——
                # 历史数据里「Entropy 数量最多支持 4 位小数」出现过 2433 次，
                # 就是这类没对齐的数量。max_quantity_for 内部已经对齐过，
                # 但截断这一步会把它破坏掉。
                capped = notional_cap / price
                quantity = align_quantity(
                    min(quantity, capped), int(market["quantity_decimals"])
                )
            # 数量是被谁卡住的（名义上限 / 哪一边的可用保证金）—— 写进开仓记录
            sizing = sizing_limit(
                price=price, entropy_available=entropy_avail,
                arcus_available=arcus_avail,
                entropy_leverage=leverages[0], arcus_leverage=leverages[1],
                notional_cap=notional_cap,
            )
            lo, hi = task_row.get("notional_usdc"), task_row.get("notional_usdc_max")
            if sizing and notional_cap and lo and hi and float(hi) > float(lo) \
                    and sizing.startswith("按名义上限"):
                sizing = (f"按本轮随机金额 {notional_cap:.0f} USDC"
                          f"（区间 {float(lo):g}–{float(hi):g}）")
            def check(q: float):
                return pre_open_check(
                    leverage=leverage, max_leverage=float(market["max_leverage"]),
                    quantity=q, price=price,
                    min_quantity=market["min_base_quantity"],
                    entropy_available=entropy_avail, arcus_available=arcus_avail,
                    min_corridor_pct=self.settings.min_corridor_pct,
                    entropy_leverage=leverages[0], arcus_leverage=leverages[1],
                    maintenance_fraction=market.get("arcus_mmf"),
                    min_notional=market.get("min_notional"),
                    arcus_equity=arcus_equity,
                    arcus_other_notional=other_notional,
                    arcus_other_maintenance=other_mm,
                    entropy_maintenance_fraction=market.get("entropy_mmf"),
                    entropy_max_leverage=market.get("entropy_max_leverage"),
                )

            pre = check(quantity)
            quantity, pre, fitted = self._fit_to_funds(
                task_row, market, price, quantity, pre, check)
            if fitted:
                sizing = fitted
            if pre is not None and pre.ok and quantity > 0 and self.settings.depth_cost_cap_bps > 0:
                capped, depth_note = await self._depth_cap(task_row, market, price, quantity)
                if capped != quantity:
                    quantity, pre = capped, check(capped)
                if depth_note:
                    sizing = f"{sizing}；{depth_note}" if sizing else depth_note

        choice = self._choice_for(row)
        state = TaskState(
            asset=asset,
            enabled=bool(task_row["enabled"]),
            rotation_hours=float(task_row["rotation_hours"] or 4.0),
            rotation_hours_max=task_row.get("rotation_hours_max"),
            hold_hours=task_row.get("hold_hours"),
            leverage=leverage,
            opened_at=task_row.get("opened_at"),
            corridor_at_open_pct=corridor_at_open,
            last_closed_at=task_row.get("last_closed_at"),
            cooldown_seconds=self.settings.reopen_cooldown_seconds,
        )
        decision = decide(
            task=state, health=health, risk=risk, choice=choice,
            pre_open=pre, quantity=quantity, now=now,
        )
        topup_note = None
        if (decision.plan == "idle" and health.open_legs and risk.action == "none"
                and self._arcus_bound_until.get(asset, 0.0) <= now):
            # v1.8 浮盈止盈：开仓时吃掉的价差回来了、扣完手续费还是赚 → 现在就平，进入新一轮
            tp = await self._take_profit_check(task_row, market, health, now)
            if tp is not None:
                decision = tp
        if decision.plan == "idle" and health.open_legs:
            topup, topup_note = await self._topup_decision(
                task_row, market, health, risk, state, price, mmf_by_market, now)
            if topup is not None:
                decision = topup
        view = self.take_profit_view.get(asset)
        if decision.plan == "idle" and view and not topup_note:
            topup_note = (f"止盈估算：两边现在平掉净 {view['net']:+.2f} USDC"
                          f"（超过 {view['threshold']:.2f} 就平）")
        blocked_by = plan_blocked_by_halt(decision.plan, decision.orphan_venue,
                                          self.halts, VENUES)
        if blocked_by:
            decisions.append({"asset": asset, "plan": "halted", "reason": blocked_by,
                              "urgent": True, "result": None})
            last = self._halt_logged.get(asset, 0.0)
            if now - last >= HALT_LOG_EVERY_SEC:
                self._halt_logged[asset] = now
                self.store.log_cycle(asset, "halted", f"{blocked_by}；本来要做：{decision.reason}",
                                     urgent=True, dry_run=self.dry_run)
            return
        bound_left = self._arcus_bound_until.get(asset, 0.0) - now
        if bound_left > 0 and (decision.plan in ("open", "topup")
                               or (decision.plan == "close" and decision.timed)):
            what = "到期平仓" if decision.plan == "close" else "开仓"
            decisions.append({"asset": asset, "plan": "idle", "urgent": False, "result": None,
                              "reason": (f"Arcus 盘后价格带：刚才有单被以 FILL_WILL_EXCEED_TRADING_BOUND 拒掉，"
                                         f"暂停{what}，{bound_left / 60:.0f} 分钟后再试（风控平仓不受影响）")})
            return
        timing_note = None
        if not (decision.plan == "close" and decision.timed):
            self._exit_wait_since.pop(asset, None)
        else:
            waiting, timing_note = self._exit_timing(asset, health, now)
            if waiting:
                decisions.append({"asset": asset, "plan": "idle", "reason": timing_note,
                                  "urgent": False, "result": None})
                if (health.is_hedged and not self.dry_run and self.settings.protect_orders
                        and not self.halts.any()):
                    # 等平仓的这段时间仓位还在：交易所保护单照常维护
                    await self.protect.ensure(asset, market, health,
                                              (await self._entropy_decimals(market))[0])
                return
        if health.open_legs or decision.plan != "open":
            self._entry_wait_since.pop(asset, None)
        else:
            waiting, timing_note = self._entry_timing(asset, decision, now)
            if waiting:
                decisions.append({"asset": asset, "plan": "idle", "reason": timing_note,
                                  "urgent": False, "result": None})
                return
        # 随机轮换：在【开仓这一刻】抽一次持有时长并落库，之后不再重抽
        hold = (
            draw_hold_hours(state.rotation_hours, state.rotation_hours_max, self.rng)
            if decision.plan == "open" else None
        )
        reason = decision.reason
        if topup_note:
            reason = f"{reason}；{topup_note}"
        if timing_note:
            reason = f"{reason}；{timing_note}"
        # 数量为 0 时把两边余额写进理由 —— 光说「数量 0」没法排查
        if decision.plan == "blocked" and available and quantity <= 0:
            reason = (
                f"{reason}（Entropy 可用 {available[0]:.2f} / "
                f"Arcus 可用 {available[1]:.2f} USDC，价格 {price or 0:.4f}）"
            )
        if (decision.plan == "idle" and health.is_hedged and not self.dry_run
                and self.settings.protect_orders and not self.halts.any()):
            await self.protect.ensure(asset, market, health,
                                      (await self._entropy_decimals(market))[0])
        if self._runs_as_maker(decision, task_row):
            # 挂单要等成交（最多 MAKER_WAIT_SECONDS 秒）：放到后台跑，
            # 引擎照常每 20 秒检查其它币种的风控，不被这一个币拖住
            stop = asyncio.Event()
            self._stops[asset] = stop
            self._job_kind[asset] = decision.plan
            self._jobs[asset] = asyncio.ensure_future(self._maker_job(
                decision, market, health, row, price, pre, hold, leverages,
                available, sizing, reason, stop,
            ))
            decisions.append({"asset": asset, "plan": "maker_started",
                              "reason": f"{reason}（挂单进行中）", "urgent": False,
                              "result": None})
            return
        result = await self._apply(decision, market, health, row, price, pre,
                                   hold_hours=hold, leverages=leverages)
        decisions.append(self._finish(asset, market, decision, result, reason,
                                      available, sizing))

    # ── v1.8 下单通道熔断 ──────────────────────────
    @property
    def halts(self) -> VenueHalts:
        halts = getattr(self.executor, "halts", None)
        if halts is None:                       # 测试里替换进来的假执行器没有熔断表
            halts = self.__dict__.setdefault("_fallback_halts", VenueHalts())
        return halts

    async def _probe_halts(self) -> None:
        """熔断中的所每 5 分钟自动核对一次钥匙；核对通过就解除熔断，恢复开平仓。"""
        halts = self.halts
        for venue in halts.due_for_probe():
            try:
                ok, why = await self.executor.probe(venue)
            except Exception as exc:  # noqa: BLE001
                ok, why = False, str(exc)
            if ok and halts.clear(venue):
                with contextlib.suppress(Exception):
                    self.store.log_cycle("-", "halt_cleared",
                                         f"{VENUE_LABEL.get(venue, venue)} 下单通道核对通过（{why}），"
                                         f"恢复开平仓", dry_run=self.dry_run)

    def resume_trading(self) -> list[str]:
        """面板上的「我已处理，恢复交易」：清掉全部熔断。真没修好的话下一次被拒会再触发。"""
        cleared = self.halts.clear()
        if cleared:
            with contextlib.suppress(Exception):
                self.store.log_cycle(
                    "-", "halt_cleared",
                    "手动恢复交易：" + "、".join(VENUE_LABEL.get(v, v) for v in cleared),
                    dry_run=self.dry_run)
        self._halt_logged.clear()
        return cleared

    def _note_halts(self, asset: str, result: PairResult | None) -> None:
        """动作结束后：这次有没有把某个所的熔断触发起来。新触发的写一条醒目的执行记录。"""
        halts = self.halts
        for venue in VENUES:
            if halts.is_halted(venue) and venue not in self._announced_halts:
                self._announced_halts.add(venue)
                with contextlib.suppress(Exception):
                    self.store.log_cycle(
                        asset, "halted",
                        f"⚠ {halts.describe()} —— 已暂停所有开平仓，两腿保持现状。"
                        f"请到交易所检查 API 钱包 / 密钥，处理好后在面板上点「恢复交易」"
                        f"（程序每 5 分钟也会自动核对一次）",
                        urgent=True, dry_run=self.dry_run)
        self._announced_halts &= {v for v in VENUES if halts.is_halted(v)}

    # ── v1.9 择时开仓 ──────────────────────────────
    def _entry_timing(self, asset: str, decision: CycleDecision,
                      now: float) -> tuple[bool, str | None]:
        """方向已按资金费选好：基差偏到对这个方向有利再开，最多等 ENTRY_MAX_WAIT_MINUTES。

        返回 (还要等吗, 说明)。基差数据不够（刚启动、盘口断了）就不等，照常开。
        """
        settings = self.settings
        if not settings.entry_timing or self.basis is None or not decision.direction:
            return False, None
        edge = self.basis.entry_check(asset, decision.direction)
        if edge is None:
            self._entry_wait_since.pop(asset, None)
            return False, "择时：基差数据还不够，按现价开"
        since = self._entry_wait_since.setdefault(asset, now)
        waited = (now - since) / 60
        limit = float(settings.entry_max_wait_minutes)
        detail = (f"1 分钟平均基差 {edge['mid']:+.1f} bps，近 {self.basis.window_hours:g} 小时平均 "
                  f"{edge['mean']:+.1f}，对本方向有利 {edge['favor']:+.1f} bps")
        if edge["favor"] >= settings.entry_edge_bps:
            self._entry_wait_since.pop(asset, None)
            return False, f"择时：{detail}（≥ {settings.entry_edge_bps:g}），等了 {waited:.0f} 分钟"
        if waited >= limit:
            self._entry_wait_since.pop(asset, None)
            return False, f"择时：等满 {limit:g} 分钟没等到，按现价开（{detail}）"
        return True, (f"择时开仓等待中：{detail}，要 ≥ {settings.entry_edge_bps:g} 才开"
                      f"（已等 {waited:.0f}/{limit:g} 分钟）")

    def _exit_timing(self, asset: str, health: HedgeHealth,
                     now: float) -> tuple[bool, str | None]:
        """持有到期了：等 1 分钟平均基差偏到对平仓有利再平，最多 EXIT_MAX_WAIT_MINUTES。

        平掉「Entropy 多」= 卖 Entropy、买 Arcus，和开一个「Entropy 空」同方向，所以直接复用开仓的判断。
        """
        settings = self.settings
        entropy_leg = health.entropy
        if (not settings.exit_timing or self.basis is None or entropy_leg is None
                or not entropy_leg.is_open):
            return False, None
        closing_as = ("short_entropy_long_arcus" if entropy_leg.size > 0
                      else "long_entropy_short_arcus")
        edge = self.basis.entry_check(asset, closing_as)
        if edge is None:
            self._exit_wait_since.pop(asset, None)
            return False, "择时平仓：基差数据不够，按现价平"
        since = self._exit_wait_since.setdefault(asset, now)
        waited = (now - since) / 60
        limit = float(settings.exit_max_wait_minutes)
        detail = (f"1 分钟平均基差 {edge['mid']:+.1f} bps，近 {self.basis.window_hours:g} 小时平均 "
                  f"{edge['mean']:+.1f}，对平仓有利 {edge['favor']:+.1f} bps")
        if edge["favor"] >= settings.exit_edge_bps:
            self._exit_wait_since.pop(asset, None)
            return False, f"择时平仓：{detail}（≥ {settings.exit_edge_bps:g}），等了 {waited:.0f} 分钟"
        if waited >= limit:
            self._exit_wait_since.pop(asset, None)
            return False, f"择时平仓：等满 {limit:g} 分钟没等到，按现价平（{detail}）"
        return True, (f"到期了，择时平仓等待中：{detail}，要 ≥ {settings.exit_edge_bps:g} 才平"
                      f"（已等 {waited:.0f}/{limit:g} 分钟；风控照常）")

    # ── v1.8 浮盈止盈 ──────────────────────────────
    def _fee_rates_now(self) -> dict[str, float]:
        """止盈用的吃单费率：Entropy 扣掉当前层级的返佣（T4 返 100% = 实际 0）。"""
        rebate = rebate_fraction(self.store.entropy_tier_history(), time.time())
        return {"arcus": CLOSE_FEE_RATES["arcus"],
                "entropy": CLOSE_FEE_RATES["entropy"] * max(0.0, 1.0 - rebate)}

    def _open_fees(self, asset: str, opened_at: float, health: HedgeHealth) -> float:
        """这一轮开仓（含补仓）已经付掉的手续费。

        账本里有手续费的按真实值；还没对上账的、或账本里没有的数量（接管的仓位）
        按吃单费率估 —— 宁可高估，也不让止盈过早触发。
        """
        history = self.store.entropy_tier_history()
        rates = self._fee_rates_now()
        rows = self.store.conn.execute(
            "SELECT venue, quantity, price, fee, created_at FROM fills WHERE asset=? AND dry_run=?"
            " AND created_at>=? AND action NOT IN ('close','backout','orphan')",
            (asset, int(self.dry_run), float(opened_at) - 120.0),
        ).fetchall()
        total = 0.0
        covered = {"entropy": 0.0, "arcus": 0.0}
        for venue, qty, px, fee, created in rows:
            qty, px = float(qty or 0), float(px or 0)
            if venue not in covered or qty <= 0:
                continue
            covered[venue] += qty
            if fee is None:
                total += qty * px * rates[venue]
            elif venue == "entropy":
                # Entropy 的手续费按成交当时的层级返还（v1.9.1：以前没扣返佣，止盈门槛偏高）
                total += float(fee) * max(0.0, 1.0 - rebate_fraction(history, created))
            else:
                total += float(fee)
        for venue, leg in (("entropy", health.entropy), ("arcus", health.arcus)):
            if leg is None:
                continue
            missing = abs(leg.size) - covered[venue]
            if missing > abs(leg.size) * 0.01:
                px = float(leg.entry_price or leg.mark_price or 0)
                total += missing * px * rates[venue]
        return total

    async def _take_profit_check(self, task_row: dict[str, Any], market: dict[str, Any],
                                 health: HedgeHealth, now: float) -> CycleDecision | None:
        """两腿按「现在能吃到的价格」平掉，扣掉开平仓手续费还是净赚 → 立刻两边一起平。"""
        asset = market["asset"]
        settings = self.settings
        opened_at = task_row.get("opened_at")
        if (self.dry_run or not settings.take_profit_enabled or not opened_at
                or not health.is_hedged or health.entropy is None or health.arcus is None):
            self.take_profit_view.pop(asset, None)
            return None
        if now - float(opened_at) < settings.take_profit_min_hold_seconds:
            return None
        books = await self._books(market)
        if books is None:
            return None
        entropy_size, arcus_size = health.entropy.size, health.arcus.size
        entropy_side, arcus_side = closing_sides(entropy_size, arcus_size)
        e_px = executable_prices(books[0], books[1], entropy_side=entropy_side,
                                 arcus_side=arcus_side, quantity=abs(entropy_size))[0]
        a_px = executable_prices(books[0], books[1], entropy_side=entropy_side,
                                 arcus_side=arcus_side, quantity=abs(arcus_size))[1]
        est = take_profit_estimate(
            [("entropy", entropy_size, health.entropy.entry_price),
             ("arcus", arcus_size, health.arcus.entry_price)],
            {"entropy": e_px, "arcus": a_px},
            open_fees=self._open_fees(asset, float(opened_at), health),
            close_fee_rates=self._fee_rates_now(),
            min_usd=settings.take_profit_min_usd, buffer_bps=settings.take_profit_buffer_bps,
        )
        if est is None:
            self.take_profit_view.pop(asset, None)
            return None
        self.take_profit_view[asset] = {
            "net": round(est.net, 4), "threshold": round(est.threshold, 4),
            "gross": round(est.gross, 4), "fees": round(est.open_fees + est.close_fees, 4),
            "at": now,
        }
        if not est.triggered:
            return None
        return CycleDecision("close", "止盈：" + est.text(), maker_ok=False)

    def _finish(self, asset: str, market: dict[str, Any], decision: CycleDecision,
                result: PairResult | None, reason: str,
                available: tuple[float, float] | None, sizing: str | None) -> dict[str, Any]:
        """把一次动作的结果落库（执行记录 + 成交账本），返回给面板的决策记录。"""
        if (decision.plan == "topup" and result is not None
                and result.stage == "maker_not_filled"):
            # 补仓这一轮没等到成交：什么都没发生，不写记录（否则每两分钟一条「未成交」）
            return {"asset": asset, "plan": "maker_wait", "reason": result.reason,
                    "urgent": False, "result": result.to_dict()}
        if (result is not None and decision.plan == "open" and available
                and isinstance(result.quotes, dict)):
            # 开仓当时两边的可用余额一并落库 —— 数量看着不对时不用再去倒推
            result.quotes["entropy_available"] = round(available[0], 4)
            result.quotes["arcus_available"] = round(available[1], 4)
            result.quotes["sizing"] = sizing
        record = {
            "asset": asset, "plan": decision.plan, "reason": reason,
            "urgent": decision.urgent, "result": result.to_dict() if result else None,
            "entropy_available": available[0] if available else None,
            "arcus_available": available[1] if available else None,
        }
        if decision.is_action or decision.plan == "blocked":
            # 记【结果】，不是记【决策】。
            # 2026-09-18：实盘四次开仓全部零成交，日志却都写着「开仓 …」，
            # 看起来像成功 —— 真正的失败原因埋在 result 里没人看得到。
            logged_plan, logged_reason = decision.plan, reason
            if result is not None and decision.is_action:
                if result.stage == "maker_not_filled":
                    # 挂单没等到成交、已撤单：没花钱，不是失败
                    logged_plan, logged_reason = "maker_wait", result.reason or "挂单未成交"
                elif not result.ok:
                    logged_plan = f"{decision.plan}_failed"
                    logged_reason = f"{result.stage}：{result.reason or '未成功'}"
                elif result.stage == "opened":
                    logged_reason = f"已开仓 — {reason}"
                elif result.stage == "closed":
                    logged_reason = f"已平仓 — {reason}"
                elif result.stage == "topped_up":
                    logged_reason = f"已补仓 — {reason}"
                if result.notes and result.quotes.get("maker"):
                    logged_reason += "；" + "；".join(result.notes)
                # 开仓记录里写上两边实际设的杠杆，方便和交易所页面对照
                lev = (result.quotes.get("entropy_leverage"),
                       result.quotes.get("arcus_leverage"))
                if result.ok and result.stage in ("opened", "dry_run") and all(lev):
                    why = f"；{sizing}" if sizing else ""
                    logged_reason += f"（杠杆 Entropy {lev[0]}× / Arcus {lev[1]}×{why}）"
            if result is not None and result.stage in ("orphan_false", "orphan_gone"):
                logged_plan, logged_reason = "orphan_false", f"{result.reason}"
            elif result is not None and result.stage == "orphan_rehedged":
                logged_plan = "orphan_rehedged" if result.ok else "flatten_orphan_failed"
                logged_reason = f"{result.reason}；{'；'.join(result.notes)}"
            elif result is not None and result.stage == "close_rolled_back":
                logged_plan, logged_reason = "close_rolled_back", f"{result.reason}"
            cycle_id = self.store.log_cycle(
                asset, logged_plan, logged_reason, urgent=decision.urgent,
                dry_run=self.dry_run, result=result.to_dict() if result else None,
            )
            if result is not None:
                self._record_fills(asset, market, result, cycle_id)
        self._note_halts(asset, result)
        self._note_arcus_bound(asset, result)
        return record

    def _note_arcus_bound(self, asset: str, result: PairResult | None) -> None:
        """这次动作里 Arcus 有单被盘后价格带拒掉 → 暂停这个币的开仓 / 到期平仓。"""
        if result is None:
            return
        legs = [result.entropy, result.arcus, result.rescue] + [leg for _, leg in result.ledger]
        if not any(leg is not None and leg.venue == "arcus"
                   and ARCUS_BOUND_ERROR in str(leg.error or "") for leg in legs):
            return
        minutes = float(self.settings.arcus_bound_pause_minutes)
        first = self._arcus_bound_until.get(asset, 0.0) < time.time()
        self._arcus_bound_until[asset] = time.time() + minutes * 60
        if first:
            with contextlib.suppress(Exception):
                self.store.log_cycle(
                    asset, "arcus_bound",
                    f"Arcus 盘后价格带：价格贴着带边，往带外成交的单被拒（FILL_WILL_EXCEED_TRADING_BOUND）"
                    f" —— 暂停这个币的开仓和到期平仓 {minutes:g} 分钟（风控平仓照常）",
                    urgent=True, dry_run=self.dry_run)

    def _task_maker(self, task_row: dict[str, Any] | None) -> bool:
        """这个任务的 Arcus 腿走限价挂单还是市价吃单（任务自己没设就跟随 .env 的 ARCUS_MAKER）。
        演练模式一律按吃单模拟。"""
        if self.dry_run:
            return False
        kind = (task_row or {}).get("arcus_order_type")
        if kind in ("limit", "market"):
            return kind == "limit"
        return bool(self.settings.arcus_maker)

    def _maker_for(self, asset: str) -> bool:
        return self._task_maker(self.store.get_task(asset))

    async def _depth_cap(self, task_row: dict[str, Any], market: dict[str, Any], price: float,
                         quantity: float) -> tuple[float, str | None]:
        """按两边盘口深度限额（v1.12）：一来回价差成本超过 DEPTH_COST_CAP_BPS 就把数量缩小。

        2026-11-04：SNDK 单笔 > 15000 U 的轮次平均价差损益 −13.5 bps，< 7000 U 的只有 −4 ~ −5 bps ——
        Entropy 盘口薄，单子越大吃得越深。最多缩到任务金额区间的下限（固定金额 = 不缩）；
        区间下限本身就超过上限时按下限开，并在开仓记录里写明。
        """
        books = await self._books(market)
        if books is None or price <= 0:
            return quantity, None
        cap = float(self.settings.depth_cost_cap_bps)
        cost = round_trip_cost_bps(books[0], books[1], quantity)
        if cost is not None and cost <= cap:
            return quantity, f"盘口深度：按这个金额开平一来回约 {cost:.1f} bps（上限 {cap:g}）"
        decimals = int(market["quantity_decimals"])
        lo = task_row.get("notional_usdc")
        floor_q = float(market.get("min_base_quantity") or 10.0 ** -decimals)
        if lo:
            floor_q = max(floor_q, align_quantity(float(lo) / price, decimals))
        if floor_q >= quantity:
            return quantity, (f"盘口偏薄：按这个金额开平一来回约 "
                              f"{cost:.1f} bps，超过上限 {cap:g}，但金额已在区间下限" if cost is not None
                              else "盘口深度不够吃下这笔，但金额已在区间下限")
        fitted = max_quantity_within_cost(books[0], books[1], cap_bps=cap, high=quantity,
                                          low=floor_q, quantity_decimals=decimals)
        before = quantity * price
        if fitted <= 0:
            floor_cost = round_trip_cost_bps(books[0], books[1], floor_q)
            return floor_q, (f"盘口偏薄：区间下限 {floor_q * price:.0f} U 开平一来回也要约 "
                             f"{floor_cost if floor_cost is not None else float('nan'):.1f} bps，"
                             f"按下限开（原本 {before:.0f} U）")
        after_cost = round_trip_cost_bps(books[0], books[1], fitted)
        return fitted, (f"按盘口深度从 {before:.0f} 缩到 {fitted * price:.0f} U"
                        f"（一来回约 {after_cost:.1f} bps，上限 {cap:g}；原来约 "
                        f"{cost if cost is not None else float('nan'):.1f} bps）")

    @staticmethod
    def _fit_to_funds(task_row: dict[str, Any], market: dict[str, Any], price: float,
                      quantity: float, pre: Any, check: Any) -> tuple[float, Any, str | None]:
        """钱不够开这么大时，在任务的金额范围里自动缩小到能开的最大仓位（v1.7）。

        只管「钱不够」这一类：强平走廊不够宽（Arcus 全仓权益撑不住）或可用保证金不够。
        精度、杠杆、基差这些问题缩仓也解决不了，原样受阻。
        Entropy 逐仓走廊（kind = entropy_isolated）只由杠杆决定、和仓位大小无关，缩仓也没用，同样原样受阻。

          · 设了金额区间（最小 < 最大）：最多缩到区间下限，低于下限宁可不开，并写清最多能开多少；
            保证金只够开到区间下限以下时同样不开（以前会按保证金开出一个比下限还小的仓）。
          · 没设金额（开满）：本来就是「能开多大开多大」，走廊不够时同样缩到能开为止。
          · 固定金额（只填了最小）：金额是写死的，不自动改，照旧受阻。
        返回 (数量, 预检结果, 写进开仓记录的说明或 None)。
        """
        if pre is None or price <= 0 or quantity <= 0:
            return quantity, pre, None
        lo, hi = task_row.get("notional_usdc"), task_row.get("notional_usdc_max")
        ranged = bool(lo) and bool(hi) and float(hi) > float(lo)
        open_full = not lo
        if not (ranged or open_full):
            return quantity, pre, None
        decimals = int(market["quantity_decimals"])
        step = 10.0 ** -decimals
        min_q = float(market.get("min_base_quantity") or step)
        # 区间下限换成数量：向下取整一档，免得随机抽到正好是下限时被精度挤出区间
        floor_q = max(min_q, align_quantity(float(lo) / price, decimals)) if ranged else min_q
        span = f"（区间 {float(lo):g}–{float(hi):g}）" if ranged else ""

        if pre.ok:
            if ranged and quantity < floor_q - step / 2:
                return quantity, PreOpenDecision(
                    False,
                    f"可用保证金最多只够开 {quantity * price:.0f} USDC，低于设置的最小金额 "
                    f"{float(lo):g} USDC{span} —— 不开小于区间下限的仓",
                    pre.estimated_corridor_pct, pre.leverage, quantity, "margin"), None
            return quantity, pre, None
        if pre.kind not in ("corridor", "margin"):
            return quantity, pre, None

        wanted = quantity
        fitted = fit_quantity(lambda q: check(q).ok, high=wanted, low=floor_q,
                              quantity_decimals=decimals)
        if fitted > 0:
            why = "强平走廊" if pre.kind == "corridor" else "可用保证金"
            return fitted, check(fitted), (
                f"资金不足，自动从 {wanted * price:.0f} 缩到 {fitted * price:.0f} USDC"
                f"（{why}能撑住的最大金额）{span}")
        if ranged:
            most = fit_quantity(lambda q: check(q).ok, high=wanted, low=min_q,
                                quantity_decimals=decimals)
            cap = (f"现在最多只能开约 {most * price:.0f} USDC" if most > 0
                   else "现在连最小下单量都开不了")
            return quantity, PreOpenDecision(
                False, f"{pre.reason}；{cap}，低于设置的最小金额 {float(lo):g} USDC{span}，"
                       f"自动缩仓也开不了",
                pre.estimated_corridor_pct, pre.leverage, quantity, pre.kind), None
        return quantity, pre, None

    def _draw_notional(self, task_row: dict[str, Any]) -> float | None:
        """本轮开仓金额：设了区间就在区间里随机抽一个，否则按固定值；都没设 = 不限（开满）。"""
        lo = task_row.get("notional_usdc")
        hi = task_row.get("notional_usdc_max")
        if not lo:
            return None
        lo = float(lo)
        if hi and float(hi) > lo:
            return self.rng.uniform(lo, float(hi))
        return lo

    def _runs_as_maker(self, decision: CycleDecision, task_row: dict[str, Any] | None = None) -> bool:
        if not self._task_maker(task_row):
            return False
        return decision.plan in ("open", "topup") or (
            decision.plan == "close" and decision.maker_ok)

    async def _maker_job(self, decision, market, health, row, price, pre, hold,
                         leverages, available, sizing, reason, stop=None) -> None:
        asset = market["asset"]
        try:
            result = await self._apply(decision, market, health, row, price, pre,
                                       hold_hours=hold, leverages=leverages, stop=stop)
            self._finish(asset, market, decision, result, reason, available, sizing)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 —— 后台任务出错也要留下记录
            with contextlib.suppress(Exception):
                self.store.log_cycle(asset, "error", f"挂单任务出错：{exc}"[:300],
                                     dry_run=self.dry_run)

    def busy_assets(self) -> list[str]:
        return [a for a, t in self._jobs.items() if not t.done()]

    def _record_fills(self, asset: str, market: dict[str, Any],
                      result: PairResult, cycle_id: int | None) -> None:
        """把这一次动作里真正发出去的每一条腿记进成交账本。

        记账失败绝不能影响交易 —— 账本是统计用的，仓位才是真的。
        """
        try:
            for row in ledger_rows_for_result(
                asset, result, dry_run=self.dry_run,
                market_id=market.get("entropy_market_index"), cycle_id=cycle_id,
            ):
                self.store.record_fill(**row)
        except Exception as exc:  # noqa: BLE001
            with contextlib.suppress(Exception):
                self.store.log_cycle(asset, "error", f"成交记账失败：{exc}"[:300],
                                     dry_run=self.dry_run)

    # ── 孤腿抢救（v1.8：先复核、按新盘口、平不掉逐级放宽）──
    async def _flatten_orphan(self, decision: CycleDecision, market: dict[str, Any],
                              price: float, slippage: float,
                              decimals: tuple[int, int]) -> PairResult:
        asset = market["asset"]
        venue = decision.orphan_venue or "entropy"
        size = decision.orphan_size
        label = VENUE_LABEL.get(venue, venue)
        if not self.dry_run:
            # 下单前再读一次两边仓位：Arcus 的持仓接口偶尔慢一拍，
            # 刚开的那条腿还没显示出来就会被看成「只剩一条腿」（2026-10-24 SPY）
            fresh_e, fresh_a = await self.executor.read_positions(
                market["entropy_symbol"], int(market["arcus_market_id"]))
            fresh = fresh_e if venue == "entropy" else fresh_a
            other = fresh_a if venue == "entropy" else fresh_e
            if math.isfinite(fresh) and math.isfinite(other):
                if abs(fresh) < 1e-12:
                    self._orphan_fail.pop(asset, None)
                    return PairResult(True, "orphan_false", dry_run=False,
                                      reason=f"孤腿误报已排除：复核时 {label} 那条腿已经没有仓位了")
                if fresh * other < 0 and abs(abs(fresh) - abs(other)) <= 0.02 * abs(fresh):
                    self._orphan_fail.pop(asset, None)
                    return PairResult(True, "orphan_false", dry_run=False,
                                      reason="孤腿误报已排除：复核时两条腿都在、数量对得上（持仓接口慢了一拍）")
            if math.isfinite(fresh) and abs(fresh) > 1e-12:
                size = fresh
            books = await self._books(market)
            if books is not None:
                side = "sell" if size > 0 else "buy"
                book = books[0] if venue == "entropy" else books[1]
                from .books import vwap
                price = vwap(book.side(side), abs(size)) or price
        failures = self._orphan_fail.get(asset, 0)
        wide = orphan_slippage_bps(slippage, failures)
        leg = await self.executor.flatten_orphan(
            market=market, venue=venue, size=size, price=price, slippage_bps=slippage,
            entropy_decimals=decimals, wide_bps=wide,
        )
        if (not leg.ok and venue == "arcus" and ARCUS_BOUND_ERROR in str(leg.error or "")
                and not self.dry_run):
            # Arcus 盘后价格带把平仓单拒了：一直重试也卖不出去（11-04 抢救了 1~2 分钟）。
            # 改成在 Entropy 上反向开回同样的数量，先恢复对冲，等价格带放开再按正常流程两边一起平。
            side = "sell" if size > 0 else "buy"
            book_px = price
            books = await self._books(market)
            if books is not None:
                from .books import vwap
                book_px = vwap(books[0].side(side), abs(size)) or price
            from .fills import slippage_limit_price
            hedge = await self.executor._entropy_ioc(
                market["entropy_symbol"], side, abs(size),
                slippage_limit_price(book_px, side, slippage * 3), decimals, reduce_only=False)
            self._orphan_fail.pop(asset, None)
            ok = bool(hedge.ok and (hedge.filled or 0) > 0)
            return PairResult(
                ok, "orphan_rehedged", dry_run=self.dry_run, arcus=leg, entropy=hedge,
                reason=(f"Arcus 盘后价格带拒了平仓单 —— 改为在 Entropy 反向开 {abs(size):g}，"
                        f"两腿恢复对冲，等价格带放开再一起平"),
                notes=["已恢复对冲" if ok else f"⚠ Entropy 补对冲没成交：{hedge.error}，下一轮再处理"],
                ledger=[("orphan", leg), ("open", hedge)],
            )
        if not leg.ok and REDUCE_ONLY_GONE.search(str(leg.error or "")):
            # 交易所说「只减仓的单会让仓位变大」= 那边已经没有这个方向的仓位了
            self._orphan_fail.pop(asset, None)
            return PairResult(True, "orphan_gone", dry_run=self.dry_run,
                              reason=f"孤腿误报已排除：{label} 回复只减仓单会让仓位变大 —— 那边其实已经没仓了",
                              entropy=leg if venue == "entropy" else None,
                              arcus=leg if venue == "arcus" else None)
        if leg.ok:
            self._orphan_fail.pop(asset, None)
        else:
            self._orphan_fail[asset] = failures + 1
        return PairResult(
            leg.ok, "flatten_orphan", reason=decision.reason, dry_run=self.dry_run,
            entropy=leg if leg.venue == "entropy" else None,
            arcus=leg if leg.venue == "arcus" else None,
            notes=[f"孤腿已平（滑点上限 {wide:g} bps）" if leg.ok
                   else f"⚠ 孤腿平仓失败（第 {failures + 1} 次，滑点上限 {wide:g} bps），"
                        f"下轮放宽滑点重试"],
            ledger=[("orphan", leg)],
        )

    # ── 执行 ────────────────────────────────────────
    async def _apply(
        self, decision: CycleDecision, market: dict[str, Any],
        health: HedgeHealth, row: dict[str, Any], price: float | None,
        pre: Any = None, *, hold_hours: float | None = None,
        leverages: tuple[int, int] | None = None, stop: asyncio.Event | None = None,
    ) -> PairResult | None:
        asset = market["asset"]
        slippage = self.settings.order_slippage_bps
        decimals = await self._entropy_decimals(market)
        if price is None:
            price = 0.0

        if decision.plan == "flatten_orphan":
            return await self._flatten_orphan(decision, market, price, slippage, decimals)

        if decision.plan == "close":
            entropy = health.entropy.size if health.entropy else 0.0
            arcus = health.arcus.size if health.arcus else 0.0
            if abs(entropy) < 1e-12 and abs(arcus) < 1e-12:
                # 演练模式下本来就没有真实仓位，直接推进状态即可
                self.store.mark_closed(asset)
                return None
            entropy_side, arcus_side = closing_sides(entropy, arcus)
            books = await self._books(market)
            entropy_px = arcus_px = price
            if books is not None:
                lp, ep = executable_prices(
                    books[0], books[1], entropy_side=entropy_side,
                    arcus_side=arcus_side, quantity=max(abs(entropy), abs(arcus)),
                )
                # 平仓拿不到盘口时退回标记价 —— 平仓不能因为取不到价就不做
                entropy_px = lp or price
                arcus_px = ep or price
            # 正常轮换 / 停用收尾可以挂单慢慢平；风控触发的平仓必须立刻吃单
            closer = self._maker() if (
                decision.maker_ok and self._maker_for(asset)
            ) else self.executor
            result = await closer.close_pair(
                market=market, entropy_size=entropy, arcus_size=arcus,
                entropy_price=entropy_px, arcus_price=arcus_px,
                slippage_bps=slippage, entropy_decimals=decimals,
            )
            if result.ok:
                self.store.mark_closed(asset)
            return result

        if decision.plan in ("open", "topup"):
            topup = decision.plan == "topup"
            # 每条腿的限价必须来自【该所自己的盘口】，而且是按下单数量
            # 走完档位的 VWAP。共用一个标记价在原理上就是错的：
            # 两所之间有基差，滑点预算一旦盖不住它，单子就永远够不到对手价。
            entropy_side, arcus_side = hedge_side(decision.direction or "")
            # 先设杠杆、再取盘口、再下单。设不上就不开 —— 数量是按这个杠杆算的，
            # 交易所实际用别的杠杆，保证金和强平走廊就全对不上了。
            # 放在取盘口之前：设杠杆要一两秒，别让它夹在报价和下单中间。
            if leverages is not None:
                ok, error = await self.executor.set_leverage(
                    market, entropy_leverage=leverages[0], arcus_leverage=leverages[1],
                )
                if not ok:
                    return PairResult(
                        False, "leverage_failed", reason=error, dry_run=self.dry_run,
                        quotes={"entropy_leverage": leverages[0],
                                "arcus_leverage": leverages[1]},
                        notes=["尚未下任何单"],
                    )
            books = await self._books(market)
            if books is None:
                return PairResult(
                    False, "no_book", reason="拿不到两边盘口，本轮不开",
                    dry_run=self.dry_run,
                )
            entropy_book, arcus_book = books
            entropy_px, arcus_px = executable_prices(
                entropy_book, arcus_book,
                entropy_side=entropy_side, arcus_side=arcus_side,
                quantity=decision.quantity,
            )
            quotes = {
                "entropy_best_bid": entropy_book.best_bid,
                "entropy_best_ask": entropy_book.best_ask,
                "arcus_best_bid": arcus_book.best_bid,
                "arcus_best_ask": arcus_book.best_ask,
                "entropy_vwap": entropy_px,
                "arcus_vwap": arcus_px,
                "basis_bps": basis_bps(entropy_book, arcus_book),
                "shared_mark_was": price,
            }
            if leverages is not None:
                quotes["entropy_leverage"], quotes["arcus_leverage"] = leverages
            if entropy_px is None or arcus_px is None:
                short = "Entropy" if entropy_px is None else "Arcus"
                return PairResult(
                    False, "insufficient_depth",
                    reason=f"{short} 盘口深度不足以吃下 {decision.quantity:g}，本轮不开",
                    dry_run=self.dry_run, quotes=quotes,
                )
            # 基差闸门：两所是按代号自动配对的，同名不等于同一个标的
            # （或者一边是 1000 倍合约）。中价差出这么多，宁可不开。
            basis = quotes.get("basis_bps")
            if basis is None or abs(basis) > MAX_OPEN_BASIS_BPS:
                return PairResult(
                    False, "basis_too_wide",
                    reason=(
                        f"两所中价相差 {basis:+.0f} bps（上限 {MAX_OPEN_BASIS_BPS:g}），"
                        f"疑似不是同一个标的或一边盘口异常，本轮不开"
                        if basis is not None else "有一边盘口缺买一或卖一，本轮不开"
                    ),
                    dry_run=self.dry_run, quotes=quotes, notes=["尚未下任何单"],
                )
            if topup:
                # 补仓只走挂单（杠杆开仓时已经设过，不再动）
                result = await self._maker(stop).open_pair(
                    market=market, direction=decision.direction or "",
                    quantity=decision.quantity,
                    entropy_price=entropy_px, arcus_price=arcus_px,
                    slippage_bps=slippage, entropy_decimals=decimals, quotes=quotes,
                    action="topup",
                )
                if not result.ok:
                    return result
                added = float((result.quotes or {}).get("filled_quantity") or 0.0)
                task = self.store.get_task(asset) or {}
                self.store.upsert_task(
                    asset, open_quantity=float(task.get("open_quantity") or 0.0) + added)
                result.stage = "topped_up"
                # 仓位变大，全仓账户里各任务的强平距离都会机械地变近：下一轮重设基准
                self._rebase_note = f"{asset} 补仓 {added:g}"
                return result
            opener = self._maker(stop) if self._maker_for(asset) \
                else self.executor
            result = await opener.open_pair(
                market=market, direction=decision.direction or "",
                quantity=decision.quantity,
                entropy_price=entropy_px, arcus_price=arcus_px,
                slippage_bps=slippage, entropy_decimals=decimals, quotes=quotes,
            )
            if not result.ok:
                return result
            # 挂单模式可能只开出一部分：按实际对冲上的数量记
            opened_quantity = float(
                (result.quotes or {}).get("filled_quantity") or decision.quantity)
            # 开仓后必须用真实强平价复核走廊 —— 估算可能偏乐观。
            #
            # 但「读不到强平价」和「确认走廊太窄」是两回事，不能混为一谈：
            # 账户接口偶尔要几秒才反映出新仓位（Arcus 202 异步撮合尤其如此）。
            # 2026-09-18 原本只等 1 秒就盲平，白付一轮往返成本，
            # 而且盲平本身也可能失败。
            # 现在：重试若干轮；确认太窄才回撤；始终读不到就【保留仓位】，
            # 交给每 20 秒一轮的风控循环去判断（它有绝对下限和孤腿抢救兜底）。
            if not self.dry_run:
                check = None
                for attempt in range(_VERIFY_ATTEMPTS):
                    await asyncio.sleep(_VERIFY_DELAY_SEC * (attempt + 1))
                    fresh = await self.service.refresh()
                    fresh_row = next(
                        (r for r in fresh.get("rows", []) if r["asset"] == asset), None
                    )
                    if fresh_row is None:
                        continue
                    fresh_health = self._health_for(asset, fresh_row)
                    candidate = verify_corridor_after_open(
                        fresh_health, self.settings.close_corridor_pct
                    )
                    # 读到了真实走廊（不管够不够宽）就采信，不再重试
                    if candidate.actual_corridor_pct is not None or candidate.ok:
                        check = candidate
                        break
                if check is None:
                    # 始终读不到：保留仓位，如实标注，让风控循环接管
                    self.store.mark_opened(
                        asset, direction=decision.direction or "",
                        quantity=opened_quantity, corridor_pct=None,
                        hold_hours=hold_hours, target_quantity=decision.quantity,
                    )
                    result.notes.append(
                        f"开仓后 {_VERIFY_ATTEMPTS} 次都读不到强平价，已保留仓位 —— "
                        f"下一轮风控会重新判断（绝对下限与孤腿抢救仍然有效）"
                    )
                    return result
                if True:
                    if not check.ok:
                        back_out = await self.executor.close_pair(
                            market=market,
                            entropy_size=fresh_health.entropy.size if fresh_health.entropy else 0.0,
                            arcus_size=fresh_health.arcus.size if fresh_health.arcus else 0.0,
                            entropy_price=price, arcus_price=price,
                            slippage_bps=slippage, entropy_decimals=decimals,
                        )
                        self.store.mark_closed(asset)
                        result.ok = False
                        result.stage = "corridor_too_narrow_backed_out"
                        result.reason = check.reason
                        # 把回撤平仓自己的结果也记下来 —— 不记的话
                        # 无从判断「平仓单发出去了」还是「真的平掉了」
                        result.rescue = back_out.entropy
                        result.quotes["backout"] = back_out.to_dict()
                        result.ledger.extend(("backout", leg) for _, leg in back_out.ledger)
                        result.notes.append(
                            "开仓后复核不过，已平掉" if back_out.ok
                            else "⚠ 复核不过且平仓失败 —— 仓位可能还在，下一轮风控接管"
                        )
                        return result
                    self.store.mark_opened(
                        asset, direction=decision.direction or "",
                        quantity=opened_quantity,
                        corridor_pct=check.actual_corridor_pct,
                        hold_hours=hold_hours, target_quantity=decision.quantity,
                    )
                    return result
            # 演练模式没有真实仓位可复核，退而记录预检的估算值，
            # 好让持仓期间的相对触发有个参照。
            self.store.mark_opened(
                asset, direction=decision.direction or "",
                quantity=opened_quantity,
                corridor_pct=getattr(pre, "estimated_corridor_pct", None),
                hold_hours=hold_hours, target_quantity=decision.quantity,
            )
            return result
        return None

    # ── 辅助 ────────────────────────────────────────
    def _maker(self, stop: asyncio.Event | None = None):
        from .maker import MakerExecutor
        return MakerExecutor(self.executor, wait_seconds=self.settings.maker_wait_seconds,
                             bell=self.bell, stop=stop)

    @staticmethod
    def _task_state(task_row: dict[str, Any], settings: Settings) -> TaskState:
        return TaskState(
            asset=task_row["asset"], enabled=bool(task_row["enabled"]),
            rotation_hours=float(task_row["rotation_hours"] or 4.0),
            rotation_hours_max=task_row.get("rotation_hours_max"),
            hold_hours=task_row.get("hold_hours"),
            leverage=float(task_row["leverage"] or 1.0),
            opened_at=task_row.get("opened_at"),
            corridor_at_open_pct=task_row.get("corridor_at_open"),
            last_closed_at=task_row.get("last_closed_at"),
            cooldown_seconds=settings.reopen_cooldown_seconds,
        )

    def _topup_should_stop(self, task_row: dict[str, Any], row: dict[str, Any] | None,
                           now: float) -> str | None:
        """补仓进行中，这一轮的风控要不要介入。要介入返回原因。"""
        if not task_row.get("enabled"):
            return "任务已停用"
        if row is None:
            return "该币种不在两所共有列表里了"
        if self._task_state(task_row, self.settings).is_due_to_close(now):
            return "已到轮换时间"
        health = self._health_for(task_row["asset"], row)
        distance = health.min_distance_pct
        if distance is not None and distance < self.settings.close_corridor_pct:
            return f"距强平仅剩 {distance:.2f}%"
        if health.is_hedged:
            # 两腿对得上时才看完整的风控裁决（补仓中间两腿差一点是正常的，不能当成不匹配）
            verdict = evaluate(health, corridor_at_open_pct=task_row.get("corridor_at_open"),
                               min_corridor_pct=self.settings.close_corridor_pct)
            if verdict.action != "none":
                return verdict.reason or "风控触发"
        return None

    async def _topup_decision(self, task_row, market, health, risk, state, price,
                              mmf_by_market, now) -> tuple[CycleDecision | None, str | None]:
        """持仓中、仓位没到这一轮的目标数量：挂单补仓（只在实盘挂单模式下）。

        返回（补仓决策, 面板上显示的补充说明）。
        """
        if (self.dry_run or not self._task_maker(task_row) or not state.enabled
                or risk.action != "none" or not health.is_hedged
                or not state.opened_at or not price):
            return None, None
        dec = int(market["quantity_decimals"])
        target = task_row.get("target_quantity")
        if not target and task_row.get("notional_usdc"):
            # 升级前开的仓 / 接管的仓没有记目标：按名义上限算
            target = align_quantity(float(task_row["notional_usdc"]) / price, dec)
        if not target:
            return None, None
        left = state.effective_hold_hours() * 3600 - (now - float(state.opened_at))
        if left < self.settings.maker_wait_seconds + TOPUP_MIN_LEFT_SEC:
            return None, None
        entropy_size = health.entropy.size if health.entropy else 0.0
        arcus_size = health.arcus.size if health.arcus else 0.0
        current = min(abs(entropy_size), abs(arcus_size))
        direction = ("long_entropy_short_arcus" if entropy_size > 0
                     else "short_entropy_long_arcus")
        if task_row.get("open_direction") and task_row["open_direction"] != direction:
            return None, None
        remaining = align_quantity(float(target) - current, dec)
        if remaining <= 0 or remaining < float(target) * TOPUP_MIN_FRACTION:
            return None, None

        entropy_avail, arcus_avail, arcus_acct = await self._available(with_arcus=True)
        leverage = float(task_row["leverage"] or 1.0)
        leverages = effective_leverages(
            leverage, arcus_max=float(market["max_leverage"]),
            entropy_max=await self._entropy_max_leverage(market),
            entropy_mmf=market.get("entropy_mmf"),
            min_corridor_pct=self.settings.min_corridor_pct,
        )
        room = max_quantity_for(
            leverage=leverage, price=price, entropy_available=entropy_avail,
            arcus_available=arcus_avail, quantity_decimals=dec,
            entropy_leverage=leverages[0], arcus_leverage=leverages[1],
        )
        remaining = align_quantity(min(remaining, room), dec)
        # 全仓走廊按【补完之后】的总仓位估：这个币已有的仓位当作账户里的「其它仓位」算进去
        # （公式里它和新增部分是对称的，等价于按总仓位算）
        equity, other, other_mm = account_exposure(
            arcus_acct, mmf_by_market, exclude_market=int(market["arcus_market_id"]))
        mmf = float(market.get("arcus_mmf") or 1.0 / (2.0 * float(market["max_leverage"])))
        here = current * price
        pre = pre_open_check(
            leverage=leverage, max_leverage=float(market["max_leverage"]),
            quantity=remaining, price=price, min_quantity=market["min_base_quantity"],
            entropy_available=entropy_avail, arcus_available=arcus_avail,
            min_corridor_pct=self.settings.min_corridor_pct,
            entropy_leverage=leverages[0], arcus_leverage=leverages[1],
            maintenance_fraction=market.get("arcus_mmf"),
            min_notional=market.get("min_notional"),
            arcus_equity=equity, arcus_other_notional=other + here,
            arcus_other_maintenance=other_mm + here * mmf,
            entropy_maintenance_fraction=market.get("entropy_mmf"),
            entropy_max_leverage=market.get("entropy_max_leverage"),
        )
        if remaining <= 0 or not pre.ok:
            why = pre.reason if remaining > 0 else "可用保证金不够再加仓"
            return None, f"仓位 {current:g} / 目标 {float(target):g}，暂不补仓：{why}"
        return CycleDecision(
            "topup", f"补仓 {remaining:g}（当前 {current:g} / 目标 {float(target):g}）",
            direction=direction, quantity=remaining,
        ), None

    def _rebase_on_composition_change(self, rows: dict[str, Any]) -> None:
        """Arcus 账户里的仓位组合变了，就把各持仓任务的「开仓走廊」基准重设成当前值。

        为什么（2026-09-26 实盘）：ETH 开仓时离强平 15.62%，随后 QQQ、SPY 在同一个
        Arcus 全仓账户里开仓，ETH 的距离被【机械地】压到 7.13% —— 价格没动，
        只是账户里多了两笔仓位。「剩余距离掉到开仓时的一半就平」的规则因此触发，
        白白多平了一轮。组合一变就重设基准，相对触发只对价格变化响应；
        绝对平仓线（CLOSE_CORRIDOR_PCT）不受影响，照样兜底。
        """
        composition = frozenset(
            asset for asset, row in rows.items()
            if abs(float((((row.get("position") or {}).get("arcus")) or {}).get("size") or 0)) > 1e-12
        )
        previous = self._arcus_composition
        self._arcus_composition = composition
        note, self._rebase_note = self._rebase_note, None
        if previous is None or (previous == composition and not note):
            return
        added, removed = sorted(composition - previous), sorted(previous - composition)
        change = "、".join(
            [f"新增 {', '.join(added)}"] * bool(added) + [f"减少 {', '.join(removed)}"] * bool(removed)
            + [note] * bool(note))
        for task in self.store.list_tasks():
            asset = task["asset"]
            if not task.get("opened_at") or asset not in rows:
                continue
            distance = self._health_for(asset, rows[asset]).min_distance_pct
            old = task.get("corridor_at_open")
            if distance is None or (old is not None and abs(distance - float(old)) < 0.01):
                continue
            self.store.upsert_task(asset, corridor_at_open=distance)
            self.store.log_cycle(
                asset, "rebase",
                f"Arcus 账户仓位变了（{change}），强平距离基准从 "
                f"{float(old):.2f}% 重设为 {distance:.2f}%" if old is not None else
                f"Arcus 账户仓位变了（{change}），强平距离基准设为 {distance:.2f}%",
                dry_run=self.dry_run,
            )

    def _simulated_health(
        self, task_row: dict[str, Any], asset: str, price_hint: float | None
    ) -> HedgeHealth | None:
        """演练模式专用：按库里记的开仓状态伪造一份持仓。

        只在 dry_run 下调用。目的是让「持仓 → 到期 → 平仓 → 冷却」整条链
        在演练里真正跑一遍，而不是每轮都从空仓重新开始。
        强平价由开仓走廊反推，好让风控的相对触发也能被验到。
        """
        from .positions import LegPosition

        quantity = task_row.get("open_quantity")
        direction = task_row.get("open_direction")
        if not task_row.get("opened_at") or not quantity or not direction:
            return None
        price = price_hint or 0.0
        if price <= 0:
            return None
        corridor = float(task_row.get("corridor_at_open") or 0.0) / 100.0
        long_is_entropy = direction == "long_entropy_short_arcus"
        entropy_size = float(quantity) if long_is_entropy else -float(quantity)
        arcus_size = -entropy_size

        def leg(venue: str, size: float) -> LegPosition:
            if corridor > 0:
                liq = price * (1 - corridor) if size > 0 else price * (1 + corridor)
            else:
                liq = None
            return LegPosition(
                venue=venue, symbol=asset, size=size, entry_price=price,
                mark_price=price, liquidation_price=liq,
                unrealized_pnl=0.0, margin=None,
            )

        return HedgeHealth(
            asset=asset,
            entropy=leg("entropy", entropy_size),
            arcus=leg("arcus", arcus_size),
            warn_distance_pct=self.settings.close_corridor_pct,
        )

    async def _books(self, market: dict[str, Any]):
        """两边盘口。任一边失败返回 None —— 拿不到价就不该下单。"""
        entropy, arcus = await asyncio.gather(
            self.service.client.entropy_book(
                market["entropy_market_index"], market["entropy_symbol"]
            ),
            self.service.client.arcus_book(market["arcus_symbol"]),
            return_exceptions=True,
        )
        if isinstance(entropy, Exception) or isinstance(arcus, Exception):
            return None
        return entropy, arcus

    def _health_for(self, asset: str, row: dict[str, Any]) -> HedgeHealth:
        pos = row.get("position") or {}
        return HedgeHealth(
            asset=asset,
            entropy=_leg_from(pos.get("entropy"), "entropy", asset),
            arcus=_leg_from(pos.get("arcus"), "arcus", asset),
            warn_distance_pct=self.settings.close_corridor_pct,
        )

    @staticmethod
    def _mark_for(health: HedgeHealth, row: dict[str, Any]) -> float | None:
        for leg in health.open_legs:
            if leg.mark_price:
                return leg.mark_price
        return row.get("mark_price")

    @staticmethod
    def _choice_for(row: dict[str, Any]):
        from .funding import DirectionChoice
        if row.get("net_bps_per_hour") is None:
            return None
        return DirectionChoice(
            symbol=row["asset"], direction=row["direction"],
            net_bps_per_hour=row["net_bps_per_hour"],
            entropy_bps_per_hour=row["entropy_bps_per_hour"],
            arcus_bps_per_hour=row["arcus_bps_per_hour"],
            tradable=row["tradable"], reason=row.get("reason"),
        )

    async def _entropy_max_leverage(self, market: dict[str, Any]) -> float | None:
        """Entropy 这个市场的杠杆上限。查不到返回 None（按任务值设，交易所不收会拒）。"""
        try:
            details = await self.service.client.entropy_market_details(
                int(market["entropy_market_index"])
            )
        except Exception:  # noqa: BLE001 —— 查不到上限不该挡住整轮
            return None
        return details.get("max_leverage")

    async def _available(self, *, with_arcus: bool = False):
        entropy_acct, arcus_acct = await asyncio.gather(
            self.service.client.entropy_account(),
            self.service.client.arcus_account(),
            return_exceptions=True,
        )
        entropy = _entropy_available(entropy_acct)
        arcus = _arcus_available(arcus_acct)
        if with_arcus:
            return entropy, arcus, (None if isinstance(arcus_acct, Exception) else arcus_acct)
        return entropy, arcus

    @staticmethod
    async def _entropy_decimals(market: dict[str, Any]) -> tuple[int, int]:
        """(数量精度, 价格精度) —— 都取 Entropy 自己的，不能用两所取小的那个。

        quantity_decimals 是两所取 min 后的下单精度；但 Entropy 的限价小数位上限是
        6 − szDecimals，要用它自己的 szDecimals 算，混用会算宽一档被拒单。
        """
        size = int(market.get("entropy_size_decimals") or market.get("quantity_decimals") or 2)
        price = int(market.get("price_decimals") or 2)
        return size, price


def _leg_from(data: dict[str, Any] | None, venue: str, asset: str):
    from .positions import LegPosition
    if not data:
        return None
    return LegPosition(
        venue=venue, symbol=asset, size=data.get("size") or 0.0,
        entry_price=data.get("entry_price"), mark_price=data.get("mark_price"),
        liquidation_price=data.get("liquidation_price"),
        unrealized_pnl=data.get("unrealized_pnl"), margin=data.get("margin"),
    )


def _entropy_available(payload: Any) -> float:
    """Entropy 可用保证金 —— 直接用首页余额那个函数（统一账户 / 普通账户都对），只有一份口径。"""
    if isinstance(payload, Exception) or not isinstance(payload, dict):
        return 0.0
    balance = entropy_balance(payload)
    return float(balance["available"]) if balance else 0.0


def _arcus_available(payload: Any) -> float:
    """Arcus 可用保证金（freeCollateral）—— 直接用首页余额那个函数，只有一份口径。"""
    if isinstance(payload, Exception):
        return 0.0
    balance = arcus_balance(payload)
    return float(balance["available"]) if balance else 0.0
