"""三道新保险（v1.8）—— 纯逻辑，不碰网络，两个程序共用同一份。

1. 下单通道熔断：某个所的下单通道失效（API 钱包 / API 密钥被拒、过期、被顶掉），
   程序就暂停所有会动到这个所的开平仓，面板标红，不再「先平 Arcus、后发现另一边平不掉」。
   2026-10-20 DRAM：Entropy 的 API 钱包失效，程序先平了 Arcus，Entropy 那条腿裸了 22 分钟。
2. 孤腿抢救的滑点阶梯：连续平不掉就逐级放宽，不再每次按同一个价去追。
   2026-10-17 DRAM：盘口薄，同一个限价连续失败 11 次、4 分钟后才平掉。
3. 浮盈止盈：两边按「现在真能成交的价格」平掉，扣掉开仓已付和平仓要付的手续费后还是赚的，
   就立刻两边一起平、冷却后进入新一轮 —— 把开仓时吃掉的价差赚回来，同时多刷一轮量。
"""
from __future__ import annotations

import re
import time
from dataclasses import dataclass
from typing import Any

# ── 1. 下单通道熔断 ──────────────────────────────────────

# 交易所的原话里出现这些，说明【这把钥匙】不能用了（不是行情 / 余额问题）。
# 只收确定的说法：误判会让程序无故停手，漏判还有「先平对冲腿」那一层兜着。
AUTH_ERROR_PATTERNS: dict[str, re.Pattern[str]] = {
    # Hyperliquid：API 钱包不存在 / 过期 / 被同名的新钱包顶掉
    "entropy": re.compile(
        r"User or API Wallet .{0,80}does not exist|API wallet .{0,60}expired"
        r"|agent .{0,40}(expired|not found)", re.I),
    # Arcus：只认 HTTP 401/403 和明确的密钥 / 签名错误码（订单本身过期的 EXPIRED 不算）
    "arcus": re.compile(
        r"^HTTP 40[13]\b|\bUNAUTHORI[SZ]ED\b|\bINVALID_SIGNATURE\b|\bSIGNATURE_INVALID\b"
        r"|\bINVALID_API_KEY\b|\bAPI_KEY_(EXPIRED|INVALID|REVOKED|NOT_FOUND)\b", re.I),
    # Lighter：报错文字不固定，被拒以后用官方 SDK 的 check_client() 向交易所核对密钥再定
    "lighter": re.compile(
        r"invalid signature|api ?key .{0,40}(not found|mismatch|invalid)", re.I),
}

VENUE_LABEL = {"arcus": "Arcus", "entropy": "Entropy", "lighter": "Lighter"}
PROBE_INTERVAL_SEC = 300.0


def looks_like_auth_error(venue: str, text: Any) -> bool:
    pattern = AUTH_ERROR_PATTERNS.get(venue)
    return bool(pattern and text and pattern.search(str(text)))


@dataclass
class Halt:
    venue: str
    reason: str
    since: float
    last_probe: float = 0.0


class VenueHalts:
    """哪些所的下单通道被判定失效了。只存在内存里：重启程序 = 重新检查。"""

    def __init__(self, clock: Any = time.time) -> None:
        self.clock = clock
        self._halts: dict[str, Halt] = {}

    def trip(self, venue: str, reason: str) -> bool:
        """标记失效。返回 True = 这是新触发的（调用方据此写一条执行记录）。"""
        if venue in self._halts:
            return False
        now = self.clock()
        self._halts[venue] = Halt(venue, str(reason)[:300], now, last_probe=now)
        return True

    def clear(self, venue: str | None = None) -> list[str]:
        venues = [venue] if venue else list(self._halts)
        return [v for v in venues if self._halts.pop(v, None) is not None]

    def is_halted(self, venue: str | None) -> bool:
        return bool(venue) and venue in self._halts

    def any(self) -> bool:
        return bool(self._halts)

    def due_for_probe(self) -> list[str]:
        now = self.clock()
        due = [v for v, h in self._halts.items() if now - h.last_probe >= PROBE_INTERVAL_SEC]
        for v in due:
            self._halts[v].last_probe = now
        return due

    def describe(self) -> str:
        return "；".join(f"{VENUE_LABEL.get(h.venue, h.venue)} 下单通道失效（{h.reason}）"
                        for h in self._halts.values())

    def status(self) -> list[dict[str, Any]]:
        return [{"venue": h.venue, "label": VENUE_LABEL.get(h.venue, h.venue),
                 "reason": h.reason, "since": h.since} for h in self._halts.values()]


def plan_blocked_by_halt(plan: str, orphan_venue: str | None, halts: VenueHalts,
                         venues: tuple[str, str]) -> str | None:
    """这个动作会不会碰到失效的所。返回挡住它的原因，或 None（可以照常做）。

    · 开仓 / 补仓 / 平仓都要两边一起下单 —— 任何一边失效都不做
      （只平得掉一边，另一边就裸了，比两边都不动更糟）；
    · 孤腿抢救只下孤腿那一个所 —— 那个所没失效就照常抢救。
    """
    if not halts.any():
        return None
    if plan == "flatten_orphan":
        if halts.is_halted(orphan_venue):
            return (f"孤腿在 {VENUE_LABEL.get(orphan_venue or '', orphan_venue)}，"
                    f"但那边下单通道失效，程序平不掉 —— 请立刻手动平仓")
        return None
    if plan in ("open", "topup", "close"):
        bad = [v for v in venues if halts.is_halted(v)]
        if bad:
            return ("、".join(VENUE_LABEL.get(v, v) for v in bad)
                    + " 下单通道失效，暂停开平仓（两腿保持对冲不动）")
    return None


# ── 2. 孤腿抢救的滑点阶梯 ────────────────────────────────

# 相对任务滑点（ORDER_SLIPPAGE_BPS）的倍数：第 1 次 3 倍，之后逐级放宽
ORPHAN_SLIPPAGE_STEPS = (3, 6, 10, 15)
# 绝对上限（bps）：再宽有的交易所会以「离预言机价太远」直接拒单（Hyperliquid 报过）
ORPHAN_SLIPPAGE_CAP_BPS = 150.0


def orphan_slippage_bps(base_bps: float, failures: int) -> float:
    step = ORPHAN_SLIPPAGE_STEPS[min(max(0, failures), len(ORPHAN_SLIPPAGE_STEPS) - 1)]
    return min(float(base_bps) * step, ORPHAN_SLIPPAGE_CAP_BPS)


# 交易所说「这张只减仓的单会让仓位变大」= 那边其实已经没有仓位了（持仓接口慢了一拍）
REDUCE_ONLY_GONE = re.compile(r"REDUCE_ONLY_WOULD_INCREASE|reduce only order would increase", re.I)


# ── 3. 浮盈止盈 ──────────────────────────────────────────

@dataclass(frozen=True)
class TakeProfitEstimate:
    gross: float          # 两边按可成交价平掉的价差盈亏
    open_fees: float      # 这一轮开仓已经付掉的手续费
    close_fees: float     # 平仓要付的手续费（两边都按吃单算）
    net: float            # gross − open_fees − close_fees
    notional: float       # 单边名义额（按平仓价）
    threshold: float      # 要超过多少才平

    @property
    def triggered(self) -> bool:
        return self.net > self.threshold

    def text(self) -> str:
        return (f"按现在能成交的价格两边平掉：价差 {self.gross:+.2f}，开仓手续费 {self.open_fees:.2f}，"
                f"平仓手续费约 {self.close_fees:.2f} → 净 {self.net:+.2f} USDC"
                f"（门槛 {self.threshold:.2f}）")


def take_profit_estimate(
    legs: list[tuple[str, float, float | None]],
    exit_prices: dict[str, float | None],
    *, open_fees: float, close_fee_rates: dict[str, float],
    min_usd: float = 0.0, buffer_bps: float = 0.0,
) -> TakeProfitEstimate | None:
    """legs = [(所, 带符号数量, 开仓均价)]；exit_prices = 各所按这笔数量吃单平仓的成交均价。

    任何一项拿不到（开仓价 / 盘口）都返回 None —— 宁可不止盈，也不按猜的价平仓。
    门槛 = max(最少净赚 USDC, 名义额 × 缓冲 bps)：缓冲吸收「算完到下单之间」价格的变动。
    """
    gross = close_fees = 0.0
    notional = 0.0
    for venue, size, entry in legs:
        exit_px = exit_prices.get(venue)
        if not size or not entry or not exit_px or entry <= 0 or exit_px <= 0:
            return None
        gross += size * (exit_px - entry)
        close_fees += abs(size) * exit_px * float(close_fee_rates.get(venue, 0.0))
        notional = max(notional, abs(size) * exit_px)
    net = gross - float(open_fees) - close_fees
    threshold = max(float(min_usd), notional * float(buffer_bps) / 10_000.0)
    return TakeProfitEstimate(gross, float(open_fees), close_fees, net, notional, threshold)
