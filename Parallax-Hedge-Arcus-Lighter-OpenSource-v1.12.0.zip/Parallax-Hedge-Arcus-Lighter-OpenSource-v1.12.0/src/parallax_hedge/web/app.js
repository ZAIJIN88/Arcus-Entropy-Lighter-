'use strict';

const $ = (id) => document.getElementById(id);
const fmt = (v, d = 3) => (v === null || v === undefined || Number.isNaN(v) ? '—' : Number(v).toFixed(d));
const cls = (v) => (v > 0 ? 'pos' : v < 0 ? 'neg' : 'dim');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let costBps = 8;
let timer = null;

function tickClock() {
  $('clock').textContent = new Date().toLocaleTimeString('zh-CN', { hour12: false });
}

function renderVenues(venues) {
  const names = { arcus: ['Arcus', 'Arcus Perps · 全仓'], lighter: ['Lighter', 'Robinhood Chain'] };
  $('venue-grid').innerHTML = Object.entries(venues || {}).map(([key, v]) => {
    const [title, sub] = names[key] || [key, ''];
    const state = !v.ok ? 'bad' : v.stale ? 'stale' : '';
    const label = !v.ok ? '离线' : v.stale ? `沿用 ${v.age_seconds}s 前` : '正常';
    return `<div class="venue-card ${state}">
      <header><span class="pulse-dot"></span><div><b>${esc(title)}</b></div><i>${esc(label)}</i></header>
      <div class="row"><span>${esc(sub)}</span></div>
      <div class="row"><span>网络出口</span><b>${esc(v.proxy)}</b></div>
      ${v.error ? `<div class="row"><span style="color:var(--amber)">${esc(v.error).slice(0, 90)}</span></div>` : ''}
    </div>`;
  }).join('');
}

function renderWarnings(list) {
  const box = $('period-warnings');
  if (!list || !list.length) { box.innerHTML = ''; box.style.display = 'none'; return; }
  box.style.display = '';
  box.innerHTML = list.map((w) =>
    `<p class="assumption-note" style="border-left-color:var(--red);border-color:rgba(255,109,122,.28);background:rgba(255,109,122,.05)">
      <b style="color:var(--red)">周期自检告警</b> ${esc(w)}
    </p>`).join('');
}

function renderPositions(snap) {
  const grid = $('pos-grid');
  const note = $('acct-note');
  const acct = snap.accounts || {};
  const missing = [];
  if (!acct.arcus_configured) missing.push('Arcus 地址');
  if (!acct.lighter_configured) missing.push('Lighter 账户索引');
  const errs = Object.entries(acct.errors || {});
  if (missing.length) {
    note.innerHTML = `尚未配置 ${esc(missing.join(' 和 '))} —— 在 .env 里填上即可读取持仓。`
      + ` <b style="color:var(--green)">这一步只读公开数据，不需要任何私钥。</b>`;
  } else if (errs.length) {
    note.innerHTML = errs.map(([k, v]) =>
      `<span style="color:var(--amber)">${esc(k)} 账户读取失败：${esc(v).slice(0, 110)}</span>`).join('<br>');
  } else {
    note.innerHTML = `两边账户读取正常。危险线：任一条腿距强平价小于 `
      + `<b>${esc(snap.liquidation_warn_pct)}%</b> —— `
      + `<b style="color:var(--amber)">处置动作是双腿同时平掉，绝不单腿止损</b>`
      + `（单腿平掉的瞬间，另一条腿就变成满仓裸单边）。`
      + `引擎只处理「轮换任务」里启用的币种。`;
  }

  const held = (snap.rows || []).filter((r) => r.position && r.position.status !== 'flat');
  $('pos-meta').textContent = held.length ? `${held.length} 个币种有持仓` : '当前空仓';
  if (!held.length) {
    grid.innerHTML = '<div class="pos-empty">当前两边都没有持仓。'
      + '手动在两个所各开一笔小额反向仓，这里就会显示强平价和距离，用来核对数字读得对不对。</div>';
    return;
  }
  grid.innerHTML = held.map((r) => {
    const p = r.position;
    const legs = ['lighter', 'arcus'].map((v) => {
      const l = p[v];
      if (!l || !l.size) return '';
      const isRisk = p.riskiest_venue === v;
      const sane = l.liquidation_sane;
      return `<div class="leg ${isRisk ? 'risk' : 'safe'}">
        <span class="leg-venue">${v === 'lighter' ? 'LIGHTER' : 'ARCUS'}</span>
        <span class="leg-main">${esc(l.side)} ${fmt(Math.abs(l.size), 4)}
          <small>开仓 ${fmt(l.entry_price, 4)} · 标记 ${fmt(l.mark_price, 4)} · 强平 ${fmt(l.liquidation_price, 4)}${sane ? '' : ' ⚠方向异常'}</small></span>
        <span class="leg-dist">${l.distance_pct === null ? '—' : fmt(l.distance_pct, 2) + '%'}
          <small>距强平</small></span>
      </div>`;
    }).join('');
    return `<div class="pos-card ${esc(p.status)}">
      <header><b>${esc(r.asset)}</b><i>${esc(p.status_text)}</i></header>
      <div class="pos-sub">净敞口 ${fmt(p.net_size, 4)} · 浮盈亏 ${fmt(p.total_unrealized, 2)} USDC${p.is_hedged ? ' · 对冲完好' : ''}</div>
      ${legs}
    </div>`;
  }).join('');
}

function renderStats(s) {
  const tradable = (s.rows || []).filter((r) => r.tradable);
  const best = tradable[0];
  const cards = [
    ['共有币种', s.matched_count ?? 0, 'MATCHED', `两所交集 ${s.market_count ?? 0} 个市场`],
    ['可交易', tradable.length, 'TRADABLE', s.suspect_count ? `${s.suspect_count} 个存疑已排除` : '全部通过合理性检查'],
    ['最优净费率', best ? fmt(best.net_bps_per_hour, 3) : '—', 'BPS/H', best ? `${best.asset} · ${best.direction_label}` : '等待数据'],
    ['最优年化', best ? fmt(best.apr_pct, 1) + '%' : '—', 'APR', best && best.breakeven_hours ? `回本约 ${fmt(best.breakeven_hours, 1)} 小时` : '—'],
  ];
  $('stats-grid').innerHTML = cards.map(([label, value, unit, foot]) => `
    <div class="stat-card">
      <div class="stat-top"><span>${esc(label)}</span><i>${esc(unit)}</i></div>
      <div class="stat-value">${esc(value)}</div>
      <div class="stat-foot"><span class="trend neutral">●</span><span>${esc(foot)}</span></div>
    </div>`).join('');
}

function renderTable(rows) {
  const body = $('funding-body');
  if (!rows || !rows.length) {
    body.innerHTML = '<tr><td colspan="9" class="dim" style="text-align:center;padding:40px">暂无数据</td></tr>';
    return;
  }
  body.innerHTML = rows.map((r) => {
    const dirCls = r.direction === 'long_lighter_short_arcus' ? 'long-lighter' : 'short-lighter';
    const blocked = !r.tradable;
    return `<tr class="${blocked ? 'blocked' : ''}">
      <td><div class="asset-cell"><b>${esc(r.asset)}</b><small>${esc(r.lighter_symbol)} / ${esc(r.arcus_symbol)}${r.off_hours ? ' · 休市中（Arcus 杠杆上限降低）' : ''}</small></div></td>
      <td class="${cls(r.lighter_bps_per_hour)}">${fmt(r.lighter_bps_per_hour)}</td>
      <td class="${cls(r.arcus_bps_per_hour)}">${fmt(r.arcus_bps_per_hour)}</td>
      <td class="${cls(r.net_bps_per_hour)}"><b>${fmt(r.net_bps_per_hour)}</b></td>
      <td>${blocked
        ? `<span class="warn-badge" title="${esc(r.reason)}">存疑</span>`
        : `<span class="dir-pill ${dirCls}">${esc(r.direction_label)}</span>`}</td>
      <td class="${cls(r.apr_pct)}">${fmt(r.apr_pct, 1)}%</td>
      <td class="${cls(r.net_bps_per_day)}">${fmt(r.net_bps_per_day, 2)}</td>
      <td class="${r.breakeven_hours && r.breakeven_hours < 24 ? 'pos' : 'dim'}">${r.breakeven_hours ? fmt(r.breakeven_hours, 1) : '—'}</td>
      <td class="dim">${esc(r.max_leverage)}×</td>
    </tr>`;
  }).join('');
}

async function load(force) {
  const btn = $('refresh-button');
  btn.classList.add('rotating');
  try {
    const res = await fetch(`/api/funding?cost_bps=${encodeURIComponent(costBps)}${force ? '&refresh=true' : ''}`);
    const s = await res.json();
    renderVenues(s.venues);
    if (s.error) {
      $('conn-title').textContent = '拉取失败';
      $('conn-sub').textContent = String(s.error).slice(0, 40);
      $('conn-card').className = 'connection-card offline';
      renderTable([]);
      $('stats-grid').innerHTML = '';
      return;
    }
    const anyStale = Object.values(s.venues || {}).some((v) => v.stale);
    $('conn-card').className = 'connection-card' + (anyStale ? ' degraded' : '');
    $('conn-title').textContent = anyStale ? '数据有延迟' : '运行中';
    $('conn-sub').textContent = `${s.matched_count ?? 0} 个共有币种`;
    $('nav-count').textContent = s.matched_count ?? 0;
    $('table-meta').textContent = new Date((s.generated_at || 0) * 1000).toLocaleTimeString('zh-CN', { hour12: false }) + ' 更新';
    renderWarnings(s.period_warnings);
    renderPositions(s);
    renderStats(s);
    renderTable(s.rows);
    if (!assets.length) loadSpreads();
    $('system-dump').textContent = JSON.stringify({ ...s, rows: `(${(s.rows || []).length} 行，见表格)` }, null, 2);
  } catch (e) {
    $('conn-title').textContent = '连接失败';
    $('conn-sub').textContent = String(e.message || e).slice(0, 40);
    $('conn-card').className = 'connection-card offline';
  } finally {
    btn.classList.remove('rotating');
  }
}


// ── 账户与交易统计 ───────────────────────────────────────
const money = (v, d = 2) => (v === null || v === undefined || Number.isNaN(Number(v))
  ? '—'
  : (Number(v) < 0 ? '-$' : '$') + Math.abs(Number(v)).toLocaleString('en-US',
      { minimumFractionDigits: d, maximumFractionDigits: d }));
const signed = (v, d = 2) => (v === null || v === undefined || Number.isNaN(Number(v))
  ? '—' : (Number(v) > 0 ? '+' : '') + money(v, d));
const hhmm = (ts) => new Date(ts * 1000).toLocaleString('zh-CN',
  { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false });

function feeCell(v) {
  // 一笔都还没核对上时显示「—」，别让还不知道的手续费看起来像 $0.00
  if (v.fee_unknown > 0 && v.fee_unknown >= v.fills) return ['—', `${v.fee_unknown} 笔待交易所核对`];
  const main = money(v.fees, 2);
  return v.fee_unknown > 0 ? [main, `另有 ${v.fee_unknown} 笔待核对`] : [main, ''];
}
const MODE_LABEL = { ISOLATED: '逐仓', CROSS: '全仓', 'CROSS/ISOLATED': '全仓+逐仓' };

// 净损益 / 磨损：按「已经平掉的完整轮次」算，每平一次仓就更新（v1.6）
function roundNet(r) { return r && r.net_pnl !== null && r.net_pnl !== undefined ? signed(r.net_pnl) : '—'; }
function roundWear(r) { return r && r.wear_per_10k !== null && r.wear_per_10k !== undefined ? money(r.wear_per_10k) : '—'; }
function roundsNote(r) {
  if (!r || !r.rounds) return '平过仓后才有';
  return `已完成 ${r.rounds} 轮` + (r.fee_estimated ? ` · ${r.fee_estimated} 笔费估算` : '');
}

function ledgerCard(title, sub, bal, v, opts = {}) {
  const [fee, feeNote] = feeCell(v);
  const cells = opts.total
    ? [
        ['可用', bal ? money(bal.available) : '—', ''],
        ['浮动盈亏', bal ? signed(bal.unrealized_pnl) : '—', '', bal ? cls(bal.unrealized_pnl) : ''],
        ['交易量', money(v.volume, 0), `${v.fills} 笔成交`],
        ['手续费', fee, feeNote],
        ['净损益', roundNet(opts.rounds), roundsNote(opts.rounds),
          opts.rounds && opts.rounds.net_pnl !== null ? cls(opts.rounds.net_pnl) : ''],
        ['每万美元磨损', roundWear(opts.rounds),
          opts.rounds && opts.rounds.wear_per_10k !== null ? '每平一次仓更新' : '还没有平过仓'],
      ]
    : [
        ['可用', bal ? money(bal.available) : '—', ''],
        ['浮动盈亏', bal ? signed(bal.unrealized_pnl) : '—', '', bal ? cls(bal.unrealized_pnl) : ''],
        ['持仓', bal ? `${bal.open_positions} 个` : '—', bal && bal.mode ? (MODE_LABEL[bal.mode] || bal.mode) : ''],
        ['交易量', money(v.volume, 0), ''],
        ['手续费', fee, feeNote],
        ['成交', `${v.fills} 笔`, v.pending ? `${v.pending} 笔对账中` : (v.estimated ? `${v.estimated} 笔为估算` : '')],
      ];
  return `<div class="ledger-card${opts.total ? ' total' : ''}">
    <header><span class="venue-logo ${opts.logo || ''}">${esc(opts.mark || '∑')}</span>
      <div><b>${esc(title)}</b><small>${esc(sub)}</small></div>
      <i class="${bal ? '' : 'offline'}">${bal ? '账户权益' : '读取失败'}</i></header>
    <div class="ledger-equity">${bal ? money(bal.equity) : '—'}<small>USDC</small></div>
    <div class="ledger-cells">${cells.map(([k, val, note, c]) => `<div>
      <span>${esc(k)}</span><b class="${c || ''}">${esc(val)}</b>${note ? `<small>${esc(note)}</small>` : ''}
    </div>`).join('')}</div>
  </div>`;
}

function renderLedger(s) {
  const L = s.ledger || {};
  const venues = L.venues || {};
  const bal = s.balances || {};
  const empty = { volume: 0, fees: 0, fee_unknown: 0, fills: 0, pending: 0, estimated: 0,
                  net_pnl: null, wear_per_10k: null };
  $('ledger-grid').innerHTML = [
    ledgerCard('Lighter', 'Robinhood Chain', bal.lighter, venues.lighter || empty,
      { logo: 'lighter-logo', mark: 'L' }),
    ledgerCard('Arcus', 'Arcus Perps · 全仓', bal.arcus, venues.arcus || empty,
      { logo: 'arcus-logo', mark: 'A' }),
    ledgerCard('合计', '两边加总 · 全部任务', bal.total, L.total || empty,
      { total: true, rounds: L.rounds }),
  ].join('');

  const total = L.total || empty;
  const rec = s.reconciler || {};
  const meta = [];
  if (L.since) meta.push(`统计起点 ${hhmm(L.since)}`);
  if (total.pending) meta.push(`${total.pending} 笔对账中`);
  if (rec.at) meta.push(`上次对账 ${new Date(rec.at * 1000).toLocaleTimeString('zh-CN', { hour12: false })}`);
  $('ledger-meta').textContent = meta.join(' · ') || (s.dry_run ? '演练模式' : '还没有成交');

  const notes = [];
  if (s.dry_run) notes.push('<b>演练模式</b>：这里的交易量是模拟成交（按盘口参考价计），没有真实手续费。');
  Object.entries(s.account_errors || {}).forEach(([k, v]) =>
    notes.push(`<b>${esc(k)} 账户读取失败</b>：${esc(String(v).slice(0, 120))}`));
  (rec.errors || []).forEach((e) => notes.push(`<b>对账</b>：${esc(String(e).slice(0, 160))}`));
  const note = $('ledger-note');
  note.style.display = notes.length ? '' : 'none';
  note.innerHTML = notes.join('<br>');

  const enabled = {};
  (s.tasks || []).forEach((t) => { enabled[t.asset] = t.enabled; });
  const byAsset = L.by_asset || {};
  const names = Array.from(new Set([...Object.keys(byAsset), ...Object.keys(enabled)])).sort();
  $('ledger-body').innerHTML = names.length
    ? names.map((a) => {
        const r = byAsset[a] || { lighter: empty, arcus: empty, total: { ...empty, realized_pnl: 0, pnl_unknown: 0 }, opens: 0 };
        const t = r.total;
        const state = a in enabled ? (enabled[a] ? '' : '<small class="dim">（已停用）</small>')
                                   : '<small class="dim">（任务已删除）</small>';
        const [fee, feeNote] = feeCell(t);
        const rd = r.rounds;
        const rdTip = rd ? `已完成 ${rd.rounds} 轮（两边平仓后计入）`
          + (rd.skipped ? `；${rd.skipped} 轮数据不全已跳过` : '')
          + (rd.fee_estimated ? `；${rd.fee_estimated} 笔 Arcus 手续费为估算` : '')
          + (rd.in_progress ? '；当前持仓这一轮平仓后计入' : '') : '';
        return `<tr>
          <td><div class="asset-cell"><b>${esc(a)}</b>${state}</div></td>
          <td>${esc(r.opens)}</td>
          <td>${money(r.lighter.volume, 0)}</td>
          <td>${money(r.arcus.volume, 0)}</td>
          <td><b>${money(t.volume, 0)}</b></td>
          <td title="${esc(feeNote)}">${fee}${t.fee_unknown ? ' <span class="dim">*</span>' : ''}</td>
          <td title="${esc(rdTip)}" class="${rd && rd.rounds ? cls(rd.spread_pnl) : 'dim'}">${rd && rd.rounds ? signed(rd.spread_pnl) : '—'}</td>
          <td title="${esc(rdTip)}" class="${rd && rd.net_pnl !== null ? cls(rd.net_pnl) : 'dim'}">${roundNet(rd)}</td>
          <td title="${esc(rdTip)}" class="${rd && rd.wear_per_10k !== null ? '' : 'dim'}">${roundWear(rd)}</td>
        </tr>`;
      }).join('')
    : '<tr><td colspan="9" class="dim" style="text-align:center;padding:26px">还没有成交记录。</td></tr>';
}

// ── 侧栏：日交易量仪表盘 ─────────────────────────
function usdShort(v) {
  if (v === null || v === undefined || !Number.isFinite(Number(v))) return '—';
  const n = Number(v);
  if (n >= 1e8) return '$' + (n / 1e8).toFixed(2) + '亿';
  if (n >= 1e4) return '$' + (n / 1e4).toFixed(n >= 1e6 ? 0 : 1) + '万';
  return '$' + n.toFixed(0);
}

function gaugePoint(frac, radius) {
  const a = Math.PI * (1 - Math.min(1, Math.max(0, frac)));   // 左 = 0，右 = 满
  return [110 + radius * Math.cos(a), 110 - radius * Math.sin(a)];
}

async function loadCapacity() {
  let c;
  try { c = await fetch('/api/capacity').then((r) => r.json()); } catch (e) { return; }
  const cur = Number(c.current_daily) || 0;
  const max = Number(c.max_daily) || 0;
  const actual = Number(c.actual_24h) || 0;
  const scale = Math.max(max, cur, actual) || 1;
  const frac = cur / scale;
  $('gauge-fill').setAttribute('stroke-dasharray', `${(frac * 100).toFixed(2)} 100`);
  $('gauge-needle').setAttribute('transform', `rotate(${(-90 + 180 * frac).toFixed(2)} 110 110)`);
  // 刻度：0、25%、50%、75%、100% 的理论上限
  $('gauge-ticks').innerHTML = [0, 0.25, 0.5, 0.75, 1].map((f) => {
    const [x1, y1] = gaugePoint(f, 98); const [x2, y2] = gaugePoint(f, 104);
    // 两端的数字写在弧线端点正下方，不出卡片边界
    const label = f === 0 || f === 1 ? `<text class="gauge-tick-label" x="${f === 0 ? 20 : 200}" y="126" text-anchor="middle">${f === 0 ? '0' : usdShort(scale)}</text>` : '';
    return `<line class="gauge-tick" x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" />${label}`;
  }).join('');
  const mark = $('gauge-actual');
  if (actual > 0) {
    const [x1, y1] = gaugePoint(actual / scale, 80); const [x2, y2] = gaugePoint(actual / scale, 100);
    mark.setAttribute('x1', x1.toFixed(1)); mark.setAttribute('y1', y1.toFixed(1));
    mark.setAttribute('x2', x2.toFixed(1)); mark.setAttribute('y2', y2.toFixed(1));
    mark.style.display = '';
  } else { mark.style.display = 'none'; }
  $('gauge-current').textContent = usdShort(cur);
  $('gauge-max').textContent = max > 0 ? usdShort(max) + ' / 天' : '—';
  $('gauge-actual-text').textContent = usdShort(actual);
  $('gauge-pct').textContent = max > 0 ? `占上限 ${(cur / max * 100).toFixed(1)}%` : '—';
  const lines = ['【当前任务预估】两所合计 = 每天轮数 × 4 × 单边金额'];
  (c.tasks || []).forEach((t) => lines.push(
    `  ${t.asset}：单边 ${usdShort(t.notional)}（${t.notional_source}）× 每天 ${Number(t.rounds_per_day).toFixed(1)} 轮`
    + `（持有 ${Number(t.hold_hours).toFixed(2)}h + 开销 ${Math.round(t.overhead_seconds)}s）≈ ${usdShort(t.daily_volume)}`));
  if (!(c.tasks || []).length) lines.push('  没有启用中的任务');
  lines.push('', '【理论上限】两边最大杠杆 + 全部权益，同时守住开仓门槛（离强平 ≥ 设定值）');
  lines.push(`  两边各能同时持有 ${usdShort(c.max_notional)}，被 ${c.max_binding || '—'} 卡住`);
  lines.push(`  按最短轮换 0.1 小时、吃单开平，每天约 ${Number(c.max_rounds_per_day || 0).toFixed(0)} 轮`);
  lines.push(`  Lighter 权益 ${usdShort(c.equity?.lighter)}，Arcus 权益 ${usdShort(c.equity?.arcus)}`);
  lines.push('', '青色刻度 = 近 24 小时实际成交（两所合计）。以上都是估算，不影响交易。');
  $('gauge-card').title = lines.join('\n');
}

async function loadStats() {
  try {
    const s = await fetch('/api/stats').then((r) => r.json());
    renderLedger(s);
  } catch (e) {
    $('ledger-meta').textContent = '统计加载失败';
  }
}

// ── 轮换任务 ─────────────────────────────────────────────
let assets = [];
let spreadSignature = '';

// 币种下拉：按两所价差从窄到宽排（后台每 10 分钟扫一次）。
// 挂单模式按 Lighter 价差排（Arcus 那边是挂单，不付价差），吃单模式按两边之和排。
async function loadSpreads() {
  try {
    const r = await fetch('/api/spreads').then((x) => x.json());
    const list = r.assets || [];
    const label = (x) => {
      if (x.total_bps === undefined) return `${x.asset}  · 价差待扫描`;
      const main = r.maker ? x.lighter_bps : x.total_bps;
      return `${x.asset}  · ${fmt(main, 2)} bps（L ${fmt(x.lighter_bps, 2)} / A ${fmt(x.arcus_bps, 2)}）`;
    };
    const sig = list.map(label).join('|');
    if (!list.length || sig === spreadSignature) return;
    spreadSignature = sig;
    assets = list.map((x) => x.asset);
    const sel = $('f-asset');
    const keep = sel.value;
    sel.innerHTML = list.map((x) => `<option value="${esc(x.asset)}">${esc(label(x))}</option>`).join('');
    if (keep && assets.includes(keep)) sel.value = keep;
    const hint = $('spread-hint');
    if (hint) {
      hint.textContent = r.scanned_at
        ? `按${r.maker ? ' Lighter ' : '两所合计'}价差从窄到宽排序 · ${new Date(r.scanned_at * 1000).toLocaleTimeString('zh-CN', { hour12: false })} 扫描`
        : (r.scanning ? '正在扫描两所价差…' : '价差扫描将在启动后约 15 秒开始');
    }
  } catch (e) { /* 下拉框不该因为这个崩掉 */ }
}
let formTouched = false;

function fillFormFromTask(tasks) {
  // 选中已有任务时把它的设置带进表单，免得改一个字段时把别的字段覆盖成默认值
  if (formTouched) return;
  const task = tasks.find((t) => t.asset === $('f-asset').value);
  if (!task) { $('f-order-type').value = orderTypeOf(null); return; }
  $('f-leverage').value = task.leverage;
  $('f-rotation').value = task.rotation_hours;
  $('f-rotation-max').value = task.rotation_hours_max ?? '';
  $('f-notional').value = task.notional_usdc ?? '';
  $('f-notional-max').value = task.notional_usdc_max ?? '';
  $('f-order-type').value = orderTypeOf(task);
}

// 任务没单独设过就跟随 .env 的 ARCUS_MAKER
let defaultMaker = false;
function orderTypeOf(task) {
  if (task && (task.arcus_order_type === 'limit' || task.arcus_order_type === 'market')) return task.arcus_order_type;
  return defaultMaker ? 'limit' : 'market';
}

// 两边此刻真正用的杠杆：各自不超过该所上限（Arcus 美股休市时上限会降）
function levSub(task) {
  const e = task.effective_leverage;
  if (!e || (e.lighter === Number(task.leverage) && e.arcus === Number(task.leverage))) return '杠杆';
  return `实际 L ${e.lighter}× · A ${e.arcus}×`;
}
function levTip(task) {
  const e = task.effective_leverage;
  if (!e) return '';
  return `任务设 ${task.leverage}×；Lighter 上限 ${e.lighter_max ? Math.floor(e.lighter_max) + '×' : '未知'}，`
    + `Arcus 当前上限 ${e.arcus_max ? Math.floor(e.arcus_max) + '×' : '未知'}（美股等品种休市时会降低）。`
    + '每个所按 min(任务值, 该所上限) 设置。';
}

function amountText(task) {
  const lo = task.notional_usdc, hi = task.notional_usdc_max;
  if (!lo) return '开满';
  if (hi && Number(hi) > Number(lo)) return `${esc(lo)}–${esc(hi)} U`;
  return `${esc(lo)} U`;
}

function renderUnmanaged(list) {
  const boxes = ['unmanaged-warn', 'unmanaged-warn-top'].map((id) => $(id)).filter(Boolean);
  if (!boxes.length) return;
  if (!list || !list.length) {
    boxes.forEach((b) => { b.innerHTML = ''; b.style.display = 'none'; });
    return;
  }
  const html = list.map((u) => {
    const dist = u.min_distance_pct === null || u.min_distance_pct === undefined
      ? '—' : fmt(u.min_distance_pct, 2) + '%';
    return `<p class="assumption-note" style="border-left-color:var(--red);border-color:rgba(255,109,122,.3);background:rgba(255,109,122,.06)">
      <b style="color:var(--red)">${esc(u.asset)} 有持仓，但没有启用中的任务在管它。</b>
      当前状态「${esc(u.status_text || '')}」，距强平 ${esc(dist)}。
      面板会标红，但<b>引擎不会对它动手</b> —— 引擎只处理下面列表里启用的币种。
      要让程序接管，就给它建一个任务并启用；否则请自己盯着或手动平掉。
    </p>`;
  }).join('');
  boxes.forEach((b) => { b.style.display = ''; b.innerHTML = html; });
}

function planChip(plan, urgent) {
  const map = { open: ['on', '已开仓'], close: ['hold', '已平仓'], idle: ['off', '闲置'],
                blocked: ['blocked', '受阻'], flatten_orphan: ['urgent', '孤腿抢救'],
                open_failed: ['urgent', '开仓失败'], close_failed: ['urgent', '平仓失败'],
                flatten_orphan_failed: ['urgent', '抢救失败'],
                adopt: ['hold', '接管'], ledger: ['off', '账本'], rebase: ['off', '基准重设'],
                maker_wait: ['off', '未成交'], maker_started: ['hold', '挂单中'],
                maker_busy: ['hold', '挂单中'],
                topup: ['on', '已补仓'], topup_failed: ['urgent', '补仓失败'],
                topup_stop: ['hold', '叫停补仓'],
                arcus_bound: ['urgent', 'Arcus 价格带'], orphan_rehedged: ['hold', '补回对冲'],
                close_rolled_back: ['hold', '平仓已回滚'],
                protect: ['on', '保护单'], protect_failed: ['urgent', '保护单失败'],
                protect_cleared: ['off', '撤保护单'],
                halted: ['urgent', '通道熔断'], halt_cleared: ['on', '恢复交易'],
                orphan_false: ['off', '误报已排除'],
                close_hedge_failed: ['urgent', '平仓未成'],
                error: ['urgent', '出错'] };
  const [cls, text] = map[plan] || ['off', plan];
  return `<span class="chip ${urgent ? 'urgent' : cls}">${esc(text)}</span>`;
}

// v1.10 交易所保护单：任务行里显示上下触发价，失败标红
function protectLine(p, task) {
  if (!p || !p.enabled || !task.opened_at) return '';
  const x = (p.assets || {})[task.asset];
  if (!x) return '<div class="muted">保护单：等下一轮挂</div>';
  const lv = (x.upper && x.lower) ? `↑${Number(x.upper).toPrecision(5)} ↓${Number(x.lower).toPrecision(5)}` : '';
  return x.ok
    ? `<div class="muted" style="color:var(--green)" title="程序断线时，价格到这两个位置由交易所自动两边一起平">🛡 保护单 ${lv}</div>`
    : `<div class="muted" style="color:var(--red)" title="${esc(x.error || '')}">⚠ 保护单 ${lv} ${esc((x.error || '').slice(0, 24))}</div>`;
}

// v1.8 下单通道熔断：某个所的 API 钱包 / 密钥失效 → 顶上标红、开平仓全部暂停
function renderHalts(halts) {
  let box = $('halt-banner');
  if (!box) {
    box = document.createElement('div');
    box.id = 'halt-banner';
    box.className = 'halt-banner';
    const anchor = $('dry-banner');
    anchor.parentNode.insertBefore(box, anchor);
  }
  if (!halts.length) { box.style.display = 'none'; box.innerHTML = ''; return; }
  box.style.display = '';
  const items = halts.map((h) => `<li><b>${esc(h.label)}</b> 下单通道失效：${esc(h.reason)}`
    + `（${new Date(h.since * 1000).toLocaleString()} 起）</li>`).join('');
  box.innerHTML = `<div><b>⚠ 已暂停所有开平仓</b> —— 两腿保持现状不动，不会出现「平掉一边、另一边平不掉」。</div>`
    + `<ul>${items}</ul>`
    + `<div>请到交易所检查 API 钱包 / 密钥（过期、被删、被新钱包顶掉），换好后点下面的按钮；`
    + `程序也会每 5 分钟自动核对一次，通过就自动恢复。孤腿抢救不受影响（只要孤腿所在的所还能下单）。</div>`
    + `<button class="mini-btn" id="resume-trading">我已处理，恢复交易</button>`;
  $('resume-trading').onclick = async () => {
    await fetch('/api/resume-trading', { method: 'POST' });
    loadTasks();
  };
}

async function loadTasks() {
  try {
    const [t, c] = await Promise.all([
      fetch('/api/tasks').then((r) => r.json()),
      fetch('/api/cycles?limit=40').then((r) => r.json()),
    ]);
    const pill = $('mode-pill');
    if (pill) {
      pill.className = 'mode-pill' + (t.dry_run ? '' : ' live');
      pill.querySelector('b').textContent = t.dry_run ? '演练 · 不下单' : '实盘 · 会下单';
    }
    renderUnmanaged(t.unmanaged);
    defaultMaker = !!t.maker;
    const banner = $('dry-banner');
    banner.className = 'dry-banner' + (t.dry_run ? '' : ' live');
    banner.innerHTML = t.dry_run
      ? `<b>演练模式</b> —— 引擎照常做全部判断并记录意图，但<b>不会提交任何订单</b>。`
        + (t.maker ? ` 挂单模式已开（演练里仍按吃单模拟成交）。` : '')
        + ` 开仓门槛：离强平 ≥ ${esc(t.min_corridor_pct)}%；平仓线 ${esc(t.close_corridor_pct)}%；每 ${esc(t.cycle_seconds)} 秒一轮。`
        + ` 确认判断无误后，把 .env 里的 DRY_RUN 改成 false 再重启。`
      : `<b>实盘模式</b> —— 引擎会真实下单。`
        + `Arcus 下单方式按任务设置（没单独设的任务：${t.maker ? '限价挂单' : '市价吃单'}）。`
        + `限价挂单 0 手续费，每次最多等 ${esc(t.maker_wait_seconds)} 秒，在后台等；风控平仓一律立刻吃单。`
        + (t.bell ? (t.bell.healthy ? ' 成交推送：<b style="color:var(--green)">已连接</b>（成交后立刻对冲）。'
                                    : ' 成交推送：<b style="color:var(--amber)">未连接</b>，已退回每 0.5 秒查一次成交。') : '')
        + `开仓门槛 ${esc(t.min_corridor_pct)}%，平仓线 ${esc(t.close_corridor_pct)}%，`
        + ` 每 ${esc(t.cycle_seconds)} 秒一轮。`;
    renderHalts(t.halts || []);

    $('nav-tasks').textContent = (t.tasks || []).length;
    const byAsset = {};
    (t.decisions || []).forEach((d) => { byAsset[d.asset] = d; });

    $('task-list').innerHTML = (t.tasks || []).length
      ? t.tasks.map((task) => {
          const d = byAsset[task.asset];
          const held = task.opened_at
            ? ((Date.now() / 1000 - task.opened_at) / 3600).toFixed(2) + ' 小时'
            : '空仓';
          const lo = Number(task.rotation_hours);
          const hi = task.rotation_hours_max ? Number(task.rotation_hours_max) : lo;
          const random = hi > lo;
          // 和调度器同一个口径：抽到的时长夹进【当前】区间
          const draw = task.hold_hours === null || task.hold_hours === undefined
            ? null : Math.min(Math.max(Number(task.hold_hours), lo), hi);
          const rotation = random ? `${esc(lo)}–${esc(hi)}h` : `${esc(lo)}h`;
          const rotationSub = random
            ? (task.opened_at && draw !== null ? `本轮随机 ${draw.toFixed(2)}h` : '随机轮换')
            : '轮换周期';
          return `<div class="task-row">
            <div><b>${esc(task.asset)}</b></div>
            <div>${esc(task.leverage)}×<div class="muted" title="${esc(levTip(task))}">${levSub(task)}</div></div>
            <div>${amountText(task)}<div class="muted">${orderTypeOf(task) === 'limit' ? 'Arcus 限价挂单' : 'Arcus 市价吃单'}</div></div>
            <div>${rotation}<div class="muted">${esc(rotationSub)}</div></div>
            <div>${esc(held)}<div class="muted">${task.open_direction ? esc(task.open_direction.startsWith('long') ? 'Lighter 多' : 'Lighter 空') : '当前持仓'}</div></div>
            <div>${task.corridor_at_open ? fmt(task.corridor_at_open, 2) + '%' : '—'}<div class="muted">开仓走廊</div>${protectLine(t.protection, task)}</div>
            <div>${d ? planChip(d.plan, d.urgent) : ''}<div class="muted" title="${esc(d?.reason || '')}">${esc((d?.reason || '').slice(0, 40))}</div></div>
            <div style="display:flex;gap:6px">
              <button class="mini-btn" data-toggle="${esc(task.asset)}" data-on="${task.enabled ? 0 : 1}">${task.enabled ? '停用' : '启用'}</button>
              <button class="mini-btn danger" data-del="${esc(task.asset)}">删</button>
            </div>
          </div>`;
        }).join('')
      : '<div class="pos-empty">还没有任务。上面选个币种、设好杠杆和轮换周期就能建。</div>';
    fillFormFromTask(t.tasks || []);

    $('cycle-log').innerHTML = (c.cycles || []).length
      ? c.cycles.map((x) => `<div class="log-line">
          <time>${new Date(x.created_at * 1000).toLocaleTimeString('zh-CN', { hour12: false })}</time>
          <span>${esc(x.asset)}</span>
          <span>${planChip(x.plan, x.urgent)} ${esc(x.reason || '')}</span>
        </div>`).join('')
      : '<div class="pos-empty">暂无执行记录。</div>';
  } catch (e) { /* 面板不该因为这个崩掉 */ }
}

document.addEventListener('click', async (ev) => {
  const t = ev.target.closest('[data-toggle]');
  const d = ev.target.closest('[data-del]');
  if (t) {
    await fetch('/api/tasks', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ asset: t.dataset.toggle, enabled: t.dataset.on === '1' }) });
    loadTasks();
  } else if (d) {
    const res = await fetch('/api/tasks/' + encodeURIComponent(d.dataset.del), { method: 'DELETE' });
    if (!res.ok) alert((await res.json()).detail || '删除失败');
    loadTasks();
  }
});

$('f-save').addEventListener('click', async () => {
  const lo = Number($('f-rotation').value);
  const hiRaw = $('f-rotation-max').value.trim();
  const hi = hiRaw === '' ? null : Number(hiRaw);
  if (!(lo > 0)) { alert('轮换周期最短值必须大于 0'); return; }
  if (hi !== null && !(hi >= lo)) { alert(`最长 ${hi} 小时不能小于最短 ${lo} 小时`); return; }
  const body = {
    asset: $('f-asset').value,
    leverage: Number($('f-leverage').value),
    rotation_hours: lo,
    rotation_hours_max: hi,
    notional_usdc: $('f-notional').value === '' ? null : Number($('f-notional').value),
    notional_usdc_max: $('f-notional-max').value === '' ? null : Number($('f-notional-max').value),
    arcus_order_type: $('f-order-type').value,
  };
  if (body.notional_usdc_max !== null && body.notional_usdc === null) { alert('填了开仓金额最大值，就必须同时填最小值'); return; }
  if (body.notional_usdc_max !== null && !(body.notional_usdc_max >= body.notional_usdc)) {
    alert(`开仓金额最大 ${body.notional_usdc_max} 不能小于最小 ${body.notional_usdc}`); return; }
  const res = await fetch('/api/tasks', { method: 'POST',
    headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (!res.ok) { alert((await res.json()).detail || '保存失败'); return; }
  formTouched = false;
  loadTasks();
});

['f-leverage', 'f-rotation', 'f-rotation-max', 'f-notional', 'f-notional-max'].forEach((id) =>
  $(id).addEventListener('input', () => { formTouched = true; }));
$('f-order-type').addEventListener('change', () => { formTouched = true; });
$('f-asset').addEventListener('change', () => { formTouched = false; loadTasks(); });

$('run-preflight').addEventListener('click', async () => {
  const btn = $('run-preflight');
  const box = $('preflight-box');
  btn.textContent = '检查中…';
  try {
    const r = await fetch('/api/preflight', { method: 'POST' }).then((x) => x.json());
    const mark = (ok) => ok
      ? '<span style="color:var(--green)">通过</span>'
      : '<span style="color:var(--red)">未过</span>';
    const checks = (r.checks || []).map((c) => `<div class="log-line">
      <span>${mark(c.ok)}</span><span>${esc(c.name)}</span><span>${esc(c.detail)}</span>
    </div>`).join('');
    const plans = (r.plans || []).map((p) => `<div class="log-line">
      <span>${mark(p.ok)}</span><span>${esc(p.asset)}${p.enabled ? '' : '（停用）'}</span>
      <span>${p.quantity !== undefined
        ? `${esc(p.direction_label || '')} 数量 <b>${fmt(p.quantity, 6)}</b>`
          + (p.lighter_leverage ? ` · 杠杆 L ${esc(p.lighter_leverage)}× / A ${esc(p.arcus_leverage)}×` : '')
          + ` · 名义 ${fmt(p.notional, 2)} USDC · 走廊 ${fmt(p.corridor_pct, 2)}%`
          + ` · 最小量 ${esc(p.min_quantity)}`
          + (p.aligned ? '' : ' <b style="color:var(--red)">数量未对齐精度</b>')
          + ` — ${esc(p.detail)}`
        : esc(p.detail)}</span>
    </div>`).join('');
    box.style.display = '';
    box.innerHTML = `<div class="panel" style="padding:18px 20px">
      <header class="panel-header compact">
        <div><span class="kicker">PREFLIGHT</span><h2>实盘预检</h2></div>
        <span class="chip ${r.ready ? 'on' : 'urgent'}">${esc(r.summary)}</span>
      </header>
      <div style="margin-top:12px">${checks}${plans}</div>
      <p class="acct-note" style="margin-top:14px">
        预检【不会下任何单】。全部通过之后，把 .env 里的 <b>DRY_RUN 改成 false</b> 并重启，
        才会真正下单。建议第一次把「开仓金额」设到 20~30 USDC，用一轮真实开平
        把签名、精度、报文这层走通 —— 成本约 8 bps，也就是两三分钱。
      </p>
    </div>`;
  } catch (e) {
    box.style.display = '';
    box.innerHTML = `<p class="assumption-note">预检失败：${esc(e.message || e)}</p>`;
  } finally { btn.textContent = '实盘预检'; }
});

$('run-cycle').addEventListener('click', async () => {
  $('run-cycle').textContent = '运行中…';
  try { await fetch('/api/cycle', { method: 'POST' }); } finally {
    $('run-cycle').textContent = '立即跑一轮'; loadTasks();
  }
});

document.querySelectorAll('.nav-item').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('.nav-item').forEach((x) => x.classList.remove('active'));
  b.classList.add('active');
  const page = b.dataset.page;
  // 用 .active 类切换，不要碰行内 display ——
  // CSS 里是 .page{display:none} + .page.active{display:block}，
  // 设 style.display='' 会落回那条隐藏规则，页面永远出不来。
  ['funding', 'tasks', 'basis', 'system'].forEach((name) => {
    $('page-' + name).classList.toggle('active', page === name);
  });
  $('page-title').textContent = { funding: '资金费总览', tasks: '轮换任务', basis: '基差监控', system: '系统' }[page];
  if (page === 'tasks') loadTasks();
  if (page === 'basis') loadBasis();
}));

$('refresh-button').addEventListener('click', () => { load(true); loadStats(); });
$('cost-input').addEventListener('change', (e) => {
  const v = Number(e.target.value);
  if (Number.isFinite(v) && v >= 0) { costBps = v; load(false); }
  else e.target.value = costBps;
});

fetch('/api/status').then((r) => r.json()).then((s) => {
  $('meta-version').textContent = s.version || '—';
  $('meta-port').textContent = s.port || '—';
  const eff = s.effective || {};
  const dump = $('system-dump');
  if (dump) {
    dump.textContent = '当前实际生效的设置（不管 .env 里写没写，这里是准的）：\n\n'
      + Object.entries(eff).map(([k, v]) => `  ${k} = ${v}`).join('\n')
      + `\n\n  代理 · Arcus = ${s.proxies?.arcus || '—'}`
      + `\n  代理 · Lighter  = ${s.proxies?.lighter || '—'}`;
  }
}).catch(() => {});

// ── v1.9 基差监控 ──
const bps = (v, d = 1) => (v === null || v === undefined || !Number.isFinite(v)) ? '—' : (v >= 0 ? '+' : '') + v.toFixed(d);
const num = (v, d = 1) => (v === null || v === undefined || !Number.isFinite(v)) ? '—' : v.toFixed(d);
async function loadBasis() {
  if (!$('page-basis').classList.contains('active')) return;
  let b;
  try { b = await fetch('/api/basis').then((r) => r.json()); } catch { return; }
  const banner = $('basis-banner');
  if (!b.enabled) { banner.textContent = '基差监控没开（.env 里 BASIS_MONITOR=false）。'; return; }
  const st = b.streams || {};
  const ws = (x) => x?.connected
    ? `<b style="color:var(--green)">推送已连接</b>（${x.books}/${x.subscribed} 个币有盘口${x.books < x.subscribed ? '，其余用 REST 慢慢补' : ''}）`
    : `<b style="color:var(--amber)">推送未连接，REST 慢轮询中</b>${x?.error ? '（' + esc(x.error) + '）' : ''}`;
  const et = b.entry_timing || {};
  banner.innerHTML = `只读，不下单。每 ${esc(b.interval)} 秒记一次两边盘口，择时看的是 1 分钟平均基差，「近期平均」看最近 ${esc(b.window_hours)} 小时（至少攒够 30 分钟才算数）。`
    + ` Lighter ${ws(st.lighter)}，Arcus ${ws(st.arcus)}。`
    + (et.enabled ? ` 择时开仓已开：1 分钟平均基差偏离近期平均、对开仓方向有利 ≥ ${esc(et.edge_bps)} bps 才开，最多等 ${esc(et.max_wait_minutes)} 分钟。`
                  : ' 择时开仓未开（ENTRY_TIMING=false）。')
    + ((b.exit_timing || {}).enabled ? ` 择时平仓已开：持有到期后等对平仓有利 ≥ ${esc(b.exit_timing.edge_bps)} bps 再平，最多等 ${esc(b.exit_timing.max_wait_minutes)} 分钟（风控平仓不等）。` : ' 择时平仓未开（EXIT_TIMING=false）。');
  $('basis-meta').textContent = new Date().toLocaleTimeString();
  const rows = b.rows || [];
  $('basis-body').innerHTML = rows.length ? rows.map((r) => {
    const dev = r.deviation;
    const hot = r.sd && dev !== null && Math.abs(dev) >= 2 * r.sd;
    return `<tr${r.fresh ? '' : ' class="dim"'}>
      <td style="text-align:left">${esc(r.asset)}</td>
      <td>${bps(r.mid)}</td><td>${bps(r.smooth)}</td><td>${r.ready ? bps(r.mean) : '<span class="dim">攒数据中</span>'}</td>
      <td${hot ? ' style="color:var(--amber);font-weight:600"' : ''}>${r.ready ? bps(dev) : '—'}</td>
      <td>${r.ready ? num(r.sd) : '—'}</td>
      <td>${bps(r.sell_e)}</td><td>${bps(r.buy_e)}</td><td>${num(r.cross_cost)}</td>
      <td>${num(r.e_spread, 2)}</td><td>${num(r.a_spread, 2)}</td>
      <td>${num(r.e_age, 1)}s / ${num(r.a_age, 1)}s</td>
      <td>${r.notional ? Math.round(r.notional) : '—'}</td>
      <td>${num(r.coverage_min / 60, 1)} h</td></tr>`;
  }).join('') : '<tr><td colspan="14" class="dim" style="text-align:center;padding:26px">还没有样本（等推送连上）</td></tr>';
}
$('bt-run').addEventListener('click', async () => {
  const box = $('bt-box');
  box.innerHTML = '回测中…';
  try {
    const r = await fetch(`/api/basis/backtest?days=${$('bt-days').value}&arcus=${$('bt-arcus').value}&delay=${$('bt-delay').value}`).then((x) => x.json());
    const assets = Object.entries(r.assets || {});
    if (!assets.length) { box.innerHTML = '还没有足够的样本。'; return; }
    const head = `<p class="dim">信号出现后 ${esc(r.delay_sec)} 秒成交 · 一来回手续费 ${num(2 * (r.arcus_fee_bps + r.lighter_fee_bps), 2)} bps`
      + `（Arcus ${num(r.arcus_fee_bps, 2)} × 2 + Lighter ${num(r.lighter_fee_bps, 2)} × 2）</p>`;
    box.innerHTML = head + assets.map(([asset, a]) => {
      const best = a.best ? `<b style="color:var(--green)">最好的阈值 ${a.best.threshold} bps：每天约 ${num(a.best.per_day)} 次，平均每次净 ${bps(a.best.avg_net_bps, 2)} bps，累计 ${bps(a.best.total_net_bps)} bps</b>`
        : '<b style="color:var(--red)">没有哪个阈值是赚钱的</b>';
      return `<div style="margin:14px 0 4px"><b>${esc(asset)}</b> · ${a.samples} 条样本 / ${num(a.hours)} 小时 · 平均基差 ${bps(a.mid_mean)}，波动 ${num(a.mid_sd)}，一来回价差成本中位数 ${num(a.cross_cost)} · ${best}</div>
        <table class="funding-table ledger-table"><thead><tr><th>阈值 k</th><th>笔数</th><th>每天</th><th>平均每笔净</th><th>胜率</th><th>平均持有</th><th>累计净 bps</th></tr></thead><tbody>`
        + a.rows.map((x) => `<tr><td>${x.threshold}</td><td>${x.trades}</td><td>${num(x.per_day)}</td>
            <td>${bps(x.avg_net_bps, 2)}</td><td>${x.win_rate === null ? '—' : Math.round(x.win_rate * 100) + '%'}</td>
            <td>${x.avg_hold_min === null ? '—' : num(x.avg_hold_min, 0) + ' 分钟'}</td>
            <td style="color:${x.total_net_bps > 0 ? 'var(--green)' : x.total_net_bps < 0 ? 'var(--red)' : 'inherit'}">${bps(x.total_net_bps)}</td></tr>`).join('')
        + '</tbody></table>';
    }).join('');
  } catch (e) { box.innerHTML = '回测失败：' + esc(String(e)); }
});

tickClock();
setInterval(tickClock, 1000);
setInterval(loadBasis, 10000);
loadSpreads();
setInterval(loadSpreads, 30000);
load(true);
loadStats();
timer = setInterval(() => { load(false); loadStats(); }, 15000);
loadTasks();
setInterval(loadTasks, 10000);
loadCapacity();
setInterval(loadCapacity, 30000);
