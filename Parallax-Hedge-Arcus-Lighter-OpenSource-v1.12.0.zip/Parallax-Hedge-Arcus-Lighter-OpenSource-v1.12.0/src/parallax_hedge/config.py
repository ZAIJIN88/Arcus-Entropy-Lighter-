"""配置：从 .env 读，全部可留空（没配私钥时只读面板照样能用）。"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote

from dotenv import dotenv_values

LIGHTER_ROBINHOOD_URL = "https://api.rh.lighter.xyz"
ARCUS_URL = "https://api.arcus.xyz"
DEFAULT_PORT = 8004


def _clean(value: str | None) -> str:
    return (value or "").strip()


def _num(value: str | None, fallback: float) -> float:
    try:
        return float(_clean(value))
    except (TypeError, ValueError):
        return fallback


def normalize_proxy(value: str | None) -> str:
    """把几种常见写法统一成 httpx 认识的代理 URL。

    规则：
      · 带协议的原样使用：http:// https:// socks5://
      · host:port:user:pass → socks5://user:pass@host:port
      · host:port           → http://host:port
    """
    s = _clean(value)
    if not s:
        return ""
    if re.match(r"^\w+://", s):
        return s
    parts = s.split(":")
    if len(parts) == 4:
        host, port, user, password = parts
        return f"socks5://{quote(user, safe='')}:{quote(password, safe='')}@{host}:{port}"
    if len(parts) == 2:
        return f"http://{s}"
    return s


@dataclass
class Settings:
    env_path: Path
    data_dir: Path

    host: str = "127.0.0.1"
    port: int = DEFAULT_PORT

    # ── Arcus ──
    arcus_api_url: str = ARCUS_URL
    arcus_address: str = ""                  # 主钱包公开地址（0x + 40 位）
    arcus_account_index: int = 0             # 子账户 0~9
    arcus_api_key: str = ""                  # Ed25519 公钥 hex；留空则由私钥推导
    arcus_api_private_key: str = ""          # Ed25519 私钥（seed hex / PKCS#8）
    arcus_api_private_key_file: str = ""     # 或者私钥文件路径

    # ── RHC Lighter ──
    lighter_base_url: str = LIGHTER_ROBINHOOD_URL
    # Lighter 盘口推送地址；留空 = 由 LIGHTER_BASE_URL 推出（https://… → wss://…/stream）
    lighter_ws_url: str = ""
    lighter_account_index: int | None = None
    lighter_api_key_index: int | None = None
    lighter_api_private_key: str = ""

    # 独立 IP：每个所一个代理，留空则回落到 global_proxy，再空则直连。
    arcus_proxy: str = ""
    lighter_proxy: str = ""
    global_proxy: str = ""

    funding_refresh_seconds: float = 30.0
    funding_stale_max_seconds: float = 180.0
    funding_timeout_seconds: float = 30.0
    # 两条腿里更危险的那条，距强平价还剩多少百分比就算「危险」。
    # 到这个线的处置动作是【双腿同时平掉】，绝不单腿止损。
    liquidation_warn_distance_pct: float = 5.0
    # 开仓门槛：估算的强平走廊（离强平还有百分之几）低于它就不开
    min_corridor_pct: float = 3.0
    # 平仓线：持仓期间任一条腿离强平小于它，两边立刻一起平；面板的「危险」也是这条线。
    # （另外还有相对触发：剩余距离掉到开仓时的一半也会一起平。）
    close_corridor_pct: float = 1.5
    # 平仓后隔多久才允许重开 —— 防止刚平完就重开，连付两次往返成本
    reopen_cooldown_seconds: float = 60.0
    # 下单的滑点上限
    order_slippage_bps: float = 10.0
    # 挂单模式：Arcus 那条腿挂 ALO（0 手续费），成交后去 Lighter 吃单对冲
    arcus_maker: bool = False
    # 挂单最多等多久（秒）。开仓等不到就撤单下轮再挂；平仓等不到剩余部分改吃单
    maker_wait_seconds: float = 120.0
    # 演练模式：只记录意图，不提交任何订单
    dry_run: bool = True
    # 引擎多久跑一个周期
    engine_cycle_seconds: float = 20.0
    # v1.8 浮盈止盈：两腿按现在能吃到的价格平掉，扣掉开仓已付 + 平仓要付的手续费后，
    # 净赚超过门槛就立刻两边一起平（吃单），冷却后进入新一轮
    take_profit_enabled: bool = True
    take_profit_min_usd: float = 0.0       # 最少净赚多少 USDC 才平（门槛取它和下面那个的较大值）
    take_profit_buffer_bps: float = 1.0    # 再按名义额留多少 bps 的缓冲，吸收算完到下单之间的价格变动
    take_profit_min_hold_seconds: float = 120.0  # 开仓后至少持有多久才开始看止盈（等账本和仓位都落定）
    # v1.9 基差监控（只读）：两边盘口走 WebSocket，每 N 秒记一条样本到 data/basis.db
    basis_monitor: bool = True
    basis_sample_seconds: float = 2.0
    basis_window_hours: float = 4.0          # 「平均基差」看最近几小时
    basis_ref_notional: float = 5000.0       # 没建任务的币种按多少 USDC 算可成交价
    # v1.9 择时开仓：按资金费选好方向后，等基差偏到对这个方向有利再开
    entry_timing: bool = True
    entry_edge_bps: float = 2.0              # 1 分钟平均基差偏离近期平均、对开仓方向有利至少多少 bps
    entry_max_wait_minutes: float = 30.0     # 最多等多久；等满就按现价开（保证交易量）
    # v1.11 择时平仓：持有到期后，等基差偏到对平仓有利再平（风控 / 止盈 / 停用不等）
    exit_timing: bool = True
    exit_edge_bps: float = 2.0
    exit_max_wait_minutes: float = 30.0
    # v1.10 交易所保护单：程序断线时由两个交易所自己把两条腿一起平掉
    protect_orders: bool = True
    # v1.11.1 Arcus 盘后价格带拒单后暂停这个币开仓 / 到期平仓多少分钟
    arcus_bound_pause_minutes: float = 30.0
    # v1.12 按盘口深度限额：一来回价差成本（两边吃单开再平）超过这么多 bps 就把这轮金额缩小；0 = 不限
    depth_cost_cap_bps: float = 4.0
    protect_liq_buffer_pct: float = 1.0      # 保护单挂在离强平价还剩百分之几的位置


    _raw: dict[str, str] = field(default_factory=dict, repr=False)

    # ── 代理解析 ────────────────────────────────────────
    def _specific_proxy(self, exchange: str) -> str:
        return self.arcus_proxy if exchange == "arcus" else self.lighter_proxy

    def proxy_for(self, exchange: str) -> str | None:
        """返回该所要用的代理 URL；None = 直连。

        空字符串和纯空白都当作「没配」，不要传给 httpx —— httpx 收到 ""
        会当成一个非法代理地址直接抛错，而不是忽略它。
        """
        chosen = normalize_proxy(self._specific_proxy(exchange)) or normalize_proxy(
            self.global_proxy
        )
        return chosen or None

    def proxy_label(self, exchange: str) -> str:
        """面板上显示用：脱敏后的代理来源说明。"""
        specific = normalize_proxy(self._specific_proxy(exchange))
        if specific:
            return f"独立代理 {_mask_proxy(specific)}"
        shared = normalize_proxy(self.global_proxy)
        if shared:
            return f"共用代理 {_mask_proxy(shared)}"
        return "直连"

    @property
    def arcus_configured(self) -> bool:
        """读账户只需要公开地址。"""
        return bool(_ADDRESS_RE.match(self.arcus_address or ""))

    @classmethod
    def load(cls, env_path: Path, data_dir: Path) -> "Settings":
        raw = {k: v for k, v in dotenv_values(env_path).items() if v is not None}

        def s(key: str, fallback: str = "") -> str:
            return _clean(raw.get(key)) or fallback

        def i(key: str) -> int | None:
            try:
                return int(_clean(raw.get(key)))
            except (TypeError, ValueError):
                return None

        private_file = s("ARCUS_API_PRIVATE_KEY_FILE")
        if private_file and not Path(private_file).is_absolute():
            # 相对路径按 .env 所在目录解析，双击启动时工作目录不一定是程序目录
            private_file = str((env_path.parent / private_file).resolve())

        return cls(
            env_path=env_path,
            data_dir=data_dir,
            host=s("HOST", "127.0.0.1"),
            port=int(_num(raw.get("PORT"), DEFAULT_PORT)),
            arcus_api_url=s("ARCUS_API_URL", ARCUS_URL).rstrip("/"),
            arcus_address=s("ARCUS_ADDRESS").lower(),
            arcus_account_index=i("ARCUS_ACCOUNT_INDEX") or 0,
            arcus_api_key=s("ARCUS_API_KEY").lower().removeprefix("0x"),
            arcus_api_private_key=s("ARCUS_API_PRIVATE_KEY"),
            arcus_api_private_key_file=private_file,
            lighter_base_url=s("LIGHTER_BASE_URL", LIGHTER_ROBINHOOD_URL).rstrip("/"),
            lighter_ws_url=s("LIGHTER_WS_URL"),
            lighter_account_index=i("LIGHTER_ACCOUNT_INDEX"),
            lighter_api_key_index=i("LIGHTER_API_KEY_INDEX"),
            lighter_api_private_key=s("LIGHTER_API_PRIVATE_KEY"),
            arcus_proxy=s("ARCUS_PROXY"),
            lighter_proxy=s("LIGHTER_PROXY"),
            global_proxy=s("GLOBAL_PROXY"),
            funding_refresh_seconds=_num(raw.get("FUNDING_REFRESH_SECONDS"), 30.0),
            funding_stale_max_seconds=_num(raw.get("FUNDING_STALE_MAX_SECONDS"), 180.0),
            funding_timeout_seconds=_num(raw.get("FUNDING_TIMEOUT_SECONDS"), 30.0),
            liquidation_warn_distance_pct=_num(
                raw.get("LIQUIDATION_WARN_DISTANCE_PCT"), 5.0
            ),
            min_corridor_pct=_num(raw.get("MIN_CORRIDOR_PCT"), 3.0),
            close_corridor_pct=_num(raw.get("CLOSE_CORRIDOR_PCT"), 1.5),
            reopen_cooldown_seconds=_num(raw.get("REOPEN_COOLDOWN_SECONDS"), 60.0),
            order_slippage_bps=_num(raw.get("ORDER_SLIPPAGE_BPS"), 10.0),
            dry_run=_clean(raw.get("DRY_RUN", "true")).lower() not in ("0", "false", "no"),
            arcus_maker=_clean(raw.get("ARCUS_MAKER", "false")).lower() in ("1", "true", "yes"),
            maker_wait_seconds=_num(raw.get("MAKER_WAIT_SECONDS"), 120.0),
            engine_cycle_seconds=_num(raw.get("ENGINE_CYCLE_SECONDS"), 20.0),
            take_profit_enabled=_clean(raw.get("TAKE_PROFIT", "true")).lower()
            not in ("0", "false", "no", "off"),
            take_profit_min_usd=max(0.0, _num(raw.get("TAKE_PROFIT_MIN_USD"), 0.0)),
            take_profit_buffer_bps=max(0.0, _num(raw.get("TAKE_PROFIT_BUFFER_BPS"), 1.0)),
            take_profit_min_hold_seconds=max(
                0.0, _num(raw.get("TAKE_PROFIT_MIN_HOLD_SECONDS"), 120.0)),
            basis_monitor=_clean(raw.get("BASIS_MONITOR", "true")).lower()
            not in ("0", "false", "no", "off"),
            basis_sample_seconds=max(1.0, _num(raw.get("BASIS_SAMPLE_SECONDS"), 2.0)),
            basis_window_hours=max(0.5, _num(raw.get("BASIS_WINDOW_HOURS"), 4.0)),
            basis_ref_notional=max(10.0, _num(raw.get("BASIS_REF_NOTIONAL"), 5000.0)),
            entry_timing=_clean(raw.get("ENTRY_TIMING", "true")).lower()
            not in ("0", "false", "no", "off"),
            entry_edge_bps=_num(raw.get("ENTRY_EDGE_BPS"), 2.0),
            entry_max_wait_minutes=max(0.0, _num(raw.get("ENTRY_MAX_WAIT_MINUTES"), 30.0)),
            exit_timing=_clean(raw.get("EXIT_TIMING", "true")).lower()
            not in ("0", "false", "no", "off"),
            exit_edge_bps=_num(raw.get("EXIT_EDGE_BPS"), 2.0),
            exit_max_wait_minutes=max(0.0, _num(raw.get("EXIT_MAX_WAIT_MINUTES"), 30.0)),
            depth_cost_cap_bps=max(0.0, _num(raw.get("DEPTH_COST_CAP_BPS"), 4.0)),
            arcus_bound_pause_minutes=max(1.0, _num(raw.get("ARCUS_BOUND_PAUSE_MINUTES"), 30.0)),
            protect_orders=_clean(raw.get("PROTECT_ORDERS", "true")).lower()
            not in ("0", "false", "no", "off"),
            protect_liq_buffer_pct=min(5.0, max(0.3, _num(raw.get("PROTECT_LIQ_BUFFER_PCT"), 1.0))),
            _raw=raw,
        )


_ADDRESS_RE = re.compile(r"^0x[0-9a-f]{40}$")


def sync_env_file(env_path: Path, example_path: Path) -> list[str]:
    """把 .env.example 里有、.env 里没有的键补进 .env。

    为什么需要这个：.env 只在首次运行时从 .env.example 复制一次，
    之后每新增一个设置项，用户的 .env 就少一项 —— 而且完全看不出来，
    只会表现为「这个开关怎么不起作用」。2026-09-18 就是这样：
    DRY_RUN 等六个键全都不在用户的 .env 里。

    只【追加】，绝不改写已有行 —— .env 里有私钥，不能碰。
    """
    if not env_path.exists() or not example_path.exists():
        return []
    existing = {
        line.split("=", 1)[0].strip()
        for line in env_path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#") and "=" in line
    }
    added: list[tuple[str, str]] = []
    for line in example_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        key = key.strip()
        if key not in existing:
            added.append((key, value.strip()))
    if not added:
        return []
    with env_path.open("a", encoding="utf-8") as handle:
        handle.write("\n\n# ── 以下为程序自动补齐的新增设置（值为默认值）──\n")
        for key, value in added:
            handle.write(f"{key}={value}\n")
    return [key for key, _ in added]


def _mask_proxy(url: str) -> str:
    """把 user:pass@host:port 里的账密和大部分 IP 抹掉再显示。"""
    tail = url.split("@")[-1]
    host = tail.split("://")[-1]
    parts = host.split(":")
    addr = parts[0]
    octets = addr.split(".")
    if len(octets) == 4:
        addr = f"{octets[0]}.*.*.{octets[3]}"
    return addr
