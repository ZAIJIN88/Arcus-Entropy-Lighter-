"""基差监控 + 回归套利回测 + 择时开平仓（v1.9~v1.11）。只读，不下单。

为什么要有它（拿实盘账本算的）：
  · 刷量的磨损主要是「开平时被价格吃掉的」，不是手续费；
  · 两所之间常有一个长期溢价，而且每天在漂 —— 能利用的只有【偏离近期平均】的那一段；
  · 入场时基差对开仓方向有利的轮次，价差损益明显好于平均。

所以这里做三件事：
  1. 两边盘口走 WebSocket（Lighter order_book / Arcus l2Orderbook），每 N 秒对每个共有币种记一条样本，
     落到单独的 data/basis.db（不和交易账本抢锁）；推送拿不到的币用 REST 轮流补；
  2. 回测「偏离近 W 小时平均 ≥ k bps 进、回到平均就出」，可选「信号后晚几秒成交」；
  3. 给刷量引擎择时：按 1 分钟平均基差，开仓 / 到期平仓都等偏到有利再做，最多等 M 分钟。

基差统一定义为 (Lighter − Arcus) / 中价，单位 bps：
  · mid    —— 两边中价之差
  · sell_e —— 「卖 Lighter、买 Arcus」按参考金额走完档位的可成交基差
  · buy_e  —— 「买 Lighter、卖 Arcus」的可成交基差
  buy_e − sell_e 就是这一刻两边一起吃单开再平掉的价差成本。
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import math
import sqlite3
import time
from collections import deque
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Iterable

from .books import Book, Level, aggregate_levels, vwap

# Arcus 吃单费（bps）；Lighter 标准账户 0 费率
ARCUS_TAKER_BPS = 2.25
LIGHTER_TAKER_BPS = 0.0          # Lighter 标准账户 0 费率
# 回测试的进场阈值（偏离平均多少 bps 才进）
BACKTEST_THRESHOLDS = (2.0, 4.0, 6.0, 8.0, 10.0, 15.0, 20.0)
# 回测里一笔最多持有多久（小时），到点不管回没回归都平
BACKTEST_MAX_HOLD_HOURS = 24.0
# 均值至少要有这么多分钟的数据才拿来判断（刚启动时不择时、回测也跳过）
MIN_WINDOW_MINUTES = 30.0
# 样本超过这么多秒没更新就当作「现在没有数据」
FRESH_SEC = 45.0
# 落盘的样本保留天数（v1.9.1 起每 2 秒一条，留 7 天）
KEEP_DAYS = 7
# 择时开仓看的「当前基差」= 最近这么多秒的平均。
# 2026-11-04 拿第一天数据看：10 秒一条的原始基差里，85% 的「机会」只出现一条就弹回去
# （相邻两条的变化自相关 −0.43），晚 10 秒成交全部变成亏钱；按 1 分钟平均后的偏离
# 才是能持续十几分钟到半小时的真实偏离（SNDK 15 分钟后仍保留 +0.26，DRAM +0.62）。
SMOOTH_SEC = 60.0
# 回测默认按「信号出现后这么多秒才成交」算，贴近真实下单延迟
DEFAULT_DELAY_SEC = 5.0


@dataclass(frozen=True)
class Sample:
    ts: float
    asset: str
    mid: float        # 中价基差 bps
    sell_e: float     # 卖 Lighter / 买 Arcus 的可成交基差
    buy_e: float      # 买 Lighter / 卖 Arcus 的可成交基差
    e_spread: float   # Lighter 买卖价差 bps
    a_spread: float   # Arcus 买卖价差 bps
    notional: float   # 按多少 USDC 算的可成交价
    # v1.9.1：两边各自的中价和盘口「多久没更新了」（秒）—— 用来判断尖峰是真价差还是某一边盘口慢了
    e_mid: float | None = None
    a_mid: float | None = None
    e_age: float | None = None
    a_age: float | None = None


def sample_from_books(asset: str, lighter: Book, arcus: Book, notional: float,
                      ts: float | None = None, e_age: float | None = None,
                      a_age: float | None = None) -> Sample | None:
    """两边盘口 → 一条样本。任何一边深度不够吃下参考金额就返回 None。"""
    eb, ea, ab, aa = lighter.best_bid, lighter.best_ask, arcus.best_bid, arcus.best_ask
    if not all((eb, ea, ab, aa)) or ea < eb or aa < ab:
        return None
    e_mid, a_mid = (eb + ea) / 2, (ab + aa) / 2
    mid = (e_mid + a_mid) / 2
    qty = float(notional) / mid
    e_sell, e_buy = vwap(lighter.bids, qty), vwap(lighter.asks, qty)
    a_sell, a_buy = vwap(arcus.bids, qty), vwap(arcus.asks, qty)
    if None in (e_sell, e_buy, a_sell, a_buy):
        return None
    k = 10_000.0 / mid
    return Sample(
        ts=ts if ts is not None else time.time(), asset=asset,
        mid=(e_mid - a_mid) * k, sell_e=(e_sell - a_buy) * k, buy_e=(e_buy - a_sell) * k,
        e_spread=(ea - eb) / e_mid * 10_000, a_spread=(aa - ab) / a_mid * 10_000,
        notional=float(notional), e_mid=e_mid, a_mid=a_mid, e_age=e_age, a_age=a_age,
    )


class RollingWindow:
    """最近 W 小时的中价基差：均值 / 标准差 O(1) 更新。"""

    def __init__(self, hours: float) -> None:
        self.span = float(hours) * 3600
        self.items: deque[tuple[float, float]] = deque()
        self.s = 0.0
        self.s2 = 0.0

    def add(self, ts: float, value: float) -> None:
        self.items.append((ts, value))
        self.s += value
        self.s2 += value * value
        self.trim(ts)

    def trim(self, now: float) -> None:
        while self.items and self.items[0][0] < now - self.span:
            _, v = self.items.popleft()
            self.s -= v
            self.s2 -= v * v

    @property
    def n(self) -> int:
        return len(self.items)

    @property
    def coverage_minutes(self) -> float:
        return (self.items[-1][0] - self.items[0][0]) / 60 if len(self.items) > 1 else 0.0

    @property
    def mean(self) -> float | None:
        return self.s / self.n if self.n else None

    @property
    def sd(self) -> float | None:
        if self.n < 2:
            return None
        m = self.s / self.n
        return math.sqrt(max(0.0, self.s2 / self.n - m * m))

    @property
    def ready(self) -> bool:
        return self.coverage_minutes >= MIN_WINDOW_MINUTES


# ── 择时开仓 ──────────────────────────────────────────

def entry_edge(direction: str, last: Sample, mean: float) -> dict[str, float]:
    """按资金费选好的方向，现在开 + 将来在平均基差平掉，能拿到多少价差（bps）。

    favor  = 基差偏离平均、对这个方向有利的幅度（做多 Lighter 要 Lighter 相对便宜 = 基差低于平均）
    cost   = 现在这一刻两边一起吃单开再平的价差成本（buy_e − sell_e）
    expect = favor − cost：假设基差回到平均、两边价差不变时，这一轮的价差损益
    """
    deviation = last.mid - mean
    favor = -deviation if direction == "long_lighter_short_arcus" else deviation
    cost = last.buy_e - last.sell_e
    return {"favor": favor, "cost": cost, "expect": favor - cost, "deviation": deviation}


# ── 回测 ──────────────────────────────────────────────

def backtest(samples: Iterable[Sample], *, threshold: float, window_hours: float,
             fee_bps_round_trip: float, max_hold_hours: float = BACKTEST_MAX_HOLD_HOURS,
             delay_sec: float = 0.0) -> dict[str, Any]:
    """偏离均值回归：只用【当时之前】的数据算均值，可成交价进出，扣真实手续费。

    空仓时：sell_e − 均值 ≥ k → 卖 Lighter 买 Arcus；均值 − buy_e ≥ k → 买 Lighter 卖 Arcus。
    持仓时：反向的可成交基差回到均值（或持有超过上限）就平。
    delay_sec：信号出现后要过这么久才按【那时】的可成交价成交（模拟下单延迟）——
    0 秒的结果只是理论上限：第一天的数据里大部分尖峰 10 秒内就弹回去了。
    返回每笔净 bps 列表的统计；资金费不计入（两边费率另算，可正可负）。
    """
    win = RollingWindow(window_hours)
    position = 0          # +1 做多 Lighter，−1 做空 Lighter
    entry = opened = 0.0
    pending: tuple[float, str] | None = None     # (最早成交时刻, 动作)
    trades: list[tuple[float, float]] = []     # (净 bps, 持有分钟)
    first = last_ts = None
    for s in samples:
        if first is None:
            first = s.ts
        last_ts = s.ts
        mean = win.mean if win.ready else None
        if pending is not None and s.ts >= pending[0]:
            action, pending = pending[1], None
            if action == "short":
                position, entry, opened = -1, s.sell_e, s.ts
            elif action == "long":
                position, entry, opened = 1, s.buy_e, s.ts
            elif position == -1:
                trades.append((entry - s.buy_e - fee_bps_round_trip, (s.ts - opened) / 60))
                position = 0
            elif position == 1:
                trades.append((s.sell_e - entry - fee_bps_round_trip, (s.ts - opened) / 60))
                position = 0
        elif mean is not None and pending is None:
            if position == 0:
                if s.sell_e - mean >= threshold:
                    pending = (s.ts + delay_sec, "short")
                elif mean - s.buy_e >= threshold:
                    pending = (s.ts + delay_sec, "long")
            else:
                timeout = s.ts - opened >= max_hold_hours * 3600
                if (position == -1 and s.buy_e <= mean) or (position == 1 and s.sell_e >= mean) \
                        or timeout:
                    pending = (s.ts + delay_sec, "exit")
            if pending is not None and delay_sec <= 0:
                # 不延迟：就按这一条成交（和改版前一致）
                action, pending = pending[1], None
                if action == "short":
                    position, entry, opened = -1, s.sell_e, s.ts
                elif action == "long":
                    position, entry, opened = 1, s.buy_e, s.ts
                elif position == -1:
                    trades.append((entry - s.buy_e - fee_bps_round_trip, (s.ts - opened) / 60))
                    position = 0
                else:
                    trades.append((s.sell_e - entry - fee_bps_round_trip, (s.ts - opened) / 60))
                    position = 0
        win.add(s.ts, s.mid)
    days = max((last_ts or 0) - (first or 0), 0) / 86400
    nets = [t[0] for t in trades]
    return {
        "threshold": threshold,
        "trades": len(trades),
        "per_day": len(trades) / days if days > 0 else None,
        "avg_net_bps": sum(nets) / len(nets) if nets else None,
        "win_rate": sum(1 for x in nets if x > 0) / len(nets) if nets else None,
        "avg_hold_min": sum(t[1] for t in trades) / len(trades) if trades else None,
        # 累计净 bps = 每 1 万 U 名义额累计净赚多少 USDC（1 bps × 1 万 = 1 U）
        "total_net_bps": sum(nets),
        "open_at_end": position != 0,
    }


def backtest_asset(samples: list[Sample], *, window_hours: float, arcus_fee_bps: float,
                   lighter_fee_bps: float, delay_sec: float = DEFAULT_DELAY_SEC) -> dict[str, Any]:
    fee = 2 * (arcus_fee_bps + lighter_fee_bps)
    rows = [backtest(samples, threshold=k, window_hours=window_hours, fee_bps_round_trip=fee,
                     delay_sec=delay_sec)
            for k in BACKTEST_THRESHOLDS]
    best = max(rows, key=lambda r: r["total_net_bps"]) if rows else None
    mids = [s.mid for s in samples]
    span_h = (samples[-1].ts - samples[0].ts) / 3600 if len(samples) > 1 else 0.0
    return {
        "samples": len(samples), "hours": span_h,
        "fee_round_trip_bps": fee,
        "mid_mean": sum(mids) / len(mids) if mids else None,
        "mid_sd": _sd(mids),
        "cross_cost": _median([s.buy_e - s.sell_e for s in samples]),
        "rows": rows,
        "best": best if best and best["trades"] and best["total_net_bps"] > 0 else None,
    }


def _sd(xs: list[float]) -> float | None:
    if len(xs) < 2:
        return None
    m = sum(xs) / len(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / len(xs))


def _median(xs: list[float]) -> float | None:
    if not xs:
        return None
    ys = sorted(xs)
    n = len(ys)
    return ys[n // 2] if n % 2 else (ys[n // 2 - 1] + ys[n // 2]) / 2


# ── 样本库 ────────────────────────────────────────────

class BasisStore:
    """data/basis.db —— 和交易账本分开的库：每隔几秒一批写入，不和下单记账抢锁。"""

    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.conn = sqlite3.connect(str(path), check_same_thread=False)
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS samples (ts REAL NOT NULL, asset TEXT NOT NULL,"
            " mid REAL, sell_e REAL, buy_e REAL, e_spread REAL, a_spread REAL, notional REAL)")
        self.conn.execute("CREATE INDEX IF NOT EXISTS samples_asset_ts ON samples(asset, ts)")
        have = {r[1] for r in self.conn.execute("PRAGMA table_info(samples)")}
        for col in ("e_mid", "a_mid", "e_age", "a_age"):
            if col not in have:
                self.conn.execute(f"ALTER TABLE samples ADD COLUMN {col} REAL")
        self.conn.commit()

    def add(self, rows: list[Sample]) -> None:
        if not rows:
            return
        self.conn.executemany(
            "INSERT INTO samples (ts, asset, mid, sell_e, buy_e, e_spread, a_spread, notional,"
            " e_mid, a_mid, e_age, a_age) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            [(s.ts, s.asset, s.mid, s.sell_e, s.buy_e, s.e_spread, s.a_spread, s.notional,
              s.e_mid, s.a_mid, s.e_age, s.a_age) for s in rows])
        self.conn.commit()

    def load(self, asset: str | None, since: float, conn: Any = None) -> list[Sample]:
        sql = ("SELECT ts, asset, mid, sell_e, buy_e, e_spread, a_spread, notional,"
               " e_mid, a_mid, e_age, a_age FROM samples"
               " WHERE ts>=?" + (" AND asset=?" if asset else "") + " ORDER BY ts")
        args: tuple = (since, asset) if asset else (since,)
        return [Sample(*r) for r in (conn or self.conn).execute(sql, args)]

    def assets(self, since: float, conn: Any = None) -> list[str]:
        return [r[0] for r in (conn or self.conn).execute(
            "SELECT DISTINCT asset FROM samples WHERE ts>=? ORDER BY asset", (since,))]

    def reader(self) -> sqlite3.Connection:
        """回测在后台线程里跑，用自己的只读连接，不和每 10 秒的写入抢同一个连接。"""
        return sqlite3.connect(str(self.path))

    def prune(self, keep_days: float = KEEP_DAYS) -> None:
        self.conn.execute("DELETE FROM samples WHERE ts<?", (time.time() - keep_days * 86400,))
        self.conn.commit()

    def close(self) -> None:
        with contextlib.suppress(Exception):
            self.conn.close()


# ── 盘口推送 ──────────────────────────────────────────

class _Stream:
    """一个所的盘口 WebSocket：一条连接订阅所有币种，收到的整本盘口放进 books。

    WS 只是数据源，断了自动重连（退避到 30 秒）；断开期间监控对这个所退回 REST 慢轮询。
    """

    venue = ""

    def __init__(self, url: str, proxy: str | None) -> None:
        self.url = url
        self.proxy = proxy
        self.wanted: set[str] = set()
        self.books: dict[str, tuple[Book, float]] = {}
        self.connected = False
        self.connected_at: float | None = None
        self.last_error: str | None = None
        self.messages = 0
        self._ws: Any = None
        self._task: asyncio.Task | None = None
        self._stopped = False

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stopped = True
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._task

    async def watch(self, symbols: Iterable[str]) -> None:
        new = [s for s in symbols if s not in self.wanted]
        self.wanted.update(new)
        if self._ws is not None and self.connected:
            for symbol in new:
                with contextlib.suppress(Exception):
                    await self._ws.send(json.dumps(self.subscribe_msg(symbol)))

    def book(self, symbol: str, max_age: float) -> Book | None:
        hit = self.books.get(symbol)
        if hit is None or time.time() - hit[1] > max_age:
            return None
        return hit[0]

    def subscribe_msg(self, symbol: str) -> dict[str, Any]:
        raise NotImplementedError

    def parse(self, msg: Any) -> tuple[str, Book] | None:
        raise NotImplementedError

    def reply(self, msg: Any) -> dict[str, Any] | None:
        """需要回给服务器的消息（比如应用层心跳）。"""
        return None

    async def _keepalive(self, ws: Any) -> None:
        return None

    async def _run(self) -> None:
        from websockets.asyncio.client import connect

        backoff = 1.0
        while not self._stopped:
            pinger = None
            try:
                async with connect(self.url, proxy=self.proxy or None, open_timeout=15,
                                   max_size=2 ** 22, **self.connect_kwargs()) as ws:
                    self._ws, self.connected, self.last_error = ws, True, None
                    self.connected_at = time.time()
                    backoff = 1.0
                    for symbol in list(self.wanted):
                        await ws.send(json.dumps(self.subscribe_msg(symbol)))
                    pinger = asyncio.create_task(self._keepalive(ws))
                    async for raw in ws:
                        self.messages += 1
                        try:
                            msg = json.loads(raw)
                            answer = self.reply(msg)
                            if answer is not None:
                                await ws.send(json.dumps(answer))
                            hit = self.parse(msg)
                        except Exception:  # noqa: BLE001 —— 一条看不懂的消息不能断流
                            continue
                        if hit is not None:
                            self.books[hit[0]] = (hit[1], time.time())
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.last_error = str(exc)[:200]
            finally:
                self.connected, self._ws = False, None
                if pinger:
                    pinger.cancel()
            if self._stopped:
                return
            await asyncio.sleep(backoff)
            backoff = min(30.0, backoff * 2)

    def connect_kwargs(self) -> dict[str, Any]:
        return {"ping_interval": 20, "ping_timeout": 20}

    def status(self) -> dict[str, Any]:
        return {"connected": self.connected, "subscribed": len(self.wanted),
                "books": len(self.books), "messages": self.messages, "error": self.last_error}


class LighterBookStream(_Stream):
    """Lighter order_book/{市场号}：订阅时先推一份整本快照，之后只推变化的档位（数量 0 = 删掉这一档）。

    按市场号（字符串）存盘口。盘口只在变化时推：连接还在、本次连接后收到过快照，就一直是当前盘口。
    推送里拿不到的币，监控会用 REST 轮流补。
    """

    venue = "lighter"

    def __init__(self, url: str, proxy: str | None) -> None:
        super().__init__(url, proxy)
        self._levels: dict[str, dict[str, dict[float, float]]] = {}

    def subscribe_msg(self, symbol: str) -> dict[str, Any]:
        return {"type": "subscribe", "channel": f"order_book/{symbol}"}

    def reply(self, msg: Any) -> dict[str, Any] | None:
        # Lighter 会发应用层 {"type":"ping"}，要回 {"type":"pong"}，不回会被断开
        if isinstance(msg, dict) and msg.get("type") == "ping":
            return {"type": "pong"}
        return None

    def parse(self, msg: Any) -> tuple[str, Book] | None:
        if not isinstance(msg, dict):
            return None
        kind = str(msg.get("type") or "")
        if not kind.endswith("order_book"):
            return None
        channel = str(msg.get("channel") or "")
        market = channel.split(":")[-1].split("/")[-1]
        ob = msg.get("order_book") or {}
        if not market or not isinstance(ob, dict):
            return None
        if kind.startswith("subscribed") or market not in self._levels:
            self._levels[market] = {"bids": {}, "asks": {}}
        state = self._levels[market]
        for side in ("bids", "asks"):
            for row in ob.get(side) or []:
                try:
                    price = float(row.get("price") if isinstance(row, dict) else row[0])
                    size = float(row.get("size") if isinstance(row, dict) else row[1])
                except (TypeError, ValueError, IndexError, AttributeError):
                    continue
                if size <= 0:
                    state[side].pop(price, None)
                else:
                    state[side][price] = size
        bids = [Level(p, q) for p, q in sorted(state["bids"].items(), reverse=True)]
        asks = [Level(p, q) for p, q in sorted(state["asks"].items())]
        if not bids or not asks or bids[0].price >= asks[0].price:
            return None
        return market, Book("lighter", market, bids, asks)

    def book(self, symbol: str, max_age: float) -> Book | None:
        hit = self.books.get(symbol)
        if hit is None:
            return None
        if self.connected and self.connected_at and hit[1] >= self.connected_at:
            return hit[0]
        return hit[0] if time.time() - hit[1] <= max_age else None


class ArcusBookStream(_Stream):
    """Arcus l2Orderbook：一条连接多路复用，每 ~200ms 推一次全量快照
    （报文格式经过实盘验证：channel / id / contents.bids/asks）。"""

    venue = "arcus"

    def subscribe_msg(self, symbol: str) -> dict[str, Any]:
        return {"type": "subscribe", "channel": "l2Orderbook", "id": symbol, "nLevels": 25}

    def parse(self, msg: Any) -> tuple[str, Book] | None:
        if not isinstance(msg, dict) or msg.get("channel") != "l2Orderbook":
            return None
        contents = msg.get("contents") or {}
        symbol = msg.get("id")
        if not symbol:
            return None
        bids = aggregate_levels(contents.get("bids"), descending=True)
        asks = aggregate_levels(contents.get("asks"), descending=False)
        if not bids or not asks:
            return None
        return symbol, Book("arcus", symbol, bids, asks)


def _ws_url(http_url: str, path: str) -> str:
    base = http_url.rstrip("/").replace("https://", "wss://").replace("http://", "ws://")
    return base + path


# ── 监控主体 ──────────────────────────────────────────

class BasisMonitor:
    def __init__(self, settings: Any, client: Any, store: Any, *,
                 basis_store: BasisStore | None = None) -> None:
        self.settings = settings
        self.client = client
        self.store = store              # 交易账本：读任务金额
        self.db = basis_store or BasisStore(Path(settings.data_dir) / "basis.db")
        self.interval = max(1.0, float(settings.basis_sample_seconds))
        self.window_hours = float(settings.basis_window_hours)
        self.lighter_ws = LighterBookStream(
            getattr(settings, "lighter_ws_url", "") or _ws_url(settings.lighter_base_url, "/stream"),
                                            settings.proxy_for("lighter"))
        self.arcus_ws = ArcusBookStream(_ws_url(settings.arcus_api_url, "/v1/ws"),
                                        settings.proxy_for("arcus"))
        self.markets: dict[str, dict[str, Any]] = {}
        self.windows: dict[str, RollingWindow] = {}
        self.last: dict[str, Sample] = {}
        self.recent: dict[str, deque[Sample]] = {}      # 最近 SMOOTH_SEC 秒的样本（平滑用）
        self.rest_books: dict[tuple[str, str], tuple[Book, float]] = {}
        self._task: asyncio.Task | None = None
        self._rr = 0
        self._backtest_cache: tuple[float, tuple, dict[str, Any]] | None = None
        self.started_at = time.time()
        self.errors = 0

    # ── 生命周期 ──
    def start(self) -> None:
        self._load_history()
        self.lighter_ws.start()
        self.arcus_ws.start()
        if self._task is None:
            self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._task
        await self.lighter_ws.stop()
        await self.arcus_ws.stop()
        self.db.close()

    def _load_history(self) -> None:
        """重启后从库里把最近 W 小时的样本读回来 —— 不用重新等半小时才能择时。"""
        since = time.time() - self.window_hours * 3600
        for s in self.db.load(None, since):
            self._remember(s)

    def _remember(self, s: Sample) -> None:
        win = self.windows.setdefault(s.asset, RollingWindow(self.window_hours))
        win.add(s.ts, s.mid)
        self.last[s.asset] = s
        recent = self.recent.setdefault(s.asset, deque())
        recent.append(s)
        while recent and recent[0].ts < s.ts - SMOOTH_SEC:
            recent.popleft()

    def smoothed_mid(self, asset: str) -> float | None:
        """最近 SMOOTH_SEC 秒的平均中价基差。样本太少（< 3 条）返回 None。"""
        recent = self.recent.get(asset)
        if not recent or len(recent) < 3 or time.time() - recent[-1].ts > FRESH_SEC + self.interval:
            return None
        return sum(x.mid for x in recent) / len(recent)

    async def _run(self) -> None:
        last_markets = last_prune = 0.0
        while True:
            try:
                now = time.time()
                if now - last_markets > 300 or not self.markets:
                    markets = await self.client.common_markets()
                    self.markets = {m["asset"]: m for m in markets}
                    await self.lighter_ws.watch(str(m["lighter_market_index"]) for m in markets)
                    await self.arcus_ws.watch(m["arcus_symbol"] for m in markets)
                    last_markets = now
                await self._rest_fallback()
                self.sample_all(now)
                if now - last_prune > 3600:
                    self.db.prune()
                    last_prune = now
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 —— 监控出错不能影响交易，下一轮再来
                self.errors += 1
            await asyncio.sleep(self.interval)

    async def _rest_fallback(self) -> None:
        """推送里拿不到某个币的盘口（WS 没连上，或者订阅了没数据）时，每轮用 REST 补一个币（轮流）。"""
        assets = sorted(self.markets)
        if not assets:
            return
        asset = assets[self._rr % len(assets)]
        self._rr += 1
        m = self.markets[asset]
        if self.lighter_ws.book(str(m["lighter_market_index"]), FRESH_SEC) is None:
            with contextlib.suppress(Exception):
                book = await self.client.lighter_book(m["lighter_market_index"], m["lighter_symbol"])
                self.rest_books[("lighter", str(m["lighter_market_index"]))] = (book, time.time())
        if self.arcus_ws.book(m["arcus_symbol"], FRESH_SEC) is None:
            with contextlib.suppress(Exception):
                book = await self.client.arcus_book(m["arcus_symbol"], levels=25)
                self.rest_books[("arcus", m["arcus_symbol"])] = (book, time.time())

    def _book(self, stream: _Stream, symbol: str) -> tuple[Book, float] | tuple[None, None]:
        """(盘口, 这本盘口多少秒前收到的)。"""
        book = stream.book(symbol, FRESH_SEC)
        if book is not None:
            return book, time.time() - stream.books[symbol][1]
        hit = self.rest_books.get((stream.venue, symbol))
        # REST 轮流补，一个币要等一圈：放宽到 3 分钟
        if hit and time.time() - hit[1] <= max(180.0, len(self.markets) * self.interval * 1.5):
            return hit[0], time.time() - hit[1]
        return None, None

    def ref_notional(self, asset: str) -> float:
        task = self.store.get_task(asset) if self.store else None
        if task:
            amount = task.get("notional_usdc_max") or task.get("notional_usdc")
            if amount and float(amount) > 0:
                return float(amount)
        return float(self.settings.basis_ref_notional)

    def sample_all(self, now: float | None = None) -> list[Sample]:
        now = now or time.time()
        rows: list[Sample] = []
        for asset, m in self.markets.items():
            e, e_age = self._book(self.lighter_ws, str(m["lighter_market_index"]))
            a, a_age = self._book(self.arcus_ws, m["arcus_symbol"])
            if e is None or a is None:
                continue
            s = sample_from_books(asset, e, a, self.ref_notional(asset), ts=now,
                                  e_age=e_age, a_age=a_age)
            if s is None:
                continue
            self._remember(s)
            rows.append(s)
        self.db.add(rows)
        return rows

    # ── 给引擎用：择时开仓 ──
    def entry_check(self, asset: str, direction: str) -> dict[str, Any] | None:
        """None = 数据不够（刚启动 / 盘口断了），引擎就不择时、照常开。"""
        last = self.last.get(asset)
        win = self.windows.get(asset)
        if last is None or win is None or time.time() - last.ts > FRESH_SEC + self.interval:
            return None
        win.trim(time.time())
        smooth = self.smoothed_mid(asset)
        if not win.ready or win.mean is None or smooth is None:
            return None
        # 偏离按 1 分钟平均算（瞬时尖峰 10 秒内就弹回去，追它没用）；价差成本按此刻的盘口
        edge = entry_edge(direction, replace(last, mid=smooth), win.mean)
        edge.update(mean=win.mean, sd=win.sd or 0.0, mid=smooth)
        return edge

    # ── 给面板用 ──
    def live(self) -> dict[str, Any]:
        rows = []
        now = time.time()
        for asset in sorted(set(self.markets) | set(self.last)):
            last = self.last.get(asset)
            win = self.windows.get(asset)
            if win:
                win.trim(now)
            rows.append({
                "asset": asset,
                "fresh": bool(last and now - last.ts <= FRESH_SEC + self.interval),
                "mid": last.mid if last else None,
                "sell_e": last.sell_e if last else None,
                "buy_e": last.buy_e if last else None,
                "cross_cost": (last.buy_e - last.sell_e) if last else None,
                "e_spread": last.e_spread if last else None,
                "a_spread": last.a_spread if last else None,
                "notional": last.notional if last else None,
                "mean": win.mean if win else None,
                "sd": win.sd if win else None,
                "smooth": self.smoothed_mid(asset),
                "deviation": ((self.smoothed_mid(asset) if self.smoothed_mid(asset) is not None
                               else last.mid) - win.mean)
                if (last and win and win.mean is not None) else None,
                "e_age": last.e_age if last else None,
                "a_age": last.a_age if last else None,
                "coverage_min": win.coverage_minutes if win else 0.0,
                "ready": bool(win and win.ready),
            })
        return {
            "interval": self.interval, "window_hours": self.window_hours,
            "streams": {"lighter": self.lighter_ws.status(), "arcus": self.arcus_ws.status()},
            "errors": self.errors, "rows": rows,
        }

    def run_backtest(self, *, days: float, arcus_fee_bps: float,
                     lighter_fee_bps: float, delay_sec: float = DEFAULT_DELAY_SEC) -> dict[str, Any]:
        key = (round(days, 3), round(arcus_fee_bps, 4), round(lighter_fee_bps, 4),
               round(delay_sec, 2))
        if self._backtest_cache and time.time() - self._backtest_cache[0] < 120 \
                and self._backtest_cache[1] == key:
            return self._backtest_cache[2]
        since = time.time() - days * 86400
        conn = self.db.reader()
        result = {"days": days, "arcus_fee_bps": arcus_fee_bps,
                  "lighter_fee_bps": lighter_fee_bps, "window_hours": self.window_hours,
                  "delay_sec": delay_sec,
                  "thresholds": list(BACKTEST_THRESHOLDS), "assets": {}}
        try:
            for asset in self.db.assets(since, conn):
                samples = self.db.load(asset, since, conn)
                if len(samples) >= 30:
                    result["assets"][asset] = backtest_asset(
                        samples, window_hours=self.window_hours,
                        arcus_fee_bps=arcus_fee_bps, lighter_fee_bps=lighter_fee_bps,
                        delay_sec=delay_sec)
        finally:
            conn.close()
        result["at"] = time.time()
        self._backtest_cache = (time.time(), key, result)
        return result
