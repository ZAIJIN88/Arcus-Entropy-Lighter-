"""v1.8：下单通道熔断 / 先平对冲腿 / 孤腿复核与滑点阶梯 / 浮盈止盈 / Lighter 拒单不记账。"""
import tempfile
import time

import pytest

from parallax_hedge.execution import LegResult, PairResult
from parallax_hedge.guards import (
    ORPHAN_SLIPPAGE_CAP_BPS,
    VenueHalts,
    looks_like_auth_error,
    orphan_slippage_bps,
    plan_blocked_by_halt,
    take_profit_estimate,
)

from test_engine import make, row, run
from test_execution import FakeMarket, close_with

# ── guards：纯逻辑 ─────────────────────────────────────

def test_auth_error_patterns():
    assert looks_like_auth_error(
        "entropy", "User or API Wallet 0x1234abcd does not exist.")
    assert looks_like_auth_error("arcus", "HTTP 401 Unauthorized")
    assert looks_like_auth_error("arcus", "code INVALID_SIGNATURE")
    assert not looks_like_auth_error("arcus", "ORDER_EXPIRED")
    assert not looks_like_auth_error("entropy", "Price too far from oracle")
    assert not looks_like_auth_error("entropy", None)


def test_halts_block_pair_actions_but_not_a_rescue_on_the_healthy_venue():
    h = VenueHalts(clock=lambda: 1000.0)
    assert plan_blocked_by_halt("close", None, h, ("entropy", "arcus")) is None
    assert h.trip("entropy", "钱包不存在") is True
    assert h.trip("entropy", "again") is False
    for plan in ("open", "topup", "close"):
        assert "Entropy" in plan_blocked_by_halt(plan, None, h, ("entropy", "arcus"))
    assert plan_blocked_by_halt("flatten_orphan", "arcus", h, ("entropy", "arcus")) is None
    assert "手动平仓" in plan_blocked_by_halt("flatten_orphan", "entropy", h, ("entropy", "arcus"))
    assert plan_blocked_by_halt("idle", None, h, ("entropy", "arcus")) is None


def test_halt_probe_is_due_every_five_minutes():
    now = [1000.0]
    h = VenueHalts(clock=lambda: now[0])
    h.trip("arcus", "HTTP 401")
    assert h.due_for_probe() == []
    now[0] += 301
    assert h.due_for_probe() == ["arcus"]
    assert h.due_for_probe() == []
    assert h.clear() == ["arcus"] and not h.any()


def test_orphan_slippage_widens_step_by_step_with_a_cap():
    assert [orphan_slippage_bps(10, n) for n in range(6)] == [30, 60, 100, 150, 150, 150]
    assert orphan_slippage_bps(20, 9) == ORPHAN_SLIPPAGE_CAP_BPS


def test_take_profit_math():
    est = take_profit_estimate(
        [("entropy", 1.0, 100.0), ("arcus", -1.0, 101.0)],
        {"entropy": 100.5, "arcus": 100.6},
        open_fees=0.03, close_fee_rates={"entropy": 0.0001, "arcus": 0.0002},
        min_usd=0.1, buffer_bps=1,
    )
    # 价差：+0.5 + 0.4 = 0.9；平仓费 0.01005 + 0.02012
    assert est.gross == pytest.approx(0.9)
    assert est.close_fees == pytest.approx(0.03017, abs=1e-5)
    assert est.net == pytest.approx(0.9 - 0.03 - 0.03017, abs=1e-5)
    assert est.threshold == pytest.approx(0.1)
    assert est.triggered
    assert take_profit_estimate([("entropy", 1.0, None)], {"entropy": 1.0},
                                open_fees=0, close_fee_rates={}) is None


# ── 平仓：先平 Lighter，按它实际平掉的再平 Arcus ───────────

def test_close_partial_hedge_fill_closes_the_same_amount_on_arcus():
    ex, r = close_with(FakeMarket(lighter=0.2, arcus=-0.2), lighter_fill=0.1)
    assert ex.lighter_orders[0][1] == pytest.approx(0.2)
    assert ex.arcus_orders == [("buy", pytest.approx(0.1), True)]
    assert r.ok is False and r.stage == "close_partial"
    # 剩下的两腿仍然对冲：0.1 / -0.1
    assert ex.market_state.lighter == pytest.approx(0.1)
    assert ex.market_state.arcus == pytest.approx(-0.1)


def test_close_rejected_hedge_leg_leaves_arcus_untouched():
    ex, r = close_with(FakeMarket(lighter=0.2, arcus=-0.2), lighter_ok=False)
    assert ex.arcus_orders == []
    assert r.stage == "close_hedge_failed" and "Arcus 没动" in r.reason


# ── 引擎：实盘替身 ────────────────────────────────────

class LiveStub:
    """实盘执行器替身：有熔断表，仓位读数和孤腿平仓结果按测试设置。"""

    def __init__(self, positions=(0.2, -0.2), flatten_error=None):
        self.halts = VenueHalts()
        self.positions = positions
        self.flatten_error = flatten_error
        self.calls = []

    async def read_positions(self, symbol, market_id):
        return self.positions

    async def close_pair(self, **kw):
        self.calls.append(("close_pair", kw))
        return PairResult(True, "closed")

    async def flatten_orphan(self, **kw):
        self.calls.append(("flatten_orphan", kw))
        ok = self.flatten_error is None
        return LegResult(kw["venue"], ok, submitted=True, error=self.flatten_error)

    async def open_pair(self, **kw):
        raise AssertionError("不该开仓")

    async def probe(self, venue):
        return False, "still bad"

    async def aclose(self):
        pass


def _live(tmp, r, **over):
    eng, store, svc = make(tmp, r, dry_run=False, **over)
    eng.executor = LiveStub()
    return eng, store


def _held_row(lighter_entry, arcus_entry, mark=210.0):
    r = row(0.2, -0.2, mark=mark)
    r["position"]["lighter"]["entry_price"] = lighter_entry
    r["position"]["arcus"]["entry_price"] = arcus_entry
    return r


def test_take_profit_closes_when_the_spread_came_back():
    with tempfile.TemporaryDirectory() as tmp:
        # Lighter 多 200 进、Arcus 空 212 进，现在都在 210 附近：两边一起平净赚约 2.4
        eng, store = _live(tmp, _held_row(200.0, 212.0))
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 600, corridor_at_open=8.3)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "close" and d[0]["reason"].startswith("止盈")
        (name, kw), = eng.executor.calls
        assert name == "close_pair"
        assert store.get_task("OAI")["opened_at"] is None
        assert store.get_task("OAI")["last_closed_at"] is not None


def test_take_profit_waits_when_net_is_negative_and_shows_the_estimate():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, _held_row(210.0, 210.0))
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 600, corridor_at_open=8.3)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "idle" and "止盈估算" in d[0]["reason"]
        assert eng.executor.calls == []
        assert eng.take_profit_view["OAI"]["net"] < 0


def test_take_profit_respects_min_hold_and_the_switch():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, _held_row(200.0, 212.0))
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 30, corridor_at_open=8.3)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "idle" and eng.executor.calls == []
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, _held_row(200.0, 212.0), take_profit_enabled=False)
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 600, corridor_at_open=8.3)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "idle" and eng.executor.calls == []


def test_open_fees_in_the_ledger_raise_the_bar():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, _held_row(200.0, 212.0))
        opened = time.time() - 600
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=opened, corridor_at_open=8.3)
        store.record_fill(asset="OAI", venue="arcus", action="open", side="sell",
                          dry_run=False, market_id=None, order_ref="x1", requested_qty=0.2,
                          quantity=0.2, price=212.0, source="exchange", status="final",
                          fee=5.0, created_at=opened + 1)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "idle"                 # 开仓付了 5 USDC：2.4 的价差不够
        assert eng.take_profit_view["OAI"]["fees"] > 5.0


def test_a_halted_venue_pauses_closing_and_logs_once():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, row(0.2, -0.2))
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 5 * 3600, corridor_at_open=8.3)
        eng.executor.halts.trip("lighter", "User or API Wallet 0x… does not exist.")
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "halted" and "Lighter" in d[0]["reason"]
        assert eng.executor.calls == []
        run(eng.run_cycle())
        halted = [c for c in store.recent_cycles() if c["plan"] == "halted"]
        assert len(halted) == 1
        assert eng.resume_trading() == ["lighter"]
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "close"


def test_an_orphan_that_is_actually_hedged_is_not_flattened():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, row(0.2, 0.0))        # 快照：Arcus 那条腿没显示出来
        eng.executor.positions = (0.2, -0.2)          # 复核：其实在
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 600, corridor_at_open=8.3)
        run(eng.run_cycle())
        assert eng.executor.calls == []
        assert any(c["plan"] == "orphan_false" for c in store.recent_cycles())


def test_orphan_slippage_escalates_on_repeated_failures():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, row(0.2, 0.0))
        eng.executor.positions = (0.2, 0.0)
        eng.executor.flatten_error = "IOC 没成交"
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 600, corridor_at_open=8.3)
        run(eng.run_cycle())
        run(eng.run_cycle())
        widths = [kw["wide_bps"] for name, kw in eng.executor.calls if name == "flatten_orphan"]
        assert widths == [30.0, 60.0]
        eng.executor.flatten_error = None
        run(eng.run_cycle())
        assert eng._orphan_fail.get("OAI") is None


def test_reduce_only_would_increase_means_the_orphan_is_gone():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, row(0.0, -0.2))
        eng.executor.positions = (0.0, -0.2)
        eng.executor.flatten_error = "REDUCE_ONLY_WOULD_INCREASE"
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0,
                          opened_at=time.time() - 600, corridor_at_open=8.3)
        run(eng.run_cycle())
        assert any(c["plan"] == "orphan_false" for c in store.recent_cycles())
        assert eng._orphan_fail.get("OAI") is None


# ── Lighter：拒单不算发出去；拒单后核对密钥，对不上就熔断 ──────

class _RejectSigner:
    ORDER_TYPE_MARKET = 1
    ORDER_TIME_IN_FORCE_IMMEDIATE_OR_CANCEL = 0
    DEFAULT_IOC_EXPIRY = 0

    def __init__(self, key_error=None):
        self.key_error = key_error
        self.checks = 0

    async def create_order(self, **kw):
        return None, None, "invalid order"

    def check_client(self):
        self.checks += 1
        return self.key_error


def _lighter_executor(signer):
    from parallax_hedge.execution import Executor
    from test_execution import FakeMarket as FM, settings
    ex = Executor(settings(), FM(), dry_run=False)
    ex._lighter_signer = signer
    return ex


def test_a_rejected_lighter_order_is_not_submitted():
    ex = _lighter_executor(_RejectSigner())
    leg = run(ex._lighter_ioc(1, "buy", 0.5, 100.0, (4, 2)))
    assert leg.ok is False and leg.submitted is False and not leg.uncertain
    assert not ex.halts.any()


def test_a_rejection_with_a_bad_api_key_trips_the_lighter_halt():
    signer = _RejectSigner(key_error="private key does not match the one on Lighter")
    ex = _lighter_executor(signer)
    run(ex._lighter_ioc(1, "buy", 0.5, 100.0, (4, 2)))
    assert ex.halts.is_halted("lighter") and "核对失败" in ex.halts.describe()
    ok, why = run(ex.probe("lighter"))
    assert ok is False
    signer.key_error = None
    assert run(ex.probe("lighter")) == (True, "API 密钥核对通过")


# ── v1.9.1 ───────────────────────────────────────────

def test_a_task_whose_state_changed_mid_cycle_is_skipped():
    """后台挂单刚开完仓、本轮快照还是旧的：不能拿它去「接管」或「清掉」。"""
    with tempfile.TemporaryDirectory() as tmp:
        eng, store = _live(tmp, row(0.2, -0.2))
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0)
        stale = store.get_task("OAI")
        store.upsert_task("OAI", opened_at=time.time(), hold_hours=3.0)
        decisions = []
        run(eng._cycle_task(stale, {"OAI": row(0.2, -0.2)},
                            {"OAI": __import__("test_engine").MARKET}, {}, decisions, {},
                            time.time()))
        assert decisions[0]["plan"] == "maker_busy"
        assert store.get_task("OAI")["hold_hours"] == 3.0       # 没被重抽
        assert not any(c["plan"] == "adopt" for c in store.recent_cycles())


# ── v1.11.1 Arcus 盘后价格带 ─────────────────────────────

BOUND = "Arcus 拒单：FILL_WILL_EXCEED_TRADING_BOUND"


def test_close_rolls_back_the_lighter_leg_when_arcus_is_rejected():
    ex, r = close_with(FakeMarket(lighter=0.2, arcus=-0.2), arcus_ok=False)
    assert r.stage == "close_rolled_back" and not r.ok
    # 先平 Lighter（卖 0.2，只减仓），Arcus 被拒，再把 Lighter 买回 0.2（不是只减仓）
    assert [(s, q, ro) for s, q, ro in ex.lighter_orders] == [
        ("sell", pytest.approx(0.2), True), ("buy", pytest.approx(0.2), False)]
    assert ex.market_state.lighter == pytest.approx(0.2)
    assert ex.market_state.arcus == pytest.approx(-0.2)
    assert "恢复对冲" in r.reason
    assert [a for a, _ in r.ledger].count("open") == 1


class BoundStub(LiveStub):
    def __init__(self):
        super().__init__(positions=(0.0, -0.2), flatten_error=BOUND)
        self.lighter_orders = []

    async def _lighter_ioc(self, symbol, side, qty, price, decimals, reduce_only=False):
        self.lighter_orders.append((side, qty, reduce_only))
        return LegResult("lighter", True, submitted=True, filled=qty, side=side, requested=qty)


def test_an_arcus_orphan_blocked_by_the_trading_band_is_rehedged_and_paused():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, svc = make(tmp, row(0.0, -0.2), dry_run=False)
        eng.executor = BoundStub()
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=1.0,
                          opened_at=time.time() - 2 * 3600, corridor_at_open=8.3)
        run(eng.run_cycle())
        # Arcus 空单平不掉 → 在 Lighter 买入同样数量，恢复「Lighter 多 / Arcus 空」的对冲
        assert eng.executor.lighter_orders == [("buy", pytest.approx(0.2), False)]
        plans = [c["plan"] for c in store.recent_cycles()]
        assert "orphan_rehedged" in plans and "arcus_bound" in plans
        assert eng._arcus_bound_until["OAI"] > time.time() + 25 * 60
        # 补回对冲后到期了：价格带暂停期间不平
        svc.row = row(0.2, -0.2)
        eng.executor.calls.clear()
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "idle" and "价格带" in d[0]["reason"]
        assert eng.executor.calls == []
        # 暂停结束后照常平
        eng._arcus_bound_until["OAI"] = 0
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "close"
