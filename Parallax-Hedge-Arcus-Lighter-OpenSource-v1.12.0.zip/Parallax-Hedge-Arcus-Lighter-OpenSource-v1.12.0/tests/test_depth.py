"""v1.12 按盘口深度限额。"""
import tempfile

import pytest

from parallax_hedge.books import Book, Level, max_quantity_within_cost, round_trip_cost_bps

from test_engine import make, row, run


def ladder(venue, mid, half_bps, step_bps, size, levels=20):
    bids = [Level(mid * (1 - (half_bps + i * step_bps) / 1e4), size) for i in range(levels)]
    asks = [Level(mid * (1 + (half_bps + i * step_bps) / 1e4), size) for i in range(levels)]
    return Book(venue, "X", bids, asks)


def test_round_trip_cost_grows_with_size():
    e = ladder("lighter", 100.0, 0.5, 1.0, 10)     # 每档 10 个，往深一档贵 1 bps
    a = ladder("arcus", 100.0, 0.05, 0.1, 100)
    small = round_trip_cost_bps(e, a, 5)
    big = round_trip_cost_bps(e, a, 50)
    assert small == pytest.approx(1.1, abs=0.01)
    assert big > 4 * small
    assert round_trip_cost_bps(e, a, 10_000) is None            # 深度不够


def test_max_quantity_within_cost():
    e = ladder("lighter", 100.0, 0.5, 1.0, 10)
    a = ladder("arcus", 100.0, 0.05, 0.1, 100)
    q = max_quantity_within_cost(e, a, cap_bps=4.0, high=100, low=1, quantity_decimals=2)
    assert round_trip_cost_bps(e, a, q) <= 4.0
    assert round_trip_cost_bps(e, a, q + 0.01) > 4.0
    assert max_quantity_within_cost(e, a, cap_bps=0.5, high=100, low=1, quantity_decimals=2) == 0


class DeepClient:
    """可以换盘口的假行情。"""


def _engine(tmp, lighter_book, cap=4.0, **task):
    eng, store, svc = make(tmp, row(), depth_cost_cap_bps=cap)

    async def ebook(market_id, symbol, limit=100):
        return lighter_book
    svc.client.lighter_book = ebook

    async def abook(symbol, levels=50):
        return ladder("arcus", 210.0, 0.05, 0.1, 1000)
    svc.client.arcus_book = abook
    eng.rng.uniform = lambda a, b: b
    store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0, **task)
    return eng, store


def test_a_thin_book_shrinks_the_round_but_not_below_the_range_minimum():
    with tempfile.TemporaryDirectory() as tmp:
        thin = ladder("lighter", 210.0, 0.5, 1.0, 1.0)      # 每档只有 1 个（约 210 U）
        eng, store = _engine(tmp, thin, notional_usdc=500.0, notional_usdc_max=1500.0)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "open", d[0]["reason"]
        notional = float(store.get_task("OAI")["target_quantity"]) * 210.0
        assert 500 <= notional < 1500
        logged = next(c["reason"] for c in store.recent_cycles() if c["plan"] == "open")
        assert "按盘口深度从" in logged


def test_a_deep_book_is_left_alone():
    with tempfile.TemporaryDirectory() as tmp:
        deep = ladder("lighter", 210.0, 0.5, 0.2, 1000)
        eng, store = _engine(tmp, deep, notional_usdc=500.0, notional_usdc_max=1500.0)
        run(eng.run_cycle())
        assert float(store.get_task("OAI")["target_quantity"]) * 210.0 == pytest.approx(1500, abs=3)


def test_the_range_minimum_is_kept_even_when_the_book_is_too_thin():
    with tempfile.TemporaryDirectory() as tmp:
        thin = ladder("lighter", 210.0, 3.0, 2.0, 0.5)
        eng, store = _engine(tmp, thin, notional_usdc=1000.0, notional_usdc_max=1500.0)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "open"
        assert float(store.get_task("OAI")["target_quantity"]) * 210.0 == pytest.approx(1000, abs=3)
        logged = next(c["reason"] for c in store.recent_cycles() if c["plan"] == "open")
        assert "盘口偏薄" in logged
