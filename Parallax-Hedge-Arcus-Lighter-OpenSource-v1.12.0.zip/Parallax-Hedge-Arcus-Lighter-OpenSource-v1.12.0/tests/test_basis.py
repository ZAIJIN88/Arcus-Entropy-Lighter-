"""v1.9 基差监控 / 回测 / 择时开仓。"""
import math
import tempfile
import time
from pathlib import Path

import pytest

from parallax_hedge.basis import (
    ArcusBookStream,
    BasisMonitor,
    BasisStore,
    LighterBookStream,
    RollingWindow,
    Sample,
    backtest,
    backtest_asset,
    entry_edge,
    sample_from_books,
)
from parallax_hedge.books import Book, Level

from test_engine import make, row, run


def book(venue, bid, ask, size=100.0):
    return Book(venue, "X", [Level(bid, size)], [Level(ask, size)])


def test_sample_uses_executable_prices():
    e = book("lighter", 100.10, 100.12)
    a = book("arcus", 100.00, 100.01)
    s = sample_from_books("X", e, a, 1000.0, ts=1.0)
    mid = (100.11 + 100.005) / 2
    assert s.mid == pytest.approx((100.11 - 100.005) / mid * 1e4)
    assert s.sell_e == pytest.approx((100.10 - 100.01) / mid * 1e4)   # 卖 E 吃买一、买 A 吃卖一
    assert s.buy_e == pytest.approx((100.12 - 100.00) / mid * 1e4)
    assert s.buy_e > s.mid > s.sell_e


def test_sample_needs_depth_for_the_notional():
    e = book("lighter", 100.0, 100.1, size=1.0)
    a = book("arcus", 100.0, 100.1, size=1.0)
    assert sample_from_books("X", e, a, 1000.0) is None


def test_rolling_window_trims_old_values():
    w = RollingWindow(1.0)
    w.add(0, 10.0)
    w.add(1800, 20.0)
    assert w.mean == pytest.approx(15.0) and w.ready
    w.add(3700, 30.0)                        # 0 秒那条掉出 1 小时窗口
    assert w.n == 2 and w.mean == pytest.approx(25.0)


def _s(ts, mid, cost=1.0, asset="X"):
    return Sample(ts, asset, mid, mid - cost / 2, mid + cost / 2, 1.0, 0.1, 5000.0)


def test_entry_edge_sign_follows_the_direction():
    last = _s(0, 2.0)                        # 平均 6，现在 2：Lighter 相对便宜
    long_e = entry_edge("long_lighter_short_arcus", last, 6.0)
    short_e = entry_edge("short_lighter_long_arcus", last, 6.0)
    assert long_e["favor"] == pytest.approx(4.0) and short_e["favor"] == pytest.approx(-4.0)
    assert long_e["expect"] == pytest.approx(3.0)        # 4 − 一来回价差成本 1


def test_backtest_profits_on_a_mean_reverting_basis_and_not_on_a_flat_one():
    # 平均 +5，按 2 小时周期在 ±10 之间摆动
    wave = [_s(t, 5 + 10 * math.sin(2 * math.pi * t / 7200)) for t in range(0, 3 * 86400, 30)]
    r = backtest(wave, threshold=6.0, window_hours=4, fee_bps_round_trip=1.0)
    assert r["trades"] > 10 and r["avg_net_bps"] > 4 and r["win_rate"] > 0.9
    flat = [_s(t, 5.0) for t in range(0, 86400, 30)]
    assert backtest(flat, threshold=2.0, window_hours=4, fee_bps_round_trip=1.0)["trades"] == 0


def test_backtest_charges_fees():
    wave = [_s(t, 5 + 10 * math.sin(2 * math.pi * t / 7200)) for t in range(0, 86400, 30)]
    cheap = backtest(wave, threshold=6.0, window_hours=4, fee_bps_round_trip=0.0)
    dear = backtest(wave, threshold=6.0, window_hours=4, fee_bps_round_trip=5.0)
    assert cheap["trades"] == dear["trades"]
    assert dear["total_net_bps"] == pytest.approx(cheap["total_net_bps"] - 5.0 * dear["trades"])
    summary = backtest_asset(wave, window_hours=4, arcus_fee_bps=2.25, lighter_fee_bps=0)
    assert summary["fee_round_trip_bps"] == pytest.approx(4.5)
    assert len(summary["rows"]) == 7


def test_store_round_trip():
    with tempfile.TemporaryDirectory() as tmp:
        db = BasisStore(Path(tmp) / "b.db")
        db.add([_s(10, 1.0), _s(20, 2.0)])
        assert [s.mid for s in db.load("X", 0)] == [1.0, 2.0]
        conn = db.reader()
        assert db.assets(0, conn) == ["X"]
        conn.close()
        db.close()


def test_stream_parsers():
    lt = LighterBookStream("wss://x", None)
    assert lt.subscribe_msg("7") == {"type": "subscribe", "channel": "order_book/7"}
    hit = lt.parse({"type": "subscribed/order_book", "channel": "order_book:7", "order_book": {
        "bids": [{"price": "100.1", "size": "2"}, {"price": "100.0", "size": "5"}],
        "asks": [{"price": "100.2", "size": "3"}]}})
    assert hit[0] == "7" and hit[1].best_bid == 100.1 and hit[1].best_ask == 100.2
    hit = lt.parse({"type": "update/order_book", "channel": "order_book:7", "order_book": {
        "bids": [{"price": "100.1", "size": "0"}], "asks": [{"price": "100.15", "size": "1"}]}})
    assert hit[1].best_bid == 100.0 and hit[1].best_ask == 100.15         # 数量 0 = 删掉这一档
    assert lt.parse({"type": "pong"}) is None
    a = ArcusBookStream("wss://y", None)
    hit = a.parse({"channel": "l2Orderbook", "id": "SNDK-USD",
                   "contents": {"bids": [["99.9", "1"]], "asks": [{"price": "100", "size": "2"}]}})
    assert hit[0] == "SNDK-USD" and hit[1].best_ask == 100.0


# ── 监控 + 择时开仓（演练模式引擎）─────────────────────

def _monitor(eng, store, tmp):
    mon = BasisMonitor(eng.settings, eng.service.client, store,
                       basis_store=BasisStore(Path(tmp) / "basis.db"))
    mon.markets = {"OAI": {"asset": "OAI", "lighter_symbol": "OPENAI", "lighter_market_index": 7,
                           "arcus_symbol": "OAI-USD"}}
    eng.basis = mon
    return mon


def _feed(mon, mids, now):
    """往窗口里塞一段历史（每分钟一条），最后再补 5 条 2 秒一条的「现在」（平滑要用）。"""
    n = len(mids)
    for i, m in enumerate(mids):
        mon._remember(_s(now - 60 - (n - 1 - i) * 60, m, asset="OAI"))
    _recent(mon, mids[-1], now)


def _recent(mon, mid, now=None):
    now = now or time.time()
    for j in range(5):
        mon._remember(_s(now - 8 + j * 2, mid, asset="OAI"))


def test_entry_waits_for_a_favorable_basis_then_opens():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, _ = make(tmp, row())
        mon = _monitor(eng, store, tmp)
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0)
        now = time.time()
        # 夹具方向是「Lighter 多 / Arcus 空」：要基差低于平均。平均约 +6，现在 +6 → 不开
        _feed(mon, [6.0] * 60, now)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "idle" and "择时开仓等待中" in d[0]["reason"]
        assert store.get_task("OAI")["opened_at"] is None
        # 一条瞬时尖峰不算：1 分钟平均还在 +5 附近
        mon._remember(_s(time.time(), 1.0, asset="OAI"))
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "idle"
        # 1 分钟平均也掉到 +1：对做多 Lighter 有利约 5 bps → 开
        _recent(mon, 1.0, time.time() + 1)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "open" and "择时：" in d[0]["reason"]


def test_entry_opens_anyway_after_the_max_wait():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, _ = make(tmp, row(), entry_max_wait_minutes=30.0)
        mon = _monitor(eng, store, tmp)
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0)
        _feed(mon, [6.0] * 60, time.time())
        run(eng.run_cycle())
        eng._entry_wait_since["OAI"] -= 31 * 60
        _recent(mon, 6.0)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "open" and "等满 30 分钟" in d[0]["reason"]


def test_entry_does_not_wait_without_enough_data():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, _ = make(tmp, row())
        mon = _monitor(eng, store, tmp)
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0)
        _feed(mon, [6.0] * 5, time.time())          # 只有 4 分钟数据
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "open" and "数据还不够" in d[0]["reason"]


def test_entry_timing_switch_off():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, _ = make(tmp, row(), entry_timing=False)
        mon = _monitor(eng, store, tmp)
        store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=4.0)
        _feed(mon, [6.0] * 60, time.time())
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "open"


def test_monitor_samples_books_and_reports_live_rows():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, _ = make(tmp, row())
        mon = _monitor(eng, store, tmp)
        now = time.time()
        mon.lighter_ws.books["7"] = (book("lighter", 210.10, 210.12), now)
        mon.arcus_ws.books["OAI-USD"] = (book("arcus", 210.00, 210.01), now)
        mon.lighter_ws.connected = mon.arcus_ws.connected = True
        mon.lighter_ws.connected_at = now - 1
        rows = mon.sample_all(now)
        assert len(rows) == 1 and rows[0].mid > 0
        live = mon.live()
        assert live["rows"][0]["asset"] == "OAI" and live["rows"][0]["fresh"]
        assert mon.db.load("OAI", 0)[0].mid == pytest.approx(rows[0].mid)
        bt = mon.run_backtest(days=1, arcus_fee_bps=2.25, lighter_fee_bps=0.0)
        assert bt["assets"] == {}                     # 1 条样本不够回测


def test_backtest_delay_kills_one_sample_spikes():
    """一条样本就弹回去的尖峰：不延迟时看起来稳赚，晚几秒成交就没了。"""
    S = []
    for t in range(0, 6 * 3600, 2):
        mid = 5.0 + (15.0 if t % 600 == 0 and t > 3600 else 0.0)
        S.append(_s(t, mid, cost=0.0))
    instant = backtest(S, threshold=6.0, window_hours=4, fee_bps_round_trip=1.0)
    late = backtest(S, threshold=6.0, window_hours=4, fee_bps_round_trip=1.0, delay_sec=4)
    assert instant["trades"] > 5 and instant["avg_net_bps"] > 5
    assert late["trades"] == instant["trades"] and late["avg_net_bps"] < 0


# ── v1.11 择时平仓 ────────────────────────────────────

def _due(tmp, lighter=0.2, arcus=-0.2, **over):
    eng, store, _ = make(tmp, row(lighter, arcus), **over)
    mon = _monitor(eng, store, tmp)
    store.upsert_task("OAI", enabled=1, leverage=6.0, rotation_hours=1.0,
                      opened_at=time.time() - 2 * 3600, corridor_at_open=8.3)
    return eng, store, mon


def test_a_due_close_waits_for_a_favorable_basis():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, mon = _due(tmp)              # 持有 Lighter 多：平仓要卖 Lighter，基差高于平均才有利
        _feed(mon, [6.0] * 60, time.time())
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "idle" and "择时平仓等待中" in d[0]["reason"]
        assert store.get_task("OAI")["opened_at"] is not None
        _recent(mon, 14.0, time.time() + 1)      # 1 分钟平均被拉到 +10 左右：有利约 4 bps
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "close" and "择时平仓：" in d[0]["reason"]


def test_a_due_close_goes_ahead_after_the_max_wait():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, mon = _due(tmp)
        _feed(mon, [6.0] * 60, time.time())
        run(eng.run_cycle())
        eng._exit_wait_since["OAI"] -= 31 * 60
        _recent(mon, 6.0)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "close" and "等满 30 分钟" in d[0]["reason"]


def test_risk_and_disabled_closes_never_wait():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, mon = _due(tmp)
        _feed(mon, [6.0] * 60, time.time())
        store.upsert_task("OAI", enabled=0)
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "close" and "择时" not in d[0]["reason"]


def test_exit_timing_switch_off():
    with tempfile.TemporaryDirectory() as tmp:
        eng, store, mon = _due(tmp, exit_timing=False)
        _feed(mon, [6.0] * 60, time.time())
        d = run(eng.run_cycle())
        assert d[0]["plan"] == "close"


def test_lighter_stream_answers_pings():
    lt = LighterBookStream("wss://x", None)
    assert lt.reply({"type": "ping"}) == {"type": "pong"}
    assert lt.reply({"type": "update/order_book"}) is None
